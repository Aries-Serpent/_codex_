<!-- BEGIN: CODEX_DOCS_MODEL_CARD_TEMPLATE -->

# Model Card Template

## Intended Use

- Tasks, domains, users.

## Training Data

- Sources, preprocessing, known limitations.

## Evaluation

- Datasets, metrics, results (CPU demo acceptable).

## Ethical Considerations & Safety

- Risks, mitigations, red-team coverage.

## Limitations

- Known failure modes, out-of-scope uses.
