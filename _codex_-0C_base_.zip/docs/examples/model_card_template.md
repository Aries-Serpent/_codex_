<!-- BEGIN: CODEX_MODEL_CARD -->

# Model Card (Template)

## Intended Use

## Training Data

## Evaluation Data

## Ethical Considerations

## Metrics & Limitations
