<!-- BEGIN: CODEX_DOCS_INDEX -->

# Codex Documentation

Welcome! This site covers **Getting Started (Ubuntu)**, **Concepts**, **API Reference**, **Tutorials**, **Ops**, and **Safety**.

> **Note to Codex:** Expand each section based on evolving modules (data loaders, checkpointing, safety, API service).
