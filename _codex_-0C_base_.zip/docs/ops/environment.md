<!-- BEGIN: CODEX_ENV_DOC -->

# Environment (Ubuntu)

- Use `scripts/gpu/check_gpu.sh` to summarize GPU driver/CUDA availability.
- Reproducibility: pin requirements and capture image digest when containerized.
- All validation runs are local (no online CI activation).
