<!-- BEGIN: CODEX_GRPC_PARITY_DOC -->

# gRPC Parity Plan

- Mirror REST endpoints: Train/Infer/Evaluate/Status.
- Define .proto, generate stubs, ensure compatibility tests.
