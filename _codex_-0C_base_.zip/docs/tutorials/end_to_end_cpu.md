<!-- BEGIN: CODEX_DOCS_TUTORIALS_END_TO_END -->

# End-to-End (CPU)

- Load a small JSONL dataset.
- Simulate training (checkpoints to `output/checkpoints/`).
- Evaluate and report metrics.
- Use `/train` to write artifacts under a mounted volume when containerized.
