<!-- BEGIN: CODEX_DOCS_TUTORIALS_QUICKSTART -->

# Quickstart (CPU)

1. Start API locally or via Docker Compose.
1. Run `examples/notebooks/demo_infer.ipynb` to call `/infer`.
1. Inspect outputs; no GPU required.
