# BEGIN: CODEX_API_MAIN
from __future__ import annotations

import asyncio
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, Field

ARTIFACTS = Path(os.getenv("ARTIFACTS_DIR", "/artifacts"))
ARTIFACTS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="Codex API", version="0.1.0")

QUEUE: "asyncio.Queue[dict]" = asyncio.Queue(maxsize=128)
JOBS: Dict[str, Dict[str, Any]] = {}


class InferRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=16000)


class InferResponse(BaseModel):
    completion: str
    tokens: int


class TrainRequest(BaseModel):
    epochs: int = Field(1, ge=1, le=100)
    notes: Optional[str] = None


class EvalRequest(BaseModel):
    dataset: str
    limit: int = 100


@app.on_event("startup")
async def _startup() -> None:
    async def worker() -> None:
        while True:
            job = await QUEUE.get()
            jid = job["id"]
            JOBS[jid] = {"status": "running", "started": time.time()}
            try:
                run_dir = ARTIFACTS / f"run-{int(time.time())}"
                run_dir.mkdir(parents=True, exist_ok=True)
                for e in range(job["epochs"]):
                    await asyncio.sleep(0.2)
                    (run_dir / f"epoch-{e + 1}.txt").write_text(
                        f"epoch {e + 1} done", encoding="utf-8"
                    )
                (run_dir / "metadata.json").write_text(
                    json.dumps({"epochs": job["epochs"]}), encoding="utf-8"
                )
                JOBS[jid] = {
                    "status": "completed",
                    "artifacts": str(run_dir),
                    "finished": time.time(),
                }
            except Exception as exc:  # noqa: BLE001
                JOBS[jid] = {"status": "failed", "error": str(exc)}
            finally:
                QUEUE.task_done()

    app.state.worker_task = asyncio.create_task(worker())


@app.post("/infer", response_model=InferResponse)
async def infer(req: InferRequest) -> InferResponse:
    text = req.prompt.strip()
    out = f"Echo: {text}"
    # basic secret filtering: mask sequences resembling API keys or tokens
    if os.getenv("DISABLE_SECRET_FILTER", "0") != "1":
        out = re.sub(r"(?i)(sk-\w{10,})", "[SECRET]", out)
    return InferResponse(completion=out, tokens=len(out.split()))


@app.post("/train")
async def train(req: TrainRequest) -> Dict[str, Any]:
    jid = f"job-{int(time.time() * 1000)}"
    await QUEUE.put({"id": jid, "epochs": req.epochs})
    return {"ok": True, "job_id": jid, "queued": QUEUE.qsize()}


@app.post("/evaluate")
async def evaluate(req: EvalRequest) -> Dict[str, Any]:
    return {"ok": True, "dataset": req.dataset, "limit": req.limit, "metrics": {"accuracy": 0.0}}


@app.get("/status")
async def status() -> Dict[str, Any]:
    return {"ok": True, "queue": QUEUE.qsize(), "jobs": JOBS}


@app.middleware("http")
async def api_key_middleware(request: Request, call_next):
    key = request.headers.get("x-api-key")
    expected = os.getenv("API_KEY")
    if expected and key != expected:
        raise HTTPException(status_code=401, detail="unauthorized")
    try:
        return await call_next(request)
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc))


# BEGIN: CODEX_FASTAPI_HARDEN
# FastAPI app with background queue, API-key middleware, and basic handlers

import asyncio  # noqa: E402
import os  # noqa: E402
from collections import defaultdict, deque  # noqa: E402

try:
    from fastapi import Depends, FastAPI, HTTPException, Request  # noqa: E402
    from fastapi.responses import JSONResponse  # noqa: E402
except Exception:
    FastAPI = None  # type: ignore

API_KEY_ENV = "CODEX_API_KEY"


def api_key_auth(request: Request) -> None:  # type: ignore
    key = os.environ.get(API_KEY_ENV)
    header = request.headers.get("x-api-key")
    if key and header != key:
        raise HTTPException(status_code=401, detail="Unauthorized")


def build_app():
    if FastAPI is None:
        return None
    app = FastAPI(title="Codex API")
    queue: asyncio.Queue = asyncio.Queue()
    requests: dict[str, deque[float]] = defaultdict(deque)
    rate_limit = int(os.getenv("API_RATE_LIMIT", "60"))
    window = int(os.getenv("API_RATE_WINDOW", "60"))

    @app.middleware("http")
    async def entry(request: Request, call_next):
        ip = request.client.host if request.client else "unknown"
        now = time.time()
        dq = requests[ip]
        while dq and now - dq[0] > window:
            dq.popleft()
        if len(dq) >= rate_limit:
            return JSONResponse(status_code=429, content={"error": "rate limit exceeded"})
        dq.append(now)
        try:
            start = time.time()
            response = await call_next(request)
        except HTTPException as he:
            print(f"{request.method} {request.url.path} {he.status_code}", flush=True)
            return JSONResponse(status_code=he.status_code, content={"error": he.detail})
        except Exception as e:  # noqa: BLE001
            print(f"{request.method} {request.url.path} 500", flush=True)
            return JSONResponse(status_code=500, content={"error": str(e)})
        duration = (time.time() - start) * 1000
        print(
            f"{request.method} {request.url.path} {response.status_code} {duration:.1f}ms",
            flush=True,
        )
        return response

    @app.get("/status")
    async def status():
        return {"ok": True, "queue": queue.qsize(), "ts": int(time.time())}

    @app.post("/infer")
    async def infer(request: Request, _=Depends(api_key_auth)):
        payload = await request.json()
        text = payload.get("prompt", "").strip()
        out = f"Echo: {text}"
        if os.getenv("DISABLE_SECRET_FILTER", "0") != "1":
            out = re.sub(r"(?i)(sk-\w{10,})", "[SECRET]", out)
        return {"completion": out, "ts": int(time.time())}

    @app.post("/train")
    async def train(request: Request, _=Depends(api_key_auth)):
        job = {"type": "train", "payload": await request.json(), "ts": int(time.time())}
        await queue.put(job)
        return {"queued": True, "job_id": job["ts"]}

    @app.post("/evaluate")
    async def evaluate(request: Request, _=Depends(api_key_auth)):
        job = {"type": "evaluate", "payload": await request.json(), "ts": int(time.time())}
        await queue.put(job)
        return {"queued": True, "job_id": job["ts"]}

    async def worker():
        while True:
            _ = await queue.get()
            await asyncio.sleep(0.1)
            queue.task_done()

    @app.on_event("startup")
    async def startup():
        asyncio.create_task(worker())

    return app


app = build_app()
# END: CODEX_FASTAPI_HARDEN
