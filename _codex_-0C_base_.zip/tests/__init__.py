# Test package marker for mypy
