def test_import_codex():
    import codex

    assert codex is not None
