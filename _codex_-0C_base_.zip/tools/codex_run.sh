#!/usr/bin/env bash
set -euo pipefail
python tools/codex_run.py "$@"
