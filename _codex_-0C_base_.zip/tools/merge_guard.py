#!/usr/bin/env python3
import os, sys, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
problems = []

# 1) No cost-incurring GitHub Actions
wf = ROOT/".github"/"workflows"
if wf.exists():
    problems.append("Workflows present: move to .github/_workflows_disabled before merge.")

# 2) Canonical interfaces present
tok = ROOT/"src"/"codex_ml"/"interfaces"/"tokenizer.py"
mlf = ROOT/"src"/"codex_ml"/"tracking"/"mlflow_utils.py"
shim = ROOT/"src"/"codex_ml"/"monitoring"/"mlflow_utils.py"
for p in (tok, mlf, shim):
    if not p.exists():
        problems.append(f"Missing {p}")

# 3) CLI guard
cli = ROOT/"src"/"codex"/"cli.py"
if cli.exists():
    if "__main__" not in cli.read_text():
        problems.append("src/codex/cli.py lacks __main__ guard")

print(json.dumps({"ok": not problems, "problems": problems}, indent=2))
sys.exit(0 if not problems else 1)
