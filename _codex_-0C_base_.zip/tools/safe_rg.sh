#!/usr/bin/env bash
rg "$@"
