## 2025-08-30T00:00:00Z — src/codex_ml/peft/peft_adapter.py
- **Action:** expand LoRA helper
- **Rationale:** support optional hyper-parameters and graceful fallback.

## 2025-08-30T00:00:00Z — functional_training.py
- **Action:** add gradient accumulation loop
- **Rationale:** enable micro-batch training in custom loop.

## 2025-08-30T00:00:00Z — .codex/inventory.txt
- **Action:** record environment inventory
- **Rationale:** track runtime versions.
