# Change Log (2025-08-19T01:53:49.982399Z)

## Updated Files
- `/workspace/_codex_/README.md` — 1 change(s). _Standardized README DB references_
- `/workspace/_codex_/README.md` — 3 change(s). _Normalized 3 SQLite reference(s)_
- `/workspace/_codex_/src/codex/logging/export.py` — 1 change(s). _Normalized 1 SQLite reference(s)_
- `/workspace/_codex_/src/codex/logging/session_query.py` — 5 change(s). _Normalized 5 SQLite reference(s)_
- `/workspace/_codex_/src/codex/logging/query_logs.py` — 2 change(s). _Normalized 2 SQLite reference(s)_
- `/workspace/_codex_/src/codex/logging/session_logger.py` — 1 change(s). _Normalized 1 SQLite reference(s)_
- `/workspace/_codex_/src/codex/logging/viewer.py` — 6 change(s). _Normalized 6 SQLite reference(s)_
- `/workspace/_codex_/.codex/change_log.md` — 17 change(s). _Normalized 17 SQLite reference(s)_
- `/workspace/_codex_/tests/test_chat_session.py` — 1 change(s). _Normalized 1 SQLite reference(s)_
- `/workspace/_codex_/tests/test_conversation_logger.py` — 1 change(s). _Normalized 1 SQLite reference(s)_
- `/workspace/_codex_/tests/test_logging_viewer_cli.py` — 1 change(s). _Normalized 1 SQLite reference(s)_
- `/workspace/_codex_/tests/test_session_logging.py` — 3 change(s). _Normalized 3 SQLite reference(s)_
- `/workspace/_codex_/tests/test_export.py` — 1 change(s). _Normalized 1 SQLite reference(s)_
- `/workspace/_codex_/scripts/codex_end_to_end.py` — 7 change(s). _Normalized 7 SQLite reference(s)_
- `/workspace/_codex_/scripts/apply_session_logging_workflow.py` — 5 change(s). _Normalized 5 SQLite reference(s)_
- `/workspace/_codex_/codex/logging/session_query.py` — 5 change(s). _Normalized 5 SQLite reference(s)_
- `/workspace/_codex_/codex/logging/session_logger.py` — 1 change(s). _Normalized 1 SQLite reference(s)_
- `/workspace/_codex_/documentation/end_to_end_logging.md` — 3 change(s). _Normalized 3 SQLite reference(s)_
- `/workspace/_codex_/tools/run_codex_workflow.sh` — 1 change(s). _Normalized 1 SQLite reference(s)_
- `/workspace/_codex_/tools/codex_workflow_session_query.py` — 3 change(s). _Normalized 3 SQLite reference(s)_
- `/workspace/_codex_/tools/codex_session_logging_workflow.py` — 2 change(s). _Normalized 2 SQLite reference(s)_
- `/workspace/_codex_/tools/codex_logging_workflow.py` — 2 change(s). _Normalized 2 SQLite reference(s)_
- `/workspace/_codex_/tools/codex_sqlite_align.py` — 5 change(s). _Normalized 5 SQLite reference(s)_
- `/workspace/_codex_/tools/codex_log_viewer.py` — 1 change(s). _Normalized 1 SQLite reference(s)_

## DB Inventory
{
  "discovered": [],
  "timestamp": "2025-08-19T01:53:49.981391Z"
}

## Cataloged Schemas
- See `db_catalog.json` (0 databases).

## Generated Previews
- No preview CSVs generated (no tables or access issues).

## Pruned Items (with rationale)
- None.

## Research Questions
- None captured.
