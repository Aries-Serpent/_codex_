# VERBATIM\_PROTOCOL.md

## Objective

Ensure ChatGPT 5 **copies researched responses verbatim** into canvases, with **zero omissions, zero paraphrasing, and strict byte-for-byte fidelity**. This protocol is mandatory for all “transpose” or “verbatim” requests in this Project.

---

## 1. Mode Declaration

- **Always enter **`` when user requests explicit transcription.
- Treat the request as **copy-operation only**, not a rewrite or summary.

---

## 2. Rules for Verbatim Transfer

1. **No rewrites, no summaries, no reflowing.** Copy the text exactly.
2. **Preserve ALL content**:
   - Whitespace
   - Line breaks
   - Code fences/backticks
   - Quotes, indentation, and punctuation
3. **No additions**:
   - Do not add titles, notes, or commentary unless explicitly in the user source.
4. **If the text exceeds message/canvas limits**:
   - Split into sequential parts:
     ```
     [PART 1/3]
     <content>
     [PART 2/3]
     <content>
     ...
     ```
   - Each part must be **contiguous**, with **no overlap** and **no missing sections**.

---

## 3. Canvas Protocol

When the request is to write into a **canvas**:

- **Create/overwrite** the canvas with:

  - Title: specified by user
  - Type: `document` (unless user specifies another type)
  - Content: paste the text exactly as provided

- If splitting is required:

  - Use titles like:
    - `<TITLE> (Part 1/N)`
    - `<TITLE> (Part 2/N)`

- Return **only the canvas titles and IDs** at the end. No commentary.

---

## 4. Audit & Verification

When requested by user:

- **Hash verification**:
  - Compute SHA-256 (or MD5) of both the **source** and the **final pasted content**.
  - Return both hashes. They must match.

This proves verbatim fidelity.

---

## 5. One-Liner Instruction Template

For user quick requests:

```
Copy the ENTIRE text I provide EXACTLY as-is into a canvas titled "<TITLE>", with ZERO edits or omissions; preserve whitespace and code fences; if too long, output sequential canvases titled "<TITLE> (Part X/N)" until complete; return only the canvas titles/IDs and no added commentary.
```

---

## 6. Escalation

If ChatGPT 5:

- Encounters formatting conflicts (e.g., nested code fences)
- Hits message length limits

→ It must **stop, notify the user, and request continuation protocol** instead of silently truncating.

---

✅ With this protocol in place, **all verbatim transpositions are enforced**, making it impossible to drop or alter content unintentionally.

