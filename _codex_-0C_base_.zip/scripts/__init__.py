"""Utility scripts packaged for invocation via ``python -m scripts``."""
