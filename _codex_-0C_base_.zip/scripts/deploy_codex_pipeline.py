# NOTE: Hydra entrypoint
# Prefer: python -m codex_ml.cli.main +dry_run=true
# You can pass overrides, e.g. train.epochs=2 tokenizer.name=gpt2

#!/usr/bin/env python3
"""
Deploy Codex symbolic training pipeline.

This script installs dependencies (unless skipped), validates JSONL inputs, and executes
the symbolic pipeline. Outputs such as model checkpoints and training summaries
are written to the specified directory.

Supports both CLI and importable usage, with robust error handling and explicit argument parsing.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from codex_ml.symbolic_pipeline import (
    PretrainCfg,
    RewardModelCfg,
    RLHFCfg,
    SFTCfg,
    Weights,
    run_codex_symbolic_pipeline,
    tokenize,
)
from codex_ml.tokenization import TokenizerAdapter, load_tokenizer
from codex_ml.tracking.cli import add_mlflow_flags, mlflow_from_args
from codex_ml.tracking.mlflow_utils import (
    MlflowConfig,
    log_artifacts,
    log_metrics,
    log_params,
    start_run,
)
from training.engine_hf_trainer import run_hf_trainer

__all__ = [
    "install_requirements",
    "log_env_info",
    "load_jsonl",
    "load_corpus",
    "load_demos",
    "load_prefs",
    "persist_outputs",
    "run_pipeline",
    "build_parser",
    "main",
]


def install_requirements(req: Path, skip: bool) -> None:
    """Install dependencies from ``req`` unless ``skip`` is True."""
    if skip:
        return
    if req.exists():
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(req)], check=True
        )


def log_env_info() -> None:
    """Log basic environment information (OS, Python, CUDA)."""
    import platform

    os_info = platform.platform()
    py_version = sys.version.split()[0]
    try:
        import torch

        cuda_version = getattr(torch.version, "cuda", "unknown")
        cuda_available = torch.cuda.is_available()
    except Exception:
        cuda_version = "not-installed"
        cuda_available = False
    print(f"OS: {os_info}")
    print(f"Python: {py_version}")
    print(f"CUDA: {cuda_version} (available: {cuda_available})")


def load_jsonl(path: Path) -> List[Any]:
    """
    Load newline-delimited JSON objects from `path`.
    """
    if not path.exists():
        raise FileNotFoundError(f"{path} does not exist")
    data: List[Any] = []
    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                data.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}: line {i} is not valid JSON: {exc}") from exc
    if not data:
        raise ValueError(f"{path} is empty")
    return data


def load_corpus(path: Path) -> List[str]:
    """
    Load corpus as a list of strings. Accepts either JSONL with raw strings
    or a plaintext file with one entry per line.
    """
    try:
        # Try as JSONL of strings
        raw = load_jsonl(path)
        corpus: List[str] = []
        for i, obj in enumerate(raw, 1):
            if not isinstance(obj, str):
                raise ValueError(f"{path}: line {i} must be a JSON string")
            corpus.append(obj)
        return corpus
    except Exception:
        # Fallback: treat as plain text lines
        return [
            line.strip()
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]


def load_demos(path: Path) -> List[Dict[str, Any]]:
    """
    Load demonstrations as a list of {'prompt':..., 'completion':...} dicts.
    """
    raw = load_jsonl(path)
    demos: List[Dict[str, Any]] = []
    for i, obj in enumerate(raw, 1):
        if not isinstance(obj, dict) or "prompt" not in obj or "completion" not in obj:
            raise ValueError(
                f"{path}: line {i} must be a dict with 'prompt' and 'completion' fields"
            )
        demos.append(obj)
    return demos


def load_prefs(path: Path) -> List[Tuple[str, str, str, int]]:
    """
    Load preferences as a list of ['prompt', 'A', 'B', label] tuples.
    """
    raw = load_jsonl(path)
    prefs: List[Tuple[str, str, str, int]] = []
    for i, obj in enumerate(raw, 1):
        if (
            not isinstance(obj, list)
            or len(obj) != 4
            or not all(isinstance(obj[j], str) for j in range(3))
            or not isinstance(obj[3], int)
        ):
            raise ValueError(
                f"{path}: line {i} must be ['prompt', 'A', 'B', label (int)]"
            )
        prefs.append((obj[0], obj[1], obj[2], obj[3]))
    return prefs


def persist_outputs(
    summary: Dict[str, Any],
    demos: List[Dict[str, Any]],
    output_dir: Path,
    tokenizer: Optional[TokenizerAdapter] = None,
) -> None:
    """Persist pipeline artefacts.

    The following files are written under ``output_dir``:

    ``summary.json``
        Top-level summary returned by ``run_codex_symbolic_pipeline``.
    ``checkpoints/*.json``
        Per-stage model handles, acting as lightweight checkpoints.
    ``metrics.json``
        Token counts, loss metrics and overall objective value.
    ``seeds.json``
        RNG seeds used for each training stage.
    """

    output_dir.mkdir(parents=True, exist_ok=True)

    # Summary of the whole run
    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    # Per-stage checkpoints
    ckpt_dir = output_dir / "checkpoints"
    ckpt_dir.mkdir(exist_ok=True)
    for name, handle in summary.get("handles", {}).items():
        (ckpt_dir / f"{name}.json").write_text(
            json.dumps(handle, indent=2), encoding="utf-8"
        )

    # Metrics and auxiliary outputs
    token_counts = {
        "pretrain_tokens": summary["handles"]["M0"]["meta"].get("tokens_seen", 0),
        "sft_tokens": sum(len(tokenize(ex["completion"], tokenizer)) for ex in demos),
    }
    metrics = {
        "token_counts": token_counts,
        "losses": summary.get("losses", {}),
        "objective_U": summary.get("objective_U", {}),
    }
    (output_dir / "metrics.json").write_text(
        json.dumps(metrics, indent=2), encoding="utf-8"
    )

    seeds = {
        "pretrain": summary["handles"]["M0"]["meta"].get("seed"),
        "sft": summary["handles"]["M1"]["meta"].get("seed"),
        "reward_model": summary["handles"]["RM"]["meta"].get("cfg", {}).get("seed"),
        "rlhf": summary["handles"]["M2"]["meta"].get("seed_rlhf"),
    }
    (output_dir / "seeds.json").write_text(
        json.dumps(seeds, indent=2), encoding="utf-8"
    )


def run_pipeline(args: argparse.Namespace) -> Dict[str, Any]:
    """
    Run the full symbolic pipeline given parsed CLI args.
    """
    corpus = load_corpus(Path(args.corpus))
    demos = load_demos(Path(args.demos))
    prefs = load_prefs(Path(args.prefs))

    Path("runs").mkdir(exist_ok=True)
    if args.enable_wandb:
        import wandb

        wandb.init(
            project=os.getenv("WANDB_PROJECT", "codex"), config={"alpha": args.alpha}
        )

    mlf_cfg: MlflowConfig = mlflow_from_args(args)

    w = Weights(alpha=args.alpha, beta=args.beta, gamma=args.gamma)
    pre_cfg = PretrainCfg(
        context_len=args.pretrain_context_len,
        lr=args.pretrain_lr,
        epochs=args.pretrain_epochs,
        seed=args.pretrain_seed,
    )
    sft_cfg = SFTCfg(
        lr=args.sft_lr,
        epochs=args.sft_epochs,
        batch_size=args.sft_batch_size,
        seed=args.sft_seed,
    )
    rm_cfg = RewardModelCfg(lr=args.rm_lr, epochs=args.rm_epochs, seed=args.rm_seed)
    rlhf_cfg = RLHFCfg(
        algo="PPO",
        ppo_clip=args.rlhf_ppo_clip,
        kl_penalty=args.rlhf_kl_penalty,
        epochs=args.rlhf_epochs,
        lr=args.rlhf_lr,
        seed=args.rlhf_seed,
    )

    tokenizer: Optional[TokenizerAdapter] = None
    if args.tokenizer_name or args.tokenizer_path:
        tokenizer = load_tokenizer(args.tokenizer_name, args.tokenizer_path)

    with start_run(mlf_cfg) as run:
        enabled = bool(run)
        log_params(
            {
                "alpha": args.alpha,
                "beta": args.beta,
                "gamma": args.gamma,
            },
            enabled=enabled,
        )
        summary = run_codex_symbolic_pipeline(
            corpus=corpus,
            demos=demos,
            prefs=prefs,
            w=w,
            pre_cfg=pre_cfg,
            sft_cfg=sft_cfg,
            rm_cfg=rm_cfg,
            rlhf_cfg=rlhf_cfg,
            tokenizer=tokenizer,
        )
        metrics = summary.get("metrics", {})
        log_metrics(metrics, enabled=enabled)
        if args.enable_wandb:
            wandb.log(metrics)

    output_dir = Path(args.output_dir)
    persist_outputs(summary, demos, output_dir, tokenizer)
    if tokenizer is not None:
        tokenizer.save(output_dir / "tokenizer.json")
    log_artifacts(output_dir, enabled=mlf_cfg.enable)

    try:  # GPU metrics
        import pynvml
        import torch

        if torch.cuda.is_available():
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            util = pynvml.nvmlDeviceGetUtilizationRates(handle).gpu
            if args.enable_wandb:
                import wandb

                wandb.log({"gpu_util": util})
            log_metrics({"gpu_util": float(util)}, enabled=mlf_cfg.enable)
    except Exception:  # noqa: BLE001
        pass

    return summary


def build_parser() -> argparse.ArgumentParser:
    """
    Build CLI argument parser.
    """
    p = argparse.ArgumentParser(description="Deploy Codex symbolic training pipeline")
    p.add_argument(
        "--corpus",
        required=True,
        help="JSONL of raw code/text lines or TXT (one per line)",
    )
    p.add_argument(
        "--demos", required=True, help="JSONL of {'prompt':..., 'completion':...}"
    )
    p.add_argument("--prefs", required=True, help="JSONL of ['prompt','A','B',label]")
    p.add_argument(
        "--output-dir", required=True, help="Directory for summaries/checkpoints"
    )

    p.add_argument(
        "--requirements",
        default=str(
            Path(__file__).resolve().parent.parent / "requirements" / "base.txt"
        ),
        help="Path to requirements file (default: requirements/base.txt)",
    )
    p.add_argument(
        "--skip-install",
        action="store_true",
        help="Skip installing Python requirements",
    )

    p.add_argument("--alpha", type=float, default=1.0)
    p.add_argument("--beta", type=float, default=1.0)
    p.add_argument("--gamma", type=float, default=0.1)

    p.add_argument("--pretrain-context-len", type=int, default=4096)
    p.add_argument("--pretrain-lr", type=float, default=1e-2)
    p.add_argument("--pretrain-epochs", type=int, default=1)
    p.add_argument("--pretrain-seed", type=int, default=0)

    p.add_argument("--sft-lr", type=float, default=1e-2)
    p.add_argument("--sft-epochs", type=int, default=1)
    p.add_argument("--sft-batch-size", type=int, default=32)
    p.add_argument("--sft-seed", type=int, default=0)

    p.add_argument("--rm-lr", type=float, default=0.1)
    p.add_argument("--rm-epochs", type=int, default=5)
    p.add_argument("--rm-seed", type=int, default=0)

    p.add_argument("--rlhf-lr", type=float, default=1e-2)
    p.add_argument("--rlhf-epochs", type=int, default=1)
    p.add_argument("--rlhf-ppo-clip", type=float, default=0.2)
    p.add_argument("--rlhf-kl-penalty", type=float, default=0.1)
    p.add_argument("--rlhf-seed", type=int, default=0)
    p.add_argument("--tokenizer-name", default="gpt2", help="Pretrained tokenizer name")
    p.add_argument(
        "--tokenizer-path", help="Path to tokenizer directory or tokenizer.json"
    )

    p.add_argument(
        "--engine",
        choices=["custom", "hf_trainer"],
        default="custom",
        help="Training engine to use. hf_trainer wraps HuggingFace Trainer and\n"
        "supports multi-GPU via torch.distributed (requires NCCL backend)",
    )
    p.add_argument(
        "--trainer-config",
        default=str(
            Path(__file__).resolve().parent.parent
            / "configs"
            / "training"
            / "base.yaml"
        ),
        help="YAML file with TrainingArguments for hf_trainer",
    )
    p.add_argument(
        "--model-name",
        default="sshleifer/tiny-gpt2",
        help="Model name or path for hf_trainer engine",
    )
    p.add_argument(
        "--fp16",
        action="store_true",
        help="Enable fp16 training when CUDA is available",
    )
    p.add_argument(
        "--enable-wandb", action="store_true", help="log to Weights & Biases"
    )
    add_mlflow_flags(p)
    return p


def main(argv: Optional[List[str]] = None) -> Dict[str, Any]:
    parser = build_parser()
    args = parser.parse_args(argv)
    install_requirements(Path(args.requirements), args.skip_install)
    log_env_info()
    if args.engine == "hf_trainer":
        corpus = load_corpus(Path(args.corpus))
        metrics = run_hf_trainer(
            corpus,
            Path(args.output_dir),
            model_name=args.model_name,
            config_path=Path(args.trainer_config),
            fp16=args.fp16,
        )
        return metrics
    return run_pipeline(args)


if __name__ == "__main__":
    main()
