"""Top-level package for Codex session logging utilities."""

# Exported modules or helpers may be added here in the future.
