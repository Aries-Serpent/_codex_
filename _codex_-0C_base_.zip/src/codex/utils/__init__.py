"""Utility helpers for codex."""
