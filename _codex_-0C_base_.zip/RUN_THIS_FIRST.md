# RUN THIS FIRST (local, offline)

1) Optional: verify guard
   ```bash
   python tools/merge_guard.py || true
   ```

2) Use a Codex runner with any of these prompts (in .codex/prompts/):
   - `one_shot_0C.yaml`   : prepares this 0C repo as the merge destination
   - `prepare_0A.yaml`    : guides aligning 0A branch to 0C canonical APIs
   - `orchestrator.yaml`  : full preflight + reconcile flow for both zips

3) Absolute rule: DO NOT enable or create GitHub Actions. Workflows are already moved to `.github/_workflows_disabled/` if present.

4) Offline gates you can run manually:
   ```bash
   ruff check . && black --check . && isort --check-only .
   pytest -q --import-mode=importlib --cov=src/codex_ml
   pre-commit run --all-files
   ```
