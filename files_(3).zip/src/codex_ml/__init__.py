"""
Package root init (simplified).
"""
__all__ = []