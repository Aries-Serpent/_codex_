"""
CLI package init.
"""
__all__ = []