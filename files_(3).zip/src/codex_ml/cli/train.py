"""
Hydra-based training CLI entry wrapping run_training.
"""

from __future__ import annotations
import json
from typing import Any
try:
    import hydra
    from omegaconf import DictConfig, OmegaConf
    _HAS_HYDRA = True
except Exception:
    _HAS_HYDRA = False

from codex_ml.train_loop import run_training


def _invoke(cfg_map: dict[str, Any]):
    # Flatten config fields of interest
    ckpt_cfg = cfg_map.get("checkpoint", {}) or {}
    sched_cfg = cfg_map.get("scheduler", {}) or {}
    ds_cfg = cfg_map.get("dataset", {}) or {}
    repro_cfg = cfg_map.get("reproducibility", {}) or {}

    result = run_training(
        epochs=cfg_map.get("epochs", 1),
        grad_accum=cfg_map.get("grad_accum", 1),
        steps_per_epoch=cfg_map.get("steps_per_epoch", 4),
        model_name=cfg_map.get("model_name"),
        device=cfg_map.get("device"),
        dtype=cfg_map.get("dtype"),
        checkpoint_dir=ckpt_cfg.get("dir") or "",
        resume=ckpt_cfg.get("resume", False),
        scheduler_cfg=sched_cfg if sched_cfg.get("type") else None,
        dataset_sources=ds_cfg.get("sources"),
        dataset_cache_dir=ds_cfg.get("cache_dir"),
        deterministic_cudnn=repro_cfg.get("cudnn_deterministic", False),
        retention_policy=ckpt_cfg.get("retention"),
        run_config=cfg_map,
    )
    print(json.dumps(result, indent=2))


if _HAS_HYDRA:

    @hydra.main(version_base=None, config_path="../../configs/train", config_name="default")
    def main(cfg: DictConfig):
        cfg_map = OmegaConf.to_container(cfg, resolve=True)
        _invoke(cfg_map)  # type: ignore

else:
    def main():
        import argparse
        ap = argparse.ArgumentParser(description="Training CLI (Hydra optional).")
        ap.add_argument("--epochs", type=int, default=1)
        ap.add_argument("--checkpoint-dir", type=str, default="")
        args = ap.parse_args()
        cfg_map = {
            "epochs": args.epochs,
            "checkpoint": {"dir": args.checkpoint_dir, "resume": False},
        }
        _invoke(cfg_map)


if __name__ == "__main__":
    main()