"""
Lightweight checkpoint wrapper integrating with existing repository checkpointing primitives.
Ensures consistent metadata sidecar and simple load interface.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

try:
    import torch
    _HAS_TORCH = True
except Exception:  # noqa
    torch = None  # type: ignore
    _HAS_TORCH = False

# Assume internal lower-level utilities exist; fallback minimal if not.
try:
    from codex_ml.utils import checkpointing as _ckpt_core
except Exception:  # noqa
    _ckpt_core = None  # type: ignore

__all__ = ["save_checkpoint", "load_checkpoint"]


def save_checkpoint(
    model: Any,
    optimizer: Any,
    scheduler: Any,
    out_dir: str | Path,
    metadata: Optional[dict] = None,
    filename: str = "checkpoint.pt",
) -> Path:
    out_p = Path(out_dir)
    out_p.mkdir(parents=True, exist_ok=True)
    ckpt_path = out_p / filename
    payload = {}
    if _HAS_TORCH and model is not None:
        payload["model_state"] = model.state_dict()
    if _HAS_TORCH and optimizer is not None:
        payload["optimizer_state"] = optimizer.state_dict()
    if scheduler is not None and hasattr(scheduler, "state_dict"):
        try:
            payload["scheduler_state"] = scheduler.state_dict()
        except Exception:  # noqa
            pass

    if _ckpt_core and hasattr(_ckpt_core, "safe_torch_save"):
        _ckpt_core.safe_torch_save(payload, ckpt_path)
    else:
        if _HAS_TORCH:
            torch.save(payload, ckpt_path)
        else:
            (ckpt_path).write_bytes(b"")  # Non-torch environment placeholder

    # Write metadata sidecar
    meta_file = out_p / "metadata.json"
    try:
        existing = {}
        if meta_file.exists():
            existing = json.loads(meta_file.read_text())
        combined = {**existing, **(metadata or {})}
        meta_file.write_text(json.dumps(combined, indent=2))
    except Exception:  # noqa
        pass
    return ckpt_path


def load_checkpoint(
    path: str | Path,
    model: Any = None,
    optimizer: Any = None,
    scheduler: Any = None,
) -> dict:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Checkpoint not found: {p}")
    if _HAS_TORCH:
        data = torch.load(p, map_location="cpu")
    else:
        data = {}
    if model is not None and "model_state" in data:
        try:
            model.load_state_dict(data["model_state"])
        except Exception:  # noqa
            pass
    if optimizer is not None and "optimizer_state" in data:
        try:
            optimizer.load_state_dict(data["optimizer_state"])
        except Exception:  # noqa
            pass
    if scheduler is not None and "scheduler_state" in data:
        try:
            scheduler.load_state_dict(data["scheduler_state"])
        except Exception:  # noqa
            pass
    return data