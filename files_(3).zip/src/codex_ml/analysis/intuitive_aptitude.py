"""
intuitive_aptitude: Code ingestion, structural analysis & pattern replication system.

Core Capabilities:
- AST-based safe parsing of Python code (no execution)
- Extraction: imports, functions, classes, variables, docstrings
- Pattern mining: error handling constructs, iteration forms, conditionals, function calls
- Metrics: LOC, comment ratio, approximate cyclomatic complexity
- Style heuristics: naming conventions, indentation, docstring style, paradigm bias
- Cloning: generate skeletal code with optional renaming mappings
- Reporting: unified export of summary + style + patterns
- Deterministic outputs: sorted keys & stable ordering

Design Principles:
- Pure in-memory, offline-first (no I/O or network)
- Safe fallbacks: ingest failure never raises outward; methods return empty structures
- Extensible: pattern extraction registry pattern for future categories
"""

from __future__ import annotations

import ast
import re
import textwrap
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple, Callable
import logging

logger = logging.getLogger(__name__)


@dataclass
class FunctionSpec:
    name: str
    args: List[str]
    defaults: List[str]
    decorators: List[str]
    returns: Optional[str]
    docstring: Optional[str]
    complexity: int
    lineno: int


@dataclass
class ClassSpec:
    name: str
    bases: List[str]
    methods: Dict[str, FunctionSpec] = field(default_factory=dict)
    docstring: Optional[str] = None
    lineno: int = 0


@dataclass
class VariableSpec:
    name: str
    value_repr: str
    lineno: int


_COMPLEXITY_NODES = (
    ast.If,
    ast.For,
    ast.While,
    ast.Try,
    ast.With,
    ast.IfExp,
)


def _safe_unparse(node: ast.AST) -> str:
    try:
        import ast as _ast_mod
        if hasattr(_ast_mod, "unparse"):
            return _ast_mod.unparse(node)
    except Exception:
        pass
    if isinstance(node, ast.Attribute):
        return f"{_safe_unparse(node.value)}.{node.attr}"
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Constant):
        return repr(node.value)
    return node.__class__.__name__


_NAME_STYLE_PATTERNS = {
    "snake_case": re.compile(r"^[a-z_]+[a-z0-9_]*$"),
    "PascalCase": re.compile(r"^[A-Z][A-Za-z0-9]+$"),
    "camelCase": re.compile(r"^[a-z]+[A-Za-z0-9]+$"),
    "UPPER_SNAKE": re.compile(r"^[A-Z][A-Z0-9_]+$"),
}


def _classify_name_style(name: str) -> str:
    for label, pat in _NAME_STYLE_PATTERNS.items():
        if pat.match(name):
            return label
    return "other"


_DOCSTYLE_HINTS = {
    "google": re.compile(r"\bArgs:\b"),
    "numpy": re.compile(r"\bParameters\s*\n-{3,}"),
    "sphinx": re.compile(r":param\s+\w+:"),
}


def _infer_docstring_style(docstring: str) -> str:
    if not docstring:
        return "none"
    for style, pat in _DOCSTYLE_HINTS.items():
        if pat.search(docstring):
            return style
    first_line = docstring.strip().splitlines()[0]
    if len(first_line) < 80:
        return "simple"
    return "other"


def _compute_comment_stats(code: str) -> Tuple[int, int, int]:
    total = 0
    comments = 0
    code_lines = 0
    for raw in code.splitlines():
        total += 1
        stripped = raw.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            comments += 1
        else:
            code_lines += 1
    return total, comments, code_lines


def _estimate_function_complexity(node: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    complexity = 1

    class Visitor(ast.NodeVisitor):
        def visit(self, inner):
            nonlocal complexity
            if isinstance(inner, _COMPLEXITY_NODES):
                complexity += 1
            elif isinstance(inner, ast.BoolOp):
                complexity += max(1, len(inner.values) - 1)
            elif isinstance(inner, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
                for gen in inner.generators:
                    complexity += 1
            super().visit(inner)

    Visitor().visit(node)
    return complexity


def _sorted_dict(d: Dict[str, Any]) -> Dict[str, Any]:
    return {k: d[k] for k in sorted(d.keys())}


class IntuitiveAptitude:
    """
    AST-based Python code analyzer for structural & stylistic introspection.
    """

    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.functions: Dict[str, FunctionSpec] = {}
        self.classes: Dict[str, ClassSpec] = {}
        self.imports: Dict[str, List[str]] = {}
        self.variables: Dict[str, VariableSpec] = {}
        self.patterns: Dict[str, List[Dict[str, Any]]] = {
            "error_handling": [],
            "iteration": [],
            "conditional": [],
            "function_calls": [],
        }
        self.metrics: Dict[str, Any] = {
            "loc": 0,
            "code_loc": 0,
            "comment_lines": 0,
            "comment_ratio": 0.0,
            "complexity": 0,
            "function_count": 0,
            "class_count": 0,
            "avg_func_complexity": 0.0,
        }
        self.ast_tree: Optional[ast.AST] = None
        self._raw_code: str = ""
        self.last_error: Optional[Dict[str, Any]] = None

    def ingest(self, code: str) -> bool:
        self.reset()
        self._raw_code = code or ""
        try:
            self.ast_tree = ast.parse(code)
        except SyntaxError as e:
            self.last_error = {
                "type": "SyntaxError",
                "message": e.msg,
                "lineno": e.lineno,
                "offset": e.offset,
            }
            return False
        except Exception as e:
            self.last_error = {"type": e.__class__.__name__, "message": str(e)}
            return False

        self._extract_imports()
        self._extract_toplevel()
        self._mine_patterns()
        self._compute_metrics()
        return True

    def _extract_imports(self) -> None:
        if not self.ast_tree:
            return
        for node in ast.walk(self.ast_tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    mod = alias.name
                    self.imports.setdefault(mod, []).append(alias.asname or None)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    key = f"{module}"
                    self.imports.setdefault(key, []).append(alias.asname or alias.name)

        for k, v in list(self.imports.items()):
            dedup = []
            seen = set()
            for item in v:
                token = item or "_NONE"
                if token in seen:
                    continue
                seen.add(token)
                dedup.append(item)
            self.imports[k] = sorted(dedup, key=lambda x: "" if x is None else x)

    def _extract_toplevel(self) -> None:
        if not self.ast_tree:
            return
        for node in self.ast_tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._register_function(node, is_method=False)
            elif isinstance(node, ast.ClassDef):
                self._register_class(node)
            elif isinstance(node, ast.Assign):
                self._register_assign(node)

    def _register_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef, is_method: bool):
        fn_name = node.name
        args = [a.arg for a in node.args.args]
        defaults = [self._expr_repr(d) for d in node.args.defaults]
        decorators = [self._expr_repr(d) for d in node.decorator_list]
        returns = self._expr_repr(node.returns) if node.returns else None
        docstring = ast.get_docstring(node)
        complexity = _estimate_function_complexity(node)
        spec = FunctionSpec(
            name=fn_name,
            args=args,
            defaults=defaults,
            decorators=decorators,
            returns=returns,
            docstring=docstring,
            complexity=complexity,
            lineno=getattr(node, "lineno", -1),
        )
        if is_method:
            return spec
        self.functions[fn_name] = spec

    def _register_class(self, node: ast.ClassDef) -> None:
        bases = [self._expr_repr(b) for b in node.bases]
        docstring = ast.get_docstring(node)
        cls_spec = ClassSpec(
            name=node.name,
            bases=bases,
            docstring=docstring,
            lineno=getattr(node, "lineno", -1),
        )
        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                method_spec: FunctionSpec = self._register_function(item, is_method=True)  # type: ignore
                cls_spec.methods[method_spec.name] = method_spec
        self.classes[node.name] = cls_spec

    def _register_assign(self, node: ast.Assign) -> None:
        value_repr = self._expr_repr(node.value)
        for target in node.targets:
            if isinstance(target, ast.Name):
                self.variables[target.id] = VariableSpec(
                    name=target.id,
                    value_repr=value_repr,
                    lineno=getattr(node, "lineno", -1),
                )

    def _expr_repr(self, node: Optional[ast.AST]) -> Optional[str]:
        if node is None:
            return None
        try:
            return _safe_unparse(node)
        except Exception:
            return node.__class__.__name__

    def _mine_patterns(self) -> None:
        if not self.ast_tree:
            return
        for node in ast.walk(self.ast_tree):
            if isinstance(node, ast.Try):
                self._record_try(node)
            elif isinstance(node, (ast.For, ast.While)):
                self._record_iteration(node)
            elif isinstance(node, ast.If):
                self._record_conditional(node)
            elif isinstance(node, ast.Call):
                self._record_call(node)

    def _record_try(self, node: ast.Try) -> None:
        handlers = []
        for h in node.handlers:
            if h.type is None:
                handlers.append("Exception")
            else:
                handlers.append(self._expr_repr(h.type))
        entry = {
            "lineno": getattr(node, "lineno", -1),
            "handler_count": len(node.handlers),
            "exception_types": handlers,
            "has_finally": bool(node.finalbody),
        }
        self.patterns["error_handling"].append(entry)

    def _record_iteration(self, node: ast.For | ast.While) -> None:
        if isinstance(node, ast.For):
            entry = {
                "type": "for",
                "target": self._expr_repr(node.target),
                "iter": self._expr_repr(node.iter),
                "lineno": getattr(node, "lineno", -1),
            }
        else:
            entry = {
                "type": "while",
                "test": self._expr_repr(node.test),
                "lineno": getattr(node, "lineno", -1),
            }
        self.patterns["iteration"].append(entry)

    def _record_conditional(self, node: ast.If) -> None:
        depth = self._if_nesting_depth(node)
        entry = {
            "test": self._expr_repr(node.test),
            "lineno": getattr(node, "lineno", -1),
            "depth": depth,
            "has_else": bool(node.orelse),
        }
        self.patterns["conditional"].append(entry)

    def _if_nesting_depth(self, node: ast.If) -> int:
        depth = 1

        def descend(n):
            nonlocal depth
            for ch in getattr(n, "orelse", []):
                if isinstance(ch, ast.If):
                    depth += 1
                    descend(ch)

        descend(node)
        return depth

    def _record_call(self, node: ast.Call) -> None:
        func_repr = self._expr_repr(node.func)
        entry = {
            "func": func_repr,
            "arg_count": len(node.args) + len(node.keywords),
            "lineno": getattr(node, "lineno", -1),
        }
        self.patterns["function_calls"].append(entry)

    def _compute_metrics(self) -> None:
        total, comment_lines, code_lines = _compute_comment_stats(self._raw_code)
        self.metrics["loc"] = total
        self.metrics["comment_lines"] = comment_lines
        self.metrics["code_loc"] = code_lines
        self.metrics["comment_ratio"] = (comment_lines / total) if total else 0.0
        self.metrics["function_count"] = len(self.functions)
        self.metrics["class_count"] = len(self.classes)

        total_complexity = sum(f.complexity for f in self.functions.values())
        for cls in self.classes.values():
            total_complexity += sum(m.complexity for m in cls.methods.values())

        func_total = len(self.functions) + sum(len(c.methods) for c in self.classes.values())
        self.metrics["complexity"] = total_complexity
        self.metrics["avg_func_complexity"] = total_complexity / func_total if func_total else 0.0

    def analyze_code_style(self) -> Dict[str, Any]:
        naming_styles = {"snake_case": 0, "PascalCase": 0, "camelCase": 0, "UPPER_SNAKE": 0, "other": 0}
        identifiers = list(self.functions.keys()) + list(self.classes.keys()) + list(self.variables.keys())
        for ident in identifiers:
            naming_styles[_classify_name_style(ident)] += 1

        indentation = self._detect_indentation()
        doc_styles = {"google": 0, "numpy": 0, "sphinx": 0, "simple": 0, "none": 0, "other": 0}
        for f in self.functions.values():
            doc_styles[_infer_docstring_style(f.docstring or "")] += 1
        for c in self.classes.values():
            doc_styles[_infer_docstring_style(c.docstring or "")] += 1
            for m in c.methods.values():
                doc_styles[_infer_docstring_style(m.docstring or "")] += 1

        method_defs = sum(len(c.methods) for c in self.classes.values())
        top_funcs = len(self.functions)
        paradigm = {
            "oop_method_defs": method_defs,
            "top_level_functions": top_funcs,
            "oop_ratio": method_defs / max(1, (method_defs + top_funcs)),
        }

        style = {
            "naming": naming_styles,
            "indentation": indentation,
            "docstring_styles": doc_styles,
            "paradigm": paradigm,
        }
        return style

    def _detect_indentation(self) -> str:
        lines = self._raw_code.splitlines()
        counts = {"tab": 0, "2space": 0, "4space": 0, "other": 0}
        for line in lines:
            if not line.strip():
                continue
            prefix = line[: len(line) - len(line.lstrip())]
            if not prefix:
                continue
            if prefix.startswith("\t"):
                counts["tab"] += 1
            elif prefix.startswith("    "):
                counts["4space"] += 1
            elif prefix.startswith("  "):
                counts["2space"] += 1
            else:
                counts["other"] += 1
        if not any(counts.values()):
            return "unknown"
        return max(counts, key=lambda k: counts[k])

    def get_summary(self) -> Dict[str, Any]:
        if self.last_error:
            return {"error": self.last_error}
        base = {
            "functions": len(self.functions),
            "classes": len(self.classes),
            "variables": len(self.variables),
            "imports": len(self.imports),
        }
        base.update(self.metrics)
        return _sorted_dict(base)

    def get_detailed_structure(self) -> Dict[str, Any]:
        if self.last_error:
            return {"error": self.last_error}

        def func_to_dict(spec: FunctionSpec):
            return {
                "name": spec.name,
                "args": spec.args,
                "defaults": spec.defaults,
                "decorators": spec.decorators,
                "returns": spec.returns,
                "docstring": spec.docstring,
                "complexity": spec.complexity,
                "lineno": spec.lineno,
            }

        def cls_to_dict(spec: ClassSpec):
            return {
                "name": spec.name,
                "bases": spec.bases,
                "docstring": spec.docstring,
                "lineno": spec.lineno,
                "methods": {k: func_to_dict(v) for k, v in sorted(spec.methods.items())},
            }

        structure = {
            "functions": {k: func_to_dict(v) for k, v in sorted(self.functions.items())},
            "classes": {k: cls_to_dict(v) for k, v in sorted(self.classes.items())},
            "variables": {
                k: {"value_repr": v.value_repr, "lineno": v.lineno}
                for k, v in sorted(self.variables.items())
            },
            "imports": {k: v for k, v in sorted(self.imports.items())},
        }
        return structure

    def extract_patterns(self) -> Dict[str, List[Dict[str, Any]]]:
        if self.last_error:
            return {"error": self.last_error}  # type: ignore
        return {k: list(v) for k, v in self.patterns.items()}

    def export_report(self) -> Dict[str, Any]:
        return {
            "summary": self.get_summary(),
            "style": self.analyze_code_style(),
            "patterns": self.extract_patterns(),
        }

    def clone_structure(self, mappings: Dict[str, str]) -> str:
        if self.last_error:
            return "# clone_structure unavailable due to previous parse error\n"

        def remap(name: str) -> str:
            return mappings.get(name, name)

        out_lines: List[str] = [
            "# Generated by intuitive_aptitude.clone_structure",
            "# Original element counts:",
            f"#   functions={len(self.functions)} classes={len(self.classes)} variables={len(self.variables)}",
            "",
        ]

        if self.imports:
            for mod, aliases in sorted(self.imports.items()):
                if aliases and any(a for a in aliases):
                    for alias in aliases:
                        if alias:
                            out_lines.append(f"from {mod} import {alias}")
                        else:
                            out_lines.append(f"import {mod}")
                else:
                    out_lines.append(f"import {mod}")
            out_lines.append("")

        for name, spec in sorted(self.variables.items()):
            out_lines.append(f"{remap(name)} = ...  # original: {spec.value_repr}")

        if self.variables:
            out_lines.append("")

        for name, spec in sorted(self.functions.items()):
            sig = self._build_function_signature(spec, remap)
            for dec in spec.decorators:
                out_lines.append(f"@{remap(dec)}")
            out_lines.append(f"def {remap(name)}{sig}:")
            body = self._infer_stub_body(spec)
            out_lines.append(textwrap.indent(body, "    "))
            out_lines.append("")

        for cname, cspec in sorted(self.classes.items()):
            bases = f"({', '.join([remap(b) for b in cspec.bases])})" if cspec.bases else ""
            out_lines.append(f"class {remap(cname)}{bases}:")
            if cspec.docstring:
                ds = textwrap.indent(f'"""Stub for {remap(cname)} (original doc trimmed)."""', "    ")
                out_lines.append(ds)
            if not cspec.methods:
                out_lines.append("    pass")
            else:
                for mname, mspec in sorted(cspec.methods.items()):
                    for dec in mspec.decorators:
                        out_lines.append(f"    @{remap(dec)}")
                    sig = self._build_function_signature(mspec, remap)
                    out_lines.append(f"    def {remap(mname)}{sig}:")
                    body = self._infer_stub_body(mspec, indent=8)
                    out_lines.append(body)
                    out_lines.append("")
            out_lines.append("")

        return "\n".join(out_lines).rstrip() + "\n"

    def _build_function_signature(self, spec: FunctionSpec, remap: Callable[[str], str]) -> str:
        parts = []
        defaults_offset = len(spec.args) - len(spec.defaults)
        for idx, arg in enumerate(spec.args):
            if idx >= defaults_offset:
                default_val = spec.defaults[idx - defaults_offset]
                parts.append(f"{remap(arg)}={default_val}")
            else:
                parts.append(remap(arg))
        arglist = ", ".join(parts)
        if spec.returns:
            return f"({arglist}) -> {spec.returns}"
        return f"({arglist})"

    def _infer_stub_body(self, spec: FunctionSpec, indent: int = 4) -> str:
        if spec.docstring:
            ds = textwrap.indent('"""Stub function (body omitted)."""', " " * indent)
            return f"{ds}\n{' ' * indent}pass"
        return " " * indent + "pass"

    def analyze_code_style_safe(self) -> Dict[str, Any]:
        try:
            return self.analyze_code_style()
        except Exception as e:
            logger.debug("Style analysis failed: %s", e)
            return {}

    def __repr__(self) -> str:
        return f"<IntuitiveAptitude funcs={len(self.functions)} classes={len(self.classes)} patterns={sum(len(v) for v in self.patterns.values())}>"


def intuitive_aptitude_factory() -> IntuitiveAptitude:
    return IntuitiveAptitude()


__all__ = ["IntuitiveAptitude", "intuitive_aptitude_factory"]