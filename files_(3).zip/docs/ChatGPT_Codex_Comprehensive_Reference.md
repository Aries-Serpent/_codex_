# [Docs]: ChatGPT-Codex Comprehensive System & Code Utility Reference  
> Generated: 2025-09-26 02:38:50 | Author: mbaetiong  
Roles: [Primary], [Secondary] ⚡ Energy: [5]

---

## 0. Purpose & Audience

This document is an exhaustive, integration-ready specification for ChatGPT-Codex (and similar AI code reasoning agents) to:
- Understand the intent, structure, interactions, and extension points of the current `_codex_` codebase components.
- Map tests to implementation responsibilities (verifiable contract points).
- Provide safe, pattern-aligned scaffolds for future automated modifications.
- Support deterministic, inspectable training & evaluation workflows (offline-first).
- Distill reproducibility, lifecycle, and API semantics into an internal model representation.

Every referenced file is annotated with:
- Intent
- Key abstractions
- Public surface (functions/classes)
- Contract (what tests assert / invariants)
- Extension guidelines
- Risk / Safety Notes

---

## 1. High-Level System Architecture

| Layer | Components | Purpose | Offline Behavior |
|-------|-----------|---------|------------------|
| Configuration | `configs/train/default.yaml`, `configs/evaluate/default.yaml` | Declarative knobs for training/evaluation flows | Resolved locally (no remote fetch) |
| Core Training Engine | `src/codex_ml/train_loop.py` | Deterministic synthetic (or future real) trainer with checkpointing, resume, callbacks, metrics, retention, hashing | Torch-guarded; degrades when torch absent |
| Dataset I/O | `src/codex_ml/data/loaders.py` | JSONL / CSV ingestion with checksum & metadata | Pure filesystem |
| Evaluation | `src/codex_ml/cli/evaluate.py` | Loads latest checkpoint & reports metadata (skeleton) | Fallback path if Hydra missing |
| Callbacks & Evaluation Hooks | `src/codex_ml/callbacks.py` | Pluggable lifecycle extension stage | Zero-cost no-op default |
| Determinism | `src/codex_ml/utils/determinism.py` | Optional CUDNN determinism enforcement | No-op w/o CUDA |
| Retention | `src/codex_ml/utils/retention.py` | Epoch directory pruning policy | Idempotent |
| Reproducibility Docs | `docs/reproducibility.md` | Canon of stability guarantees & flow semantics | Static |
| Implementation Plan & Updates | `docs/Implementation_Update_merged.md`, `docs/FollowUp_Implementation_Plan.md` | Change log & roadmap | Reference only |
| Integration Tests & Contracts | Multiple `tests/*` | Assert behavioral correctness | Skips gracefully when deps missing |
| Secret Filtering & Inference (Indirect) | (Not in this list but tested via API tests) | Mask sensitive patterns | Fallback echo logic |

---

## 2. File-by-File Detailed Mapping

### 2.1 `docs/Implementation_Update_merged.md`
- **Intent**: Snapshot of previously merged atomic diffs (training CLI, LoRA wiring, checkpointing, API inference secret masking).
- **Utility to ChatGPT-Codex**: Use as historic baseline to avoid regression or duplicate features; treat as provenance.
- **Key Data**: Parameter additions, file regions changed, explicit rollback paths.

### 2.2 `docs/FollowUp_Implementation_Plan.md`
- **Intent**: Ordered backlog (P1–P5) guiding incremental evolution.
- **AI Use**: When generating new PRs, align with uncompleted tasks; avoid re-implementing completed status ✅ tasks.
- **Structure**: Priority table + residual tasks ledger.

### 2.3 `src/codex_ml/train_loop.py`
- **Intent**: Central orchestrator for synthetic or future data-driven training.
- **Primary Exports**: `run_training(...)`
- **Capabilities**:
  - Model loading (registry) & optional LoRA adaptors (best-effort)
  - Optimizer (Adam), gradient accumulation
  - Minimal schedulers (`linear`, `step`) w/ per-epoch stepping
  - Callback integration (evaluation + logging)
  - Learning rate history tracking
  - Resume (latest.json discovery + state load)
  - Checkpoint hashing (SHA256 of `checkpoint.pt`)
  - Config snapshot persistence
  - Retention pruning (after each epoch)
  - Deterministic seeding (+ optional CUDNN).
- **Key Arguments (AI MUST preserve unless explicitly deprecated)**:
  | Param | Type | Purpose |
  |-------|------|---------|
  | `epochs` | int | Target total epochs (not delta) |
  | `resume` | bool | Continue if prior run exists |
  | `checkpoint_dir` | str | Root storing epoch folders + `latest.json` |
  | `scheduler_cfg` | dict | `{type: linear|step, ...}` |
  | `callbacks` | list[Callback] | Ordered execution hooks |
  | `eval_fn` | callable | Auto-wrapped into `EvaluationCallback` |
  | `deterministic_cudnn` | bool | Applies CUDNN determinism toggle |
  | `run_config` | dict | Serialized to `config.snapshot.json` |
  | `retention_policy` | dict | Passed to `prune_checkpoints` |
- **Return Keys** (partial contract):
  - `final_epoch`, `resumed`, `checkpoint_sha256_last`, `learning_rate_history`, `retention_last`
- **Test-Critical Invariants**:
  | Test | Invariant |
  |------|-----------|
  | `test_resume_training.py` | Start epoch = previous + 1 |
  | `test_training_lr_history_and_eval.py` | Len(lr hist) == epochs |
  | `test_checkpoint_checksum_and_retention.py` | SHA present & retention honored |
- **Extension Points**:
  - Add new scheduler types -> extend `_init_scheduler`
  - Real dataset integration -> replace synthetic `_synthetic_step`
  - Additional callback events -> expand `Callback` base
- **Safety / Risk Notes**:
  - Avoid introducing step-level LR logic before clarifying epoch semantics
  - Preserve resume short-circuit (avoid double-train case)
  - Keep checkpoint file naming stable for retention logic compatibility

### 2.4 `configs/train/default.yaml`
- **Intent**: Hydra config schema exemplar.
- **Sections**:
  | Section | Fields |
  |---------|--------|
  | `checkpoint` | `dir`, `resume`, `retention.*` |
  | `scheduler` | `type`, `gamma`, `final_lr_scale` |
  | `dataset` | `sources`, `cache_dir` |
  | `reproducibility` | `cudnn_deterministic` |
- **AI Use**: Source-of-truth for default param insertion when generating invocation examples.

### 2.5 `tests/test_resume_training.py`
- **Intent**: Validates epoch continuity & non-destructive resume semantics.
- **Contract**:
  - Starting epoch increments from saved state
  - Checkpoint directories must exist for each executed epoch
  - Non-existent `latest.json` + `resume=True` -> safe fallback (start at 1)

### 2.6 `src/codex_ml/data/loaders.py`
- **Intent**: Deterministic ingestion of JSONL / CSV with metadata tracing.
- **Exports**: `load_jsonl`, `load_csv`, `compute_file_checksum`
- **Metadata Schema (JSONL)**:
  | Key | Meaning |
  |-----|---------|
  | `num_records` | Count of successfully parsed rows |
  | `skipped_malformed` | Lines silently ignored |
  | `empty_file` | Bool indicator |
- **Design Principles**:
  - Full-file SHA256 (content identity)
  - BOM tolerant (`utf-8-sig`)
  - Malformed JSONL skipping vs fail-fast
- **AI Caution**: Do not replace `utf-8-sig` unless adding auto-detect; maintain skip-not-crash policy.

### 2.7 `tests/test_data_loaders.py`
- **Intent**: Baseline loader correctness (count, checksum determinism).
- **Guideline**: When changing loader internals, preserve checksum determinism (content-only hashing).

### 2.8 `tests/test_api_infer_masking.py`
- **Intent**: Ensures API inference masks secrets.
- **Patterns Covered**: `sk-`, `AKIA`, `ASIA`, `AIza`, `ghp_`, `xox[bp]`
- **AI Role**: Future secret patterns should be added with matching tests.

### 2.9 `tests/test_api_infer_tokenizer.py`
- **Intent**: Validates idempotent echo/completion pipeline.
- **Implication**: Tokenizer fallback must produce prompt-correlated output; altering decode semantics requires test updates.

### 2.10 `src/codex_ml/callbacks.py`
- **Intent**: Lightweight lifecycle hook system.
- **Classes**:
  | Class | Purpose |
  |-------|---------|
  | `Callback` | Base interface |
  | `EvaluationCallback` | Wraps `eval_fn(epoch, state)` into training |
  | `LoggingCallback` | Appends epoch metrics to `state['epoch_history']` |
- **Merging Semantics**:
  - `merge_callback_results` shallow merges; `eval` key merged at nested level.
- **AI Extension Model**:
  - Add new callback subclass -> pass via `callbacks=[...]`
  - Introduce event `on_step` only after updating training loop orchestrator.

### 2.11 `src/codex_ml/cli/evaluate.py`
- **Intent**: Skeleton evaluation entry invoking checkpoint loader.
- **Mode Duality**:
  - Hydra (if installed) via `@hydra.main`
  - Argparse fallback
- **Outputs**: Minimal JSON: `{evaluated_epoch_dir, model_name, model_params}`
- **AI Extension**:
  - Add dataset-driven evaluation -> Accept dataset paths; reuse loaders
  - Add metric aggregator -> streaming across evaluation batches

### 2.12 `configs/evaluate/default.yaml`
- **Intent**: Hydra-ready evaluation config (parity with CLI baseline).
- **Keys**: `checkpoint.dir`, `model_name`, `device`
- **AI Use**: Provide override examples safely.

### 2.13 `tests/test_data_loaders_extended.py`
- **Intent**: Edge case coverage (empty, BOM, malformed lines, quoting).
- **Contract**:
  - Malformed JSONL increments `skipped_malformed`
  - Empty CSV sets `empty_file=True`

### 2.14 `tests/test_training_lr_history_and_eval.py`
- **Intent**: Ensures evaluation callback merges metrics into epoch history; LR history length matches epochs count.
- **Key Assertions**:
  - `learning_rate_history` length = epochs
  - `state['epoch_history'][-1]['eval']['epoch_eval_score']` exists

### 2.15 `docs/reproducibility.md`
- **Intent**: Canonical reproducibility declaration.
- **Updated Additions**: CUDNN determinism toggle, retention, checkpoint hashing, config snapshot.
- **AI Cross-Check**: Aligns with final `train_loop` feature set.

### 2.16 `src/codex_ml/utils/determinism.py`
- **Intent**: Explicit, opt-in GPU reproducibility toggling.
- **Function**: `set_cudnn_deterministic(enable: bool, benchmark: bool=False)`
- **Safety**: Silent no-op on non-CUDA systems.
- **Test Coverage**: Indirect (no direct test but interacts logically with reproducibility doc).

### 2.17 `src/codex_ml/utils/retention.py`
- **Intent**: Post-epoch pruning policy with modular retention logic.
- **Policy Inputs**:
  | Param | Meaning |
  |-------|---------|
  | `keep_last` | Preserve latest N epoch directories |
  | `keep_every` | Preserve epochs divisible by modulus |
  | `max_epochs` | Final cap after union of retention sets |
  | Always Protected | Epoch in `latest.json` |
- **Return Schema**: `{total, kept[], pruned[], protected_latest, dry_run}`
- **AI Notes**: Avoid renaming `epoch-XXXX` pattern; retention depends on regex.

### 2.18 `tests/test_checkpoint_checksum_and_retention.py`
- **Intent**: Validates:
  - Checkpoint hashing exists + matches latest.json
  - Retention pruning enforces `keep_last`
  - SHA continuity across runs with resume
  - Config snapshot presence
- **Impact**: Any changes to file layout or hash algorithm must update expectations.

---

## 3. Cross-Cutting Behavioral Contracts

| Concern | Mechanism | Guarantee |
|---------|-----------|-----------|
| Determinism (Seed) | `_set_seed()` | 1234 when `seed in (None,0)` |
| Determinism (CUDNN) | `deterministic_cudnn=True` | CUDNN flags enforced |
| Resume Safety | `_attempt_resume()` | No double-run beyond target epochs |
| Integrity | SHA256 hash of `checkpoint.pt` | Exposed in result + pointer |
| Observability | `learning_rate_history` | Per-epoch LR evolution |
| Mutation Boundaries | Callback interface | Side-effect sandbox (state only) |
| Extensibility | `scheduler_cfg['type']` | Non-breaking extension via pattern |
| Storage Control | `retention_policy` | Bounded disk usage post-training |
| Dataset Robustness | Malformed JSONL skipping | Training unaffected by partial corruption |

---

## 4. CLI & Programmatic Invocation Recipes

### 4.1 Training (Hydra style)
```bash
python -m codex_ml.cli.train \
  epochs=6 steps_per_epoch=8 grad_accum=2 \
  checkpoint.dir=artifacts/ckpts checkpoint.resume=true \
  scheduler.type=linear scheduler.final_lr_scale=0.25 \
  reproducibility.cudnn_deterministic=true \
  checkpoint.retention.keep_last=3
```

### 4.2 Training (Programmatic)
```python
from codex_ml.train_loop import run_training

result = run_training(
    epochs=4,
    steps_per_epoch=5,
    grad_accum=2,
    checkpoint_dir="artifacts/ckpts",
    resume=True,
    scheduler_cfg={"type": "step", "step_size": 2, "gamma": 0.7},
    run_config={"experiment": "debug-lr"},
    retention_policy={"keep_last": 2},
    deterministic_cudnn=True,
    eval_fn=lambda e, st: {"ppl_proxy": 100 / (e + 1)},
)
print(result["checkpoint_sha256_last"])
```

### 4.3 Evaluate (Skeleton)
```bash
python -m codex_ml.cli.evaluate --checkpoint-dir artifacts/ckpts --model-name TinyModel
```

### 4.4 Retention (Standalone)
```python
from codex_ml.utils.retention import prune_checkpoints
summary = prune_checkpoints("artifacts/ckpts", keep_last=3, keep_every=5, dry_run=True)
print(summary)
```

---

## 5. Metrics Reference (Returned by `run_training`)

| Metric | Type | Description |
|--------|------|-------------|
| `final_epoch` | int | Last epoch processed (== target) |
| `resumed` | bool | Whether resume path used |
| `resumed_from_epoch` | int/None | Previous epoch before continuation |
| `optimizer_steps` | int | Total optimizer updates |
| `total_steps` | int | Raw synthetic steps processed |
| `learning_rate_history` | list[list[float]] | Per-epoch per-group LR snapshot |
| `checkpoint_sha256_last` | str/None | Integrity hash of latest checkpoint |
| `dataset_total_records` | int | Aggregated record count across sources |
| `retention_last` | dict/None | Last retention pruning summary |
| `model_params` | int/None | Parameter count (torch-based models) |

---

## 6. Callback System Specification

| Hook | Invocation Point | Inputs | Allowed Side Effects |
|------|------------------|--------|----------------------|
| `on_train_start` | Before epoch loop | `state` | Mutate state |
| `on_epoch_start` | Each epoch pre-steps | `epoch`, `state` | Logging, state prep |
| `on_epoch_end` | After metrics assembly | `epoch`, `metrics`, `state` | Return dict to merge |
| `on_train_end` | After loop | `state` | Finalization |

**Merge Strategy**:
- If `on_epoch_end` returns `{'eval': {...}}`, values are deep-updated under `metrics['eval']`.
- Non-conflicting scalar keys appended shallowly.

---

## 7. Extension Guidelines (AI-Aware)

| Objective | Recommended Pattern | Avoid |
|-----------|---------------------|-------|
| Add new scheduler | Extend `_init_scheduler`; keep epoch semantics | In-loop LR step before all grads aggregated |
| Add data pipeline | Introduce `data_iterator()` + replace `_synthetic_step` | Embedding data logic directly in loop |
| Add AMP | Gate with flag; wrap forward/backward only if CUDA | Forcing on CPU-only runs |
| Add structured logging | New callback subclass (`StructuredLoggingCallback`) | Hardcoding logger JSON into core |
| Add new retention modes | Extend `prune_checkpoints` w/ strategy arg | Rewriting directory naming convention |
| Add test coverage | Mirror existing test naming & skip patterns | Hidden implicit assertions |

---

## 8. Testing Matrix (Contract-Centric)

| Test File | Focus | Core Assertions |
|-----------|-------|------------------|
| `test_resume_training.py` | Resume semantics | Epoch continuity |
| `test_training_lr_history_and_eval.py` | LR + eval callback | History length & eval key existence |
| `test_checkpoint_checksum_and_retention.py` | SHA + retention + snapshot | Hash present + pruning logic |
| `test_data_loaders.py` | Basic ingestion | Count / checksum stability |
| `test_data_loaders_extended.py` | Edge input tolerance | Skipped malformed lines recorded |
| `test_api_infer_masking.py` | Secret hygiene | Mask token coverage |
| `test_api_infer_tokenizer.py` | Echo path stability | Prompt influences completion |

**AI Mutation Rule**: Never remove a field that tests assert unless also updating those tests with justification.

---

## 9. Reproducibility Layer Map

| Mechanism | File / Source | Restoration Path |
|-----------|---------------|------------------|
| Seed discipline | `train_loop._set_seed` | Pass same `seed` |
| CUDNN flags | `utils/determinism.py` | `deterministic_cudnn=True` |
| Config snapshot | `config.snapshot.json` | Reload & pass as `run_config` |
| Checkpoint pointer | `latest.json` | Auto-loaded via resume |
| Hash validation | `checkpoint_sha256_last` | Recompute & compare |
| LR trace | `learning_rate_history` | Compare shape & deltas |
| Retention resilience | `retention_last.kept` | Confirm expected epochs retained |

---

## 10. Risk Inventory & Mitigations

| Risk | Description | Mitigation Present | Future Action |
|------|-------------|--------------------|---------------|
| Non-atomic pointer writes | `latest.json` overwrite mid-crash | Acceptable for prototype | Temp file + atomic rename |
| Large dataset memory use | Full file load for big CSV/JSONL | Lightweight now | Streaming loader w/ yield |
| Missing secret patterns | New API keys unmasked | Extensible regex list | Add pattern registry |
| Over-pruning retention | Misconfigured policy removes useful epochs | `latest.json` protected | Add dry-run CLI |
| Callback side-effect collisions | Shared `state` mutation | Controlled access | Add reserved key namespace |

---

## 11. AI Code Generation Heuristics (For ChatGPT-Codex)

| Scenario | Pattern to Follow | Reference |
|----------|------------------|-----------|
| Add scheduler | Add branch in `_init_scheduler`; include `state_dict()` when stateful | Existing `linear`, `step` |
| New callback | Subclass `Callback`; return dict in `on_epoch_end` | `EvaluationCallback` |
| New metric | Compute in loop, append to `epoch_metrics` before callbacks | `lr` value injection |
| Add config field | Mirror YAML → accept param in `run_training` → thread to logic | `reproducibility.cudnn_deterministic` |
| Add CLI flag | Add Hydra config + parse in CLI; default safe fallback | `configs/train/default.yaml` |
| Add testable feature | Introduce deterministic outputs or structural artifacts | Checkpoint hashing pattern |

---

## 12. Glossary

| Term | Meaning |
|------|--------|
| Synthetic Step | Proxy training computation using simple param L2 |
| Resume | Continue training from last fully completed epoch |
| Learning Rate History | Ordered list capturing LR schedule evolution |
| Retention | Post-save pruning of older checkpoint epoch directories |
| Config Snapshot | Persisted user-provided run configuration input |
| Integrity Hash | SHA256 digest of raw checkpoint file contents |

---

## 13. Future Roadmap Hooks (For Planning Models)

| Planned Feature | Anchor Point |
|-----------------|--------------|
| AMP | Wrap `_synthetic_step` or real forward with autocast |
| Real Dataset Batching | Replace synthetic loop with enumerated dataloader |
| Advanced Schedulers | Extend `_init_scheduler` (cosine, warmup, polynomial) |
| Plugin System | Expand callback taxonomy with ordering + priorities |
| Atomic Pointer Writes | Utility wrapper for safe file replacement |
| Metrics Export (Prometheus) | Callback publishing gauge counters |

---

## 14. Quick Validation Checklist (Automated Agents)

| Check | Method |
|-------|--------|
| Pointer exists | `Path(checkpoint_dir/'latest.json').exists()` |
| Hash digest length | `len(checkpoint_sha256_last) == 64` |
| LR history shape | `len(learning_rate_history) == epochs` |
| Retention applied | Directory count matches policy |
| Eval callback presence | `'eval' in state['epoch_history'][-1]` |
| Dataset ingestion safe | No uncaught exceptions on malformed JSONL |

---

## 15. Minimal End-to-End Smoke (Agent Script)

```python
from codex_ml.train_loop import run_training
res = run_training(
    epochs=2,
    steps_per_epoch=3,
    checkpoint_dir="ck_dbg",
    scheduler_cfg={"type": "linear", "final_lr_scale": 0.2},
    retention_policy={"keep_last": 1},
    eval_fn=lambda e, st: {"score": e},
    run_config={"purpose": "smoke"}
)
assert res["final_epoch"] == 2
assert res["learning_rate_history"]
print("OK", res["checkpoint_sha256_last"])
```

---

## 16. Integrity & Consistency Assurance

| Element | Enforcement |
|---------|-------------|
| File naming (`epoch-XXXX`) | Regex in `retention.py` |
| Sidecar metadata | Augmented by train loop after save |
| Non-destructive resume | Early return if already complete |
| Config logging | Single write per run (overwrite semantics) |
| Hash propagation | Stored simultaneously in `metadata.json` & `latest.json` |

---

## 17. Change Impact Guidance (For AI Refactors)

| Change Type | Impact Level | Required Actions |
|-------------|--------------|------------------|
| Renaming `checkpoint.pt` | High | Update hashing, tests, docs |
| Adding per-step scheduler | Medium | Adjust LR capture granularity |
| Removing synthetic loop | Low-Medium | Preserve test abstractions via mock/dummy | 
| Changing hash algo | High | Update docs + tests referencing 64-char length |
| Modifying retention semantics | Medium | Expand test suite to cover new strategy |

---

## 18. Final Summary

This system is a **determinism-first, extensible training scaffold** engineered for rapid iteration with safety rails:
- All critical states (weights, optimizer, scheduler, config intent) are checkpointed.
- Observability surfaces (LR history, hashes, retention outputs) provide auditability.
- Modular callback design enables layering evaluation, logging, and future plugins.
- Test suite asserts correctness across lifecycle stages: ingestion, training, resumption, hashing, retention, masking.

AI agents interacting with this repository should:
1. Treat `run_training` signature as a stable integration surface.
2. Extend via additive patterns (callbacks, scheduler variants) rather than inline mutation.
3. Maintain test invariants or update them with explicit rationale.
4. Use deterministic constructs to maximize reproducible patch generation.

---

## 19. `__all__` and Public API Audit

| Module | Exported (`__all__`) | Stability |
|--------|----------------------|-----------|
| `train_loop` | `run_training` | Stable |
| `data.loaders` | `load_jsonl`, `load_csv`, `compute_file_checksum` | Stable |
| `callbacks` | `Callback`, `EvaluationCallback`, `LoggingCallback`, `merge_callback_results` | Additive OK |
| `utils.determinism` | `set_cudnn_deterministic` | Stable |
| `utils.retention` | `prune_checkpoints` | Stable |

---

## 20. Meta (Document Provenance)
- Derived from project evolution artifacts:
  - Implementation updates
  - Follow-up plan
  - Reproducibility specification
  - Active test suite contracts
- Safe to regenerate after API-expanding patches; treat this as canonical until superseded.

---

If further decomposition or embedding-oriented versions (vector-friendly slices) are required, request:  
"Generate embedding partitioned spec (N sections)" — preserving semantic anchors.

---