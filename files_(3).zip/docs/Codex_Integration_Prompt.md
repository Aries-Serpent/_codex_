# [Codex Integration Prompt]: Intuitive Aptitude Analyzer & Documentation Validation
> Generated: 2025-09-26 02:44:45 | Author: mbaetiong  
Roles: [Primary], [Secondary] ⚡ Energy: [5]

## PURPOSE
You (Codex) must:
1. Integrate a new analysis utility `intuitive_aptitude` into the `_codex_` codebase under `src/codex_ml/analysis/intuitive_aptitude.py`.
2. Ensure the implementation matches the documented specification below.
3. Cross-validate documentation vs. actual code (train loop, callbacks, loaders, determinism, retention).
4. Regenerate/update docs ONLY if discrepancies are detected (do not delete existing docs).
5. Produce deterministic, testable, side-effect minimal code (no network usage, offline-first).
6. Maintain backward compatibility; do not alter existing public API surfaces unless additive.

---

## SYSTEM CONTEXT (SOURCE OF TRUTH)
Key repo functional pillars already present (do NOT re-implement):
| Domain | Module(s) | Capability |
|--------|-----------|------------|
| Training engine | `src/codex_ml/train_loop.py` | Resume, checkpoints, retention, LR history |
| Dataset ingestion | `src/codex_ml/data/loaders.py` | JSONL + CSV, checksums, malformed skipping |
| Callbacks | `src/codex_ml/callbacks.py` | Lifecycle hooks, evaluation wrapper |
| Determinism | `src/codex_ml/utils/determinism.py` | CUDNN toggle |
| Retention | `src/codex_ml/utils/retention.py` | Epoch pruning |
| Reproducibility docs | `docs/reproducibility.md` | Hashing, seeds, config snapshot |

You MUST NOT duplicate these; only consume them if needed.

---

## NEW COMPONENT: intuitive_aptitude (ANALYZER)
Add file: `src/codex_ml/analysis/intuitive_aptitude.py`

### Functional Goals
| Feature | Requirement |
|---------|-------------|
| Parsing | Use `ast` to safely parse Python code |
| Extraction | Imports, functions (args, decorators), classes (bases, methods), assignments (top-level), docstrings |
| Pattern Mining | Try/Except, loops, conditionals, function call sites |
| Metrics | LOC, comment ratio, cyclomatic complexity (approx), function count, class count |
| Style Analysis | Naming conventions, indentation detection (2/4/tabs), docstring style heuristic, functional vs OOP bias |
| Cloning | Remap selected symbol names via mapping dict (safe regenerate stubs) |
| Pattern Templates | Provide generative scaffolds for each pattern cluster |
| Error Handling | Robust try/except around parsing; structured error object returned on failure |
| Deterministic Output | Sorted keys for summaries; stable ordering for generated code |
| Extensibility | Simple registry pattern for future pattern extractors |

### Public API (Must Export)
| Method | Signature | Description |
|--------|-----------|-------------|
| `ingest` | `ingest(code: str) -> bool` | Parse & populate internal structures |
| `get_summary` | `get_summary() -> dict` | High-level counts + metrics |
| `get_detailed_structure` | `get_detailed_structure() -> dict` | Full extracted model |
| `extract_patterns` | `extract_patterns() -> dict` | Patterns grouped by type |
| `analyze_code_style` | `analyze_code_style() -> dict` | Style metrics |
| `clone_structure` | `clone_structure(mappings: dict[str,str]) -> str` | Name-substituted code skeleton |
| `export_report` | `export_report() -> dict` | Composite of summary + style + patterns |
| `reset` | `reset() -> None` | Clear all internal state |

`__all__` MUST contain: `["IntuitiveAptitude", "intuitive_aptitude_factory"]`

### Internal Data Model
```python
self.functions = {
  func_name: {
    "args": [...],
    "defaults": [...],
    "decorators": [...],
    "returns": "repr",
    "docstring": "text|None",
    "complexity": int,
    "lineno": int,
  }, ...
}
self.classes = {
  class_name: {
    "bases": [...],
    "methods": {... method spec like functions ...},
    "docstring": str|None,
    "lineno": int,
  }, ...
}
self.imports = {
  "module": ["alias1", "alias2"|None],
  ...
}
self.variables = {
  var_name: {"value_repr": "repr", "lineno": int}
}
self.patterns = {
  "error_handling": [...],
  "iteration": [...],
  "conditional": [...],
  "function_calls": [...],
}
self.metrics = {
  "loc": int,
  "code_loc": int,
  "comment_lines": int,
  "comment_ratio": float,
  "complexity": int,
  "function_count": int,
  "class_count": int,
  "avg_func_complexity": float,
}
```

### Cyclomatic Complexity (Simplified)
Increment for nodes: If, For, While, Try, ExceptHandler, With, BoolOp, Comprehension, IfExp.

### Pattern Extraction Heuristics
| Pattern | AST Nodes | Recorded Fields |
|---------|-----------|-----------------|
| Error Handling | `ast.Try` | counts, has_finally, exception types |
| Iteration | `ast.For`, `ast.While`, comps | target, iterable repr |
| Conditional | `ast.If` | test repr, depth |
| Function Calls | `ast.Call` | function name (best-effort), arg count |

### Style Detection
| Aspect | Logic |
|--------|-------|
| Naming | Regex classify: snake_case, PascalCase, camelCase, UPPER_SNAKE |
| Indentation | Sample leading whitespace of non-empty lines |
| Docstring Style | Heuristics: Google (Args:), NumPy (Parameters), Sphinx (:param), Simple (short first line) |
| Paradigm Bias | Ratio: method defs vs top-level funcs & presence of `self` |

### Cloning Behavior
- Generate stubs only (no bodies) unless body is simple pass/return literal
- Replace names in signatures referencing mappings
- Preserve decorators (mapped if in dict)
- Omit original comments
- Prepend header comment with provenance marker: `# Generated by intuitive_aptitude.clone_structure`

### Error Handling Strategy
All externally callable methods:
- No raise unless catastrophic (e.g., ingest before parse) → return fallback or empty structures
- `ingest` returns False on parse failure & sets `self.last_error` with keys: `{"type": ..., "message": ..., "lineno": ...}`

---

## CODE QUALITY & VALIDATION RULES
| Rule | Enforcement |
|------|-------------|
| No network calls | Reject any urllib/http usage |
| No file I/O side-effects | Analyzer operates purely in-memory |
| Deterministic ordering | Sort names when emitting lists |
| Type hints required | For all public methods |
| Logging | Only via `logging.getLogger(__name__)` at debug level (optional) |
| Performance | Single pass AST walk where possible |
| Security | Never eval code; use AST only |

---

## DOC CONSISTENCY VALIDATION
You (Codex) MUST:
1. Compare `docs/reproducibility.md` content: ensure references to training features still exist in `train_loop.run_training`.
2. Ensure retention + SHA fields exist:
   - Fields: `checkpoint_sha256_last`, `retention_last`, `learning_rate_history`
3. Verify callbacks module exports listed classes.
4. Confirm dataset loader metadata has keys: `num_records`, `checksum`, `empty_file` (CSV & JSONL), `skipped_malformed` (JSONL only).
5. If mismatch: produce a report file `docs/consistency_report.md` with:
   - Section per discrepancy: expected vs found
   - Suggested remediation (do NOT auto-fix)

If all consistent: still create `docs/consistency_report.md` with “No discrepancies detected.”

---

## TEST AUGMENTATION (OPTIONAL PHASE)
After integration, you MAY (if instructed later) add:
- `tests/test_intuitive_aptitude_core.py`
  - Ingest sample code
  - Assert counts
  - Assert complexity > 0 when control flow present
  - Assert cloning preserves new names

Do NOT add now unless explicitly requested later.

---

## OUTPUT REQUIREMENTS
You must generate:
1. File: `src/codex_ml/analysis/intuitive_aptitude.py` (full implementation).
2. (If validation run requested later) `docs/consistency_report.md`

Current task: Produce only the new analyzer file.

---

## PSEUDOCODE OUTLINE (REFERENCE)
```
class IntuitiveAptitude:
    def ingest(code):
        reset()
        parse -> ast_tree
        walk -> collect (imports, funcs, classes, vars, patterns, metrics)
        compute derived metrics (comment ratio, complexity)
    def _walk():
        single pass with visit_* or manual stack
    def extract_patterns(): return deepcopy(patterns)
    def analyze_code_style(): run heuristics
    def clone_structure(mappings): build new code
```

---

## ACCEPTANCE CRITERIA
| Criterion | Pass Condition |
|-----------|----------------|
| Import safety | Only stdlib modules used |
| Public API stable | All required methods present |
| No merge artifacts | No conflict markers, no partial blocks |
| Deterministic output | Sorting enforced in summaries |
| Robust failure | Invalid Python returns False with last_error set |
| Comprehensive docstrings | Each public method documented |
| `__all__` present | Matches spec |
| No global state leakage | All state on instance |

---

## IMPLEMENTATION NOW
Proceed to emit the file.

---