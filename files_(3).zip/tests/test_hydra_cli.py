import pytest
import subprocess
import sys
from pathlib import Path

hydra = pytest.importorskip("hydra")

def test_train_cli_help():
    # Simple smoke check calling the module (if hydra installed)
    cmd = [sys.executable, "-m", "codex_ml.cli.train", "--help"]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    assert proc.returncode == 0
    assert "epochs" in proc.stdout.lower()