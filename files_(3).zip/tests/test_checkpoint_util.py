"""
Checkpoint utility roundtrip smoke test (torch-guarded).
"""

import pytest
torch = pytest.importorskip("torch")

from codex_ml.utils.checkpoint import save_checkpoint, load_checkpoint

def test_checkpoint_roundtrip(tmp_path):
    class M(torch.nn.Module):
        def __init__(self): super().__init__(); self.w = torch.nn.Linear(2,2)
    m = M()
    out = tmp_path / "ck"
    save_checkpoint(m, None, None, out)
    # mutate
    with torch.no_grad():
        for p in m.parameters(): p.add_(1.0)
    load_checkpoint(out / "checkpoint.pt", model=m)