import json
from pathlib import Path
import pytest

torch = pytest.importorskip("torch", reason="Torch required for resume / optimizer tests")

from codex_ml.train_loop import run_training  # noqa: E402


@pytest.fixture()
def ckpt_tmp(tmp_path):
    return tmp_path / "ckpts"


def test_resume_basic(ckpt_tmp):
    result1 = run_training(
        epochs=1,
        checkpoint_dir=str(ckpt_tmp),
        resume=False,
        model_name=None,
        steps_per_epoch=2,
    )
    assert (ckpt_tmp / "epoch-0001").exists()
    latest = json.loads((ckpt_tmp / "latest.json").read_text())
    assert latest["epoch"] == 1
    assert not result1.get("resumed")

    result2 = run_training(
        epochs=3,
        checkpoint_dir=str(ckpt_tmp),
        resume=True,
        model_name=None,
        steps_per_epoch=2,
    )
    assert result2["resumed"] is True
    assert result2["resumed_from_epoch"] == 1
    assert (ckpt_tmp / "epoch-0002").exists()
    assert (ckpt_tmp / "epoch-0003").exists()
    latest2 = json.loads((ckpt_tmp / "latest.json").read_text())
    assert latest2["epoch"] == 3


def test_resume_flag_without_checkpoint(tmp_path):
    ckpt_dir = tmp_path / "empty"
    ckpt_dir.mkdir()
    result = run_training(
        epochs=2,
        checkpoint_dir=str(ckpt_dir),
        resume=True,
        model_name=None,
        steps_per_epoch=2,
    )
    assert result["start_epoch"] == 1
    assert result["resumed"] is False
    assert (ckpt_dir / "epoch-0001").exists()
    assert (ckpt_dir / "epoch-0002").exists()