"""
API service main (excerpt focusing on /infer endpoint with secret masking, tokenizer/model lazy load).
"""

from __future__ import annotations
import re
import os
from fastapi import FastAPI, Body
from pydantic import BaseModel

app = FastAPI()

SECRET_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9]{10,}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"ASIA[0-9A-Z]{16}"),
    re.compile(r"AIza[0-9A-Za-z\-_]{20,}"),
    re.compile(r"ghp_[A-Za-z0-9]{30,}"),
    re.compile(r"xox[baprs]-[A-Za-z0-9\-]{10,}"),
]

def _mask_secrets(text: str) -> str:
    if os.getenv("DISABLE_SECRET_FILTER"):
        return text
    masked = text
    for pat in SECRET_PATTERNS:
        masked = pat.sub("[SECRET]", masked)
    return masked

# Echo fallback tokenizer/model
class _EchoTokenizer:
    def encode(self, s: str): return list(range(len(s.split())))
    def decode(self, tokens): return "<decoded length={}>".format(len(tokens))

class _EchoModel:
    def infer(self, prompt: str): return f"{prompt} :: completion"

def _inference_components(state):
    if not hasattr(state, "tokenizer"):
        state.tokenizer = _EchoTokenizer()
    if not hasattr(state, "model"):
        state.model = _EchoModel()
    return state.tokenizer, state.model

class InferRequest(BaseModel):
    prompt: str

@app.post("/infer")
def infer(req: InferRequest):
    tok, mdl = _inference_components(app.state)
    encoded = tok.encode(req.prompt)
    _ = tok.decode(encoded)
    out = mdl.infer(req.prompt)
    return {"completion": _mask_secrets(out), "tokens": len(encoded)}