# [ADR]: AST CLI Hybrid Output & Exit Codes
> Generated: 2025-11-11 07:57:50 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Design Owner], [Secondary: Reviewer] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [Human ↔ JSON] Fields🔄 [Typer] Patterns👁️ [Stable exits] Redundancy🔀 [Tests] Balance⚖️ [UX vs. API]

Decision
- Provide human by default, `--json` for machine output across analyze/audit/diff.
- Exit codes standardized: 0 success, 3 runtime error; 2 reserved for argument errors at Typer level.

Rationale
- Human-first UX lowers friction; JSON flag enables scripting and downstream tools.
- Stable exit codes simplify automation and audit integration.

Consequences
- Tests validate help text, JSON emission, and error paths.
- Future: enrich JSON schema with AST node stats, complexity, and symbol graphs.

— End —