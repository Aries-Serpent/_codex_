# [Prompt Template]: Intent Validation & Plan of Action Approval Gate
> Generated: 2025-11-11 07:38:40 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Execution Lead], [Secondary: Audit Orchestrator] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [Assess → Plan → Execute → Verify] Fields🔄 [Eval/Train, Logging, Security, Docs] Patterns👁️ [Determinism, Offline-first, “No need to reinvent the wheel”] Redundancy🔀 [Unit+Integration+Artifacts] Balance⚖️ [Score gain vs. change risk]

---

## Intent Validation
You want a phased plan to execute three iterations that raise the repository’s audit score to 99–100: Iteration 1 (evaluation loop, logging wiring, pip-audit, best‑k retention), Iteration 2 (Quickstart, config schema, AST CLI integration), and Iteration 3 (style normalization, determinism polish, CPU Dockerfile). We must preserve offline-first and deterministic pipelines and, per your directive, leverage deep web research to reuse proven patterns. Success = measurable score uplift across functionality/consistency/tests/safeguards/docs, new artifacts/tests/docs to prove it, and no regressions.

---

## Assumptions (✓ confirmed, ? uncertain, ⚠️ needs clarification)
- ✓ Offline-first remains the default; deep web search is for research only (no network in runtime paths).
- ✓ Local gates (nox tests/lint/typecheck/docs/security) are canonical; CI changes out-of-scope.
- ✓ PR #2201 will merge or rebase to 0D_base_ before Iteration 1 to avoid drift.
- ✓ Scoring rubric: audit v1.4.0 (weights: functionality 0.25, consistency 0.20, tests 0.25, safeguards 0.15, documentation 0.15).
- ✓ Minimum coverage thresholds for new/updated modules this cycle: 95% lines/branches for Iterations 1–2; later target 96–99%.
- ✓ Dependency policy for pip-audit findings: fix where feasible; fail on High/Critical; warn-only + JSON artifact for others with documented allowlist and expiry.

---

## Open Questions → Resolved Answers (based on your feedback)
1) CLI framework for new evaluation/utility commands:
   - Selected: D) Hybrid — Typer primary (built on Click) with lightweight argparse adapters where embedding is needed.

2) Minimum coverage threshold for new modules (loop/eval/registry/CLI):
   - Selected: C) 95% (lines and branches).

3) pip-audit policy for non-exploitable or pinned transitive CVEs:
   - Selected: B) Warn-only with JSON artifact; fail on High/Critical.

4) Experiment config format for schema validation:
   - Selected: D) Support JSON + TOML (with JSONSchema as the single source of truth).

5) System metrics in logging registry (CPU/RAM/ETA) default behavior:
   - Selected: A) Disabled by default; enable via flag (e.g., --sys-metrics).

6) AST CLI target audience for outputs:
   - Selected: C) Hybrid (human-readable by default; --json produces machine-readable JSON/NDJSON).

7) Style normalization strategy for E501/E402/E741:
   - Selected: D) One-shot repo-wide autofix PR + opportunistic per-module fixes.

8) Docker baseline target:
   - Selected: A) CPU-only Dockerfile mirroring nox env.

---

## Finalized Specs (frozen for Iterations 1–3)
- Modules and Entrypoints:
  - Evaluation loop: src/codex_ml/evaluation/loop.py (pure-Python, CPU-safe, lazy heavy imports).
  - CLI: Typer application “codex-eval” with subcommands run, report; human by default; --json flag.
  - Logging: src/codex_ml/logging/registry.py integrated into train/eval loops; NDJSON default; MLflow optional/offline guarded via flags.
  - Checkpoint retention: best‑k implementation with atomic metadata writes and safe deletion.
  - Security gate: nox -s security runs pip-audit; emits artifacts/security_report.json; fails on High/Critical; documents allowlist with expiry tags.
  - Config schema: configs/experiments/*.json and *.toml supported; JSONSchema in configs/schemas/experiments.schema.json; tools/validate_experiments.py validates both formats; nox session validate-configs.
  - Determinism: tests/repro/* for cross-process reproducibility with seeded loaders; env snapshot captured.
  - CPU Docker: docker/Dockerfile.cpu mirrors nox env; docs/deploy/cpu_local.md; default CMD runs pytest or nox.

- Coverage Targets:
  - Iterations 1–2: ≥95% lines/branches on new/modified modules (loop/eval/registry/CLI/checkpointing/schema/AST CLI).
  - Post-Iteration Prompt (next cycle): 96–99% focus via additional integration and edge-case tests.

---

## Phases of Action

### Phase 0 — Research & Alignment (no code, research artifacts included below)
Objective: Curate “no-reinventing” OSS patterns and finalize execution specs.
- Steps:
  - Deep web research on: robust PyTorch evaluation loops; pip-audit + nox policy; atomic best‑k retention; Typer modular CLI; JSON/TOML + JSONSchema validation; determinism recipes; CPU-only Docker mirroring local nox/pytest.
  - Freeze module names, flags, CLI interface, schema layout, and acceptance criteria.
- Decision gate: This document approved with resolved answers and specs.
- Effort/deps: 0.5–1 day.

### Phase 1 — Iteration 1 (Eval loop + logging wiring + pip‑audit + best‑k retention)
Objective: Land core execution path upgrades with tests and security gates (≥95% coverage).
- Tasks:
  - Implement evaluation.loop and Typer CLI (“codex-eval run …”; “codex-eval report …”).
  - Wire logging registry into train/eval loops; add optional system metrics via flag.
  - Implement best‑k retention with atomic metadata (write temp + os.replace) and safe deletions.
  - Add nox -s security: pip-audit; JSON artifact; fail on High/Critical; allowlist with expiry.
  - Tests: unit + integration for eval loop; logging wiring; best‑k pruning; golden JSON outputs; coverage ≥95%.
  - Docs: docs/api/loop_eval.md; docs/security/safeguards.md.
- Decision gate: All new tests ≥95%; nox security gate produces artifact; zero breaking changes; updated audit artifacts committed.

### Phase 2 — Iteration 2 (Quickstart + config schema + AST CLI integration)
Objective: Make the system discoverable and reproducible end-to-end (≥95% coverage).
- Tasks:
  - Write docs/quickstart_local_training.md covering tokenization → data → model → train → eval → checkpoint → report.
  - Add JSON+TOML experiment configs; JSONSchema + validator tool; nox validate-configs.
  - Enhance AST CLI subcommands (analyze/audit/diff), add --json output; stable exit codes; integration tests.
  - Update docs/ops/promotion_checklist.md to reflect new gates.
- Decision gate: Docs approved; schema validator green on samples; AST CLI tests pass; artifacts updated; coverage ≥95%.

### Phase 3 — Iteration 3 (Style normalization + determinism polish + CPU Dockerfile)
Objective: Maximize consistency and reproducibility; reduce friction to run.
- Tasks:
  - One-shot style pass: E501 (line length), targeted E402, E741 rename; update ruff config if needed.
  - Determinism tests: cross-process reproducibility suite; env snapshot gates; manifest hash chain proved.
  - Add docker/Dockerfile.cpu; docs/deploy/cpu_local.md; smoke test Quickstart inside container.
- Decision gate: Lint/typecheck clean; determinism tests pass; Docker build + Quickstart run OK.

---

## Risks and Mitigations
| Risk | Severity | Mitigation |
|---|---|---|
| Over-broad style changes create merge conflicts | Medium | Isolate in Phase 3; rebase early; small focused commits |
| pip-audit flags transient CVEs | Medium | Pin/upgrade; allowlist with rationale + expiry; rerun before merge |
| CLI contract churn | Low | Spec locked here; provide --json and robust help; add integration tests |
| Template/hash drift in audit artifacts | Low | Regenerate artifacts in single deterministic run; avoid manual post-edit edits |
| Optional MLflow dependency friction | Low | Keep disabled by default; lazy import; document usage |

---

## Deliverables
- Phase 0: Research notes + finalized specs; Open Question selections (this file).
- Phase 1: evaluation.loop + CLI; logging wiring; best‑k retention; pip-audit nox session; tests (≥95%); API doc; security artifact.
- Phase 2: Quickstart doc; experiments JSONSchema + samples (JSON+TOML); validator + nox session; AST CLI enhancements + tests (≥95%).
- Phase 3: Style normalization PR; determinism test suite; CPU Dockerfile + deployment doc.
- Final: Updated audit_artifacts (raw/scored/context/manifest), daily status report, coverage summaries, acceptance checklist.

---

## Acceptance Criteria
- This plan approved; answers frozen.
- New/changed code paths have ≥95% coverage; coverage report attached.
- Security gate emits artifacts/security_report.json and enforces fail-on High/Critical.
- Quickstart reproduces end-to-end workflow on CPU-only env; passes locally.
- AST CLI hybrid output works (human by default, --json for machines) with stable exit codes.
- Lint/typecheck clean; Docker CPU image builds and runs Quickstart successfully.
- Audit composite score shows uplift with updated capabilities_scored.json.

---

## Research Notes (Deep web search; reused patterns with citations)
[See included research sections in Execution Runbook and Specs files for detailed, cited patterns across eval loop, pip-audit policy, best‑k retention, Typer CLI, JSON/TOML validation, determinism, and CPU Docker.]

---

## Rollback / Fallback Plan
- All additions are flag-guarded or additive; revert by removing new modules/flags.
- Best‑k retention: fallback to previous non-pruning path via flag if issues arise.
- pip-audit enforcement can switch to warn-only temporarily with documented allowlists.
- Style normalization is formatting-only; easy git revert.
- Docker artifacts are non-invasive; safe to remove.

---