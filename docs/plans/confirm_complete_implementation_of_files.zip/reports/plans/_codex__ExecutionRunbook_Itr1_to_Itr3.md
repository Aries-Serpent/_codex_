# [Runbook]: Execution Plan — Iterations 1→3 toward 99–100
> Generated: 2025-11-11 07:38:40 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Execution Lead], [Secondary: Audit Orchestrator] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [Spec → Implement → Verify → Promote] Fields🔄 [Eval/Train, Logging, Security, Docs] Patterns👁️ [Determinism, Offline-first, OSS patterns] Redundancy🔀 [Unit+Integration+Artifacts] Balance⚖️ [Score gain vs. change risk]

## Scope
- Branches: 0D_base_ (target ring), copilot/sub-pr-2197 (source for PR #2201)
- PR: https://github.com/Aries-Serpent/_codex_/pull/2201
- Approved plan: IntentValidation_and_ActionPlan_ApprovalGate (answers resolved)
- Coverage targets:
  - Iterations 1–2: 90–95% (min 95% for new/changed modules)
  - Next cycle: 96–99%

## Iteration 1 — Eval loop + Logging wiring + pip‑audit + Best‑k
Objective: Land core execution path upgrades with tests and security gate; coverage ≥95% on touched modules.

Tasks
- Evaluation loop:
  - Implement src/codex_ml/evaluation/loop.py (CPU‑safe; lazy heavy imports).
  - Add Typer CLI “codex-eval”: subcommands run, report; human output by default; --json for machine output.
- Logging integration:
  - Wire logging registry into training and evaluation loops.
  - Add optional system metrics (CPU/RAM/ETA) disabled by default; enable via flag.
- Checkpointing:
  - Implement best‑k retention with atomic metadata writes (temp+rename) and safe deletions after index update.
- Security:
  - Add nox -s security session that runs pip-audit, emits artifacts/security_report.json, and fails on High/Critical; warn-only with allowlist+expiry for others.

Verification & Gates
- Tests: unit+integration for eval loop, logging wiring, best‑k; golden JSON/NDJSON baselines.
- Coverage: ≥95% lines/branches on new/changed modules.
- nox: tests, lint, typecheck, docs_build, security all pass.
- Artifacts: capabilities_raw/scored/context/run_manifest updated; security_report.json generated.

Commands (reference)
- nox -s tests lint typecheck docs_build security
- codex-eval run --config configs/experiments/minimal.json --json > artifacts/eval_report.json
- python scripts/space_traversal/audit_runner.py run

Deliverables
- Code: evaluation.loop, CLI, logging wiring, best‑k retention, nox security session.
- Docs: docs/api/loop_eval.md, docs/security/safeguards.md.
- Artifacts: artifacts/security_report.json; updated audit_artifacts/*.

## Iteration 2 — Quickstart + Config schema + AST CLI
Objective: End-to-end discoverability and reproducibility; coverage ≥95%.

Tasks
- Documentation:
  - Author docs/quickstart_local_training.md (tokenization → data → model → train → eval → checkpoint → report).
- Configs:
  - Support JSON + TOML experiment configs; single JSONSchema at configs/schemas/experiments.schema.json.
  - Implement tools/validate_experiments.py; nox validate-configs session.
- AST CLI:
  - Enhance analyze/audit/diff; human output by default; --json for machine output; stable exit codes.
  - Add integration tests (Typer CliRunner) and golden outputs.

Verification & Gates
- Schema validator green on sample JSON and TOML; tests pass with ≥95% coverage on changed modules.
- Quickstart steps reproducible on CPU-only environment.
- Audit artifacts regenerated; promotion checklist updated.

Deliverables
- Code: schema + validator + nox session; AST CLI enhancements + tests.
- Docs: Quickstart; updated docs/ops/promotion_checklist.md.

## Iteration 3 — Style normalization + Determinism polish + CPU Dockerfile
Objective: Maximize consistency and reproducibility; reduce friction to run.

Tasks
- Style:
  - One-shot repo-wide E501 fix; targeted E402; rename E741 cases; ruff config updates if needed.
- Determinism:
  - Cross-process reproducibility tests (seeded loaders, env hashing); env snapshot gates.
- Docker:
  - Add docker/Dockerfile.cpu mirroring nox env; docs/deploy/cpu_local.md.
  - Smoke: build image and run Quickstart.

Verification & Gates
- Lint/typecheck clean after style pass.
- Determinism tests pass on repeated runs; manifest hash chain preserved.
- Docker image builds; Quickstart runs successfully inside container.

Deliverables
- Code: style PR, tests/repro/*, Dockerfile.cpu.
- Docs: deployment guide.

## Risks & Mitigations
| Risk | Severity | Mitigation |
|---|---|---|
| Merge conflicts from style pass | Medium | Isolate in late PR, rebase early, small commits |
| pip-audit High/Critical findings | Medium | Pin/upgrade; allowlist with rationale + expiry; rerun before merge |
| CLI contract churn | Low | Spec frozen in specs files; integration tests; clear help/--json |
| Artifact hash drift | Low | Single-run regeneration; no manual edits post-render |
| Optional MLflow dependency friction | Low | Disabled by default; lazy import; documented offline mode |

## Acceptance Criteria (global)
- New/changed modules have ≥95% coverage in Iterations 1–2; repo-wide lint/typecheck/docs/security pass.
- Quickstart is reproducible on CPU-only; AST CLI hybrid outputs with stable exit codes.
- Docker CPU image builds and runs Quickstart; determinism tests green.
- Audit composite score uplift reflected in capabilities_scored.json.

## References (research-backed)
- Evaluation loop & logging best practices: CompileNRun, CodeGenes, SlingAcademy, PyTorch forums/StackOverflow.
- pip-audit + Nox integration: pypa/pip-audit docs, Nox docs.
- Best‑k retention: Lightning save_top_k semantics; Accelerate/AI Toolkit patterns.
- Typer CLI structure: Typer docs (subcommands/nested), RealPython.
- JSON/TOML validation with JSONSchema: jsonschema docs, check-jsonschema.
- Determinism best practices: PyTorch reproducibility notes, deterministic modes.
- CPU Docker patterns: Snyk/TestDriven.io; multi-stage, non-root, caching.

— End —