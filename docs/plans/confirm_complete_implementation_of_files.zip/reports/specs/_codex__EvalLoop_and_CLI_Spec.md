# [Spec]: Evaluation Loop & CLI Contract
> Generated: 2025-11-11 07:38:40 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Spec Author], [Secondary: Reviewer] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [API → CLI → Logs → Tests] Fields🔄 [PyTorch, Typer, NDJSON] Patterns👁️ [CPU-safe, lazy imports] Redundancy🔀 [Unit+Integration+Golden] Balance⚖️ [Simplicity vs. extensibility]

## Module
- Path: src/codex_ml/evaluation/loop.py
- Purpose: Deterministic, CPU-safe reference evaluation loop with pluggable metrics and logging sinks.

## Public API (stable)
```python
from typing import Iterable, Dict, Any, Optional, Protocol, Tuple

class Criterion(Protocol):
    def __call__(self, outputs, targets) -> "torch.Tensor": ...

class Logger(Protocol):
    def log(self, record: Dict[str, Any]) -> None: ...
    def close(self) -> None: ...

def evaluate_epoch(
    model,
    dataloader: Iterable,
    criterion: Criterion,
    device: str = "cpu",
    metrics: Optional[Dict[str, Any]] = None,   # mapping name -> callable(preds, targets)->float
    logger: Optional[Iterable[Logger]] = None,  # NDJSON, MLflow (offline), etc.
    max_batches: Optional[int] = None,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Runs evaluation over dataloader with torch.no_grad, model.eval().
    Returns summary dict: {"loss": float, "count": int, "metrics": {...}}
    """
```

Behavior
- Sets model.eval(), wraps in torch.no_grad().
- Computes running loss and standard metrics; supports metrics=None for minimal mode.
- Logging: emits per-batch (optional) and per-epoch aggregates to provided logger(s).
- Determinism: seed argument applied to DataLoader generator if provided; no randomness inside loop.
- Device handling: default "cpu"; lazy import torch; no heavy CUDA assumptions.

## CLI (Typer)
- Entrypoint group: codex_eval.app (exposed as console_script “codex-eval”)
- Commands:
  - run: Execute evaluation with config (JSON/TOML) or inline flags; human readable by default.
    - Options: --config PATH, --json, --device {"cpu","cuda"}, --max-batches INT, --metrics PRESET|PATH, --sys-metrics/--no-sys-metrics
  - report: Summarize previous NDJSON logs into JSON/Markdown; supports golden comparison.
- Exit codes: 0 success; 2 invalid config; 3 runtime error; 4 determinism mismatch.

## Logging
- Default NDJSON sink (file path under runs/eval/YYYYMMDD_HHMM/metrics.ndjson).
- Optional MLflow (offline) sink behind --mlflow flag; lazy import; disabled by default.
- System metrics collector opt-in via --sys-metrics.

## Tests
- Unit: empty dataloader, single-batch, multi-batch; metric function errors; device=cpu.
- Integration: CLI run with sample config; NDJSON lines parsed; golden epoch summary JSON.
- Coverage goal: ≥95% lines/branches.

## References
- Validation loop patterns and logging best practices (see Runbook references).

— End —