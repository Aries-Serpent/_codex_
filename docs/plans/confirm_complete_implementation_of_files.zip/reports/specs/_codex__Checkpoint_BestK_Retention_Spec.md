# [Spec]: Checkpoint Best‑K Retention (Atomic)
> Generated: 2025-11-11 07:38:40 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Spec Author], [Secondary: Reviewer] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [Save → Index → Prune] Fields🔄 [Atomic FS ops] Patterns👁️ [Temp+rename, sort+keep] Redundancy🔀 [Index JSON + tests] Balance⚖️ [Safety vs. simplicity]

Goal
- Keep top-k checkpoints by metric with robust, atomic index update and safe pruning.

Design
- Files:
  - {checkpoint_dir}/checkpoint_{global_step}.pt (or metric-tagged)
  - {checkpoint_dir}/index.json  (list of {path, metric, step, created_at})
- Algorithm:
  1) Save new checkpoint to staging file; fsync; rename into place.
  2) Load index.json (or seed []), append new entry.
  3) Sort by metric (lower better) then created_at; keep first k.
  4) Atomically write new index.json via temp+os.replace.
  5) Delete any files present in old index but not in new index (skip if missing; log warning).
- Options:
  - keep_last: bool (always retain most recent regardless of metric) — optional future
  - dry_run: bool for testing

Tests
- Unit: small synthetic index; verify prune set; atomic write (monkeypatch os.replace failure).
- Integration: multiple checkpoint cycles; ensure only k remains; corruption recovery path.
- Coverage ≥95%.

Notes
- Avoid concurrent writers; document single-writer assumption.
- Consider file locks on POSIX (optional).

References
- Lightning save_top_k semantics; Accelerate project config retention.

— End —