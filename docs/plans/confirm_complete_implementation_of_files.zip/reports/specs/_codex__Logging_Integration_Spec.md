# [Spec]: Logging Registry Integration (Train + Eval)
> Generated: 2025-11-11 07:38:40 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Spec Author], [Secondary: Reviewer] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [Registry → Sinks → Wiring] Fields🔄 [NDJSON, MLflow (offline)] Patterns👁️ [Flag‑guarded, lazy import] Redundancy🔀 [Golden logs + schema] Balance⚖️ [Minimal default, optional extras]

Scope
- Wire src/codex_ml/logging/registry.py sinks into:
  - Training loop (existing)
  - Evaluation loop (new)

Contract
- build_loggers(opts: Dict[str, Any]) -> List[Logger]
  - opts: {"output_dir": str, "use_mlflow": bool=False, "sys_metrics": bool=False}
- Emission policy:
  - Per-batch (optional) and per-epoch NDJSON records include: step/epoch, loss, metrics, wall_time, (optional) sys metrics.
  - Close all loggers on completion.

Flags
- --mlflow (default off; offline mode only)
- --sys-metrics (default off)
- Output dir default: runs/{train|eval}/%Y%m%d_%H%M%S

Tests
- Loggers produce expected fields; golden NDJSON baseline compare.
- MLflow guarded import; no import error when disabled.
- Sys-metrics collection toggles fields presence; covered by unit tests.
- Coverage ≥95%.

— End —