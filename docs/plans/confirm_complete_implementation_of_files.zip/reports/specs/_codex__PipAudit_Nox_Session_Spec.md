# [Spec]: Nox Security Session (pip‑audit High/Critical Fail)
> Generated: 2025-11-11 07:38:40 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Spec Author], [Secondary: Security Reviewer] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [Scan → Parse → Policy] Fields🔄 [pip-audit, JSON] Patterns👁️ [Fail-on-severity, allowlist+expiry] Redundancy🔀 [Artifact + logs] Balance⚖️ [Strict on High/Critical]

Session
- Name: security
- Steps:
  - Install pip-audit in session venv.
  - Run pip-audit on installed env or requirements(-all).txt with -f json.
  - Parse JSON; if any vulnerability severity in {HIGH, CRITICAL}, session.error().
  - Otherwise, write artifacts/security_report.json and continue.
- Allowlist:
  - File: security_allowlist.json (ids with rationale, expiry_date)
  - Filter out allowlisted items if not expired; still report in artifact.

Outputs
- artifacts/security_report.json
- console logs with counts by severity

Tests
- Simulate pip-audit JSON with high severity → expect session.error via helper function unit test.
- Allowlist honored until expiry; then fail.
- Coverage ≥95% on helper parser.

References
- pypa/pip-audit README; Nox docs.

— End —