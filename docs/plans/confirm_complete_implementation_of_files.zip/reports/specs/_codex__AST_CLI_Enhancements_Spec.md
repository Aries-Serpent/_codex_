# [Spec]: AST CLI Enhancements (analyze/audit/diff)
> Generated: 2025-11-11 07:38:40 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Spec Author], [Secondary: Reviewer] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [Command → Output → Exit] Fields🔄 [Typer CLI] Patterns👁️ [Hybrid output, stable exits] Redundancy🔀 [CliRunner tests] Balance⚖️ [Human UX vs. machine JSON]

Commands
- analyze: Produce AST node/graph metrics for a path.
- audit: Run repo audit; emit summary table; optionally JSON for machine use.
- diff: Compare two refs/paths and summarize AST deltas.

Behavior
- Human-readable by default; --json outputs structured JSON/NDJSON to stdout or file.
- Exit codes: 0 success; 2 invalid args; 3 runtime error.

Tests
- Typer CliRunner integration: help text, option parsing, success path, invalid args path.
- Golden files for --json outputs.
- Coverage ≥95%.

— End —