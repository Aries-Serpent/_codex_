# [Spec]: Experiment Configs — JSON/TOML + JSONSchema Validator
> Generated: 2025-11-11 07:38:40 UTC | Author: mbaetiong  
🧠 Roles: [Primary: Spec Author], [Secondary: Reviewer] ⚡ Energy: 5/5  
⚛️ Physics: Path🛤️ [Schema → Samples → Validate] Fields🔄 [JSONSchema, TOML] Patterns👁️ [Single SoT, multi-format] Redundancy🔀 [Precommit+Nox] Balance⚖️ [Strictness vs. UX]

Schema
- Location: configs/schemas/experiments.schema.json (Draft 2020-12)
- Top-level fields (example): model, tokenizer, data, training, evaluation, logging, checkpointing
- Required minimal fields: model.name, data.dataset, training.epochs, training.batch_size

Formats
- JSON: configs/experiments/*.json
- TOML: configs/experiments/*.toml (parsed to dict then validated against JSONSchema)

Tooling
- tools/validate_experiments.py:
  - Loads JSON or TOML (tomllib/tomli), loads schema, validates via jsonschema.
  - Exit codes: 0 ok, 2 schema invalid, 3 IO error.
- nox session: validate-configs — runs validator across sample configs.

Tests
- Valid/invalid samples for both JSON and TOML.
- Error messaging includes path to failing key.
- Coverage ≥95%.

— End —