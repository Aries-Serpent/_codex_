"""Registry facade exposing component registries and helper APIs.

This module intentionally performs *lazy* imports for component-specific
registries to avoid circular import issues.  ``codex_ml.models.registry`` depends
on :mod:`codex_ml.registry.base`, so eagerly importing the model facade from this
module previously caused an ``ImportError`` when both modules initialised at the
same time.  The helper :func:`__getattr__` resolves the concrete registry object
on first access and caches it in ``globals()`` so subsequent lookups are fast.

| Registry             | Purpose                                       |
|----------------------|-----------------------------------------------|
| ``model_registry``    | Declarative mapping of model builders         |
| ``tokenizer_registry``| Tokenizer adapters for training/evaluation   |
| ``metric_registry``   | Metric callables surfaced in evaluation CLI  |
| ``data_loader_registry`` | Dataset loaders and stream adapters       |
| ``trainer_registry``  | Training loop implementations (HF/custom)    |
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from importlib import import_module
from typing import Any

from .base import (
    Registry,
    RegistryConflictError,
    RegistryError,
    RegistryLoadError,
    RegistryNotFoundError,
)

__all__ = [
    "Registry",
    "RegistryConflictError",
    "RegistryError",
    "RegistryLoadError",
    "RegistryNotFoundError",
    "data_loader_registry",
    "get_data_loader",
    "get_metric",
    "get_model",
    "get_tokenizer",
    "get_trainer",
    "list_data_loaders",
    "list_metrics",
    "list_models",
    "list_tokenizers",
    "list_trainers",
    "metric_registry",
    "model_registry",
    "register_data_loader",
    "register_metric",
    "register_model",
    "register_tokenizer",
    "register_trainer",
    "reload_entry_points",
    "tokenizer_registry",
    "trainer_registry",
]

_LAZY_ATTRS = {
    "tokenizer_registry": (".tokenizers", "tokenizer_registry"),
    "register_tokenizer": (".tokenizers", "register_tokenizer"),
    "get_tokenizer": (".tokenizers", "get_tokenizer"),
    "list_tokenizers": (".tokenizers", "list_tokenizers"),
    "model_registry": (".models", "model_registry"),
    "register_model": (".models", "register_model"),
    "get_model": (".models", "get_model"),
    "list_models": (".models", "list_models"),
    "metric_registry": (".metrics", "metric_registry"),
    "register_metric": (".metrics", "register_metric"),
    "get_metric": (".metrics", "get_metric"),
    "list_metrics": (".metrics", "list_metrics"),
    "data_loader_registry": (".data_loaders", "data_loader_registry"),
    "register_data_loader": (".data_loaders", "register_data_loader"),
    "get_data_loader": (".data_loaders", "get_data_loader"),
    "list_data_loaders": (".data_loaders", "list_data_loaders"),
    "trainer_registry": (".trainers", "trainer_registry"),
    "register_trainer": (".trainers", "register_trainer"),
    "get_trainer": (".trainers", "get_trainer"),
    "list_trainers": (".trainers", "list_trainers"),
}

# Eagerly populate the module namespace so that __all__ exports are defined at
# import time (satisfies static analysis).  __getattr__ below remains as a
# fallback for any attribute that wasn't resolved during the eager phase.
try:
    from .data_loaders import (
        data_loader_registry,
        get_data_loader,
        list_data_loaders,
        register_data_loader,
    )
    from .metrics import (
        get_metric,
        list_metrics,
        metric_registry,
        register_metric,
    )
    from .models import (
        get_model,
        list_models,
        model_registry,
        register_model,
    )
    from .tokenizers import (
        get_tokenizer,
        list_tokenizers,
        register_tokenizer,
        tokenizer_registry,
    )
    from .trainers import (
        get_trainer,
        list_trainers,
        register_trainer,
        trainer_registry,
    )
except (
    ImportError,
    AttributeError,
):  # pragma: no cover - guard against circular imports in some envs
    logger.debug("Deferred registry imports will be resolved via __getattr__", exc_info=True)


def __getattr__(name: str) -> Any:
    """Lazily import facade attributes when accessed.

    Parameters
    ----------
    name:
        Attribute requested from the :mod:`codex_ml.registry` package.

    Returns
    -------
    Any
        The resolved object from the appropriate submodule.

    Raises
    ------
    AttributeError
        If the attribute is not part of the registry facade.
    """

    try:
        module_name, attr = _LAZY_ATTRS[name]
    except KeyError as exc:  # pragma: no cover - defensive
        raise AttributeError(f"module 'codex_ml.registry' has no attribute {name!r}") from exc
    module = import_module(module_name, package=__name__)
    value = getattr(module, attr)
    globals()[name] = value
    return value


def reload_entry_points() -> None:
    """Clear cached entry point state for all registries."""

    registry_specs = {
        ".tokenizers": ("tokenizer_registry",),
        ".models": ("model_registry",),
        ".metrics": ("metric_registry",),
        ".data_loaders": ("data_loader_registry",),
        ".trainers": ("trainer_registry",),
    }

    for module_name, attr_names in registry_specs.items():
        module = import_module(module_name, package=__name__)
        for attr in attr_names:
            registry = getattr(module, attr)
            if hasattr(registry, "_entry_points_loaded"):
                registry._entry_points_loaded = False
            failed = getattr(registry, "_failed_entry_points", None)
            if isinstance(failed, dict):
                failed.clear()
