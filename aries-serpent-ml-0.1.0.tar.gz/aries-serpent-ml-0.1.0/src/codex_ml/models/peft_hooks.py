"""
Peft Hooks Module

This module provides functionality for peft hooks.

Usage:
    from models.peft_hooks import ...

Classes:
    [To be documented]

Functions:
    [To be documented]

Author: Codex Team
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from dataclasses import dataclass  # noqa: E402
from typing import Any, Optional  # noqa: E402

try:
    from peft import LoraConfig, get_peft_model
except (ImportError, AttributeError):  # ImportError and others
    LoraConfig = None
    get_peft_model = None


@dataclass
class LoraBuildCfg:
    r: int = 8
    alpha: int = 16
    dropout: float = 0.0
    target_modules: Optional[list[str]] = None  # e.g., ["q_proj", "v_proj"]
    bias: str = "none"
    task_type: str = "SEQ_CLS"  # kept generic for toy tests


def build_lora(model: Any, cfg: Optional[LoraBuildCfg] = None) -> Any:
    """
    Optionally wrap a model with LoRA adapters.
    If PEFT is not installed, returns the model unchanged.
    """
    if LoraConfig is None or get_peft_model is None:
        return model
    cfg = cfg or LoraBuildCfg()
    lcfg = LoraConfig(
        r=cfg.r,
        lora_alpha=cfg.alpha,
        lora_dropout=cfg.dropout,
        target_modules=cfg.target_modules,
        bias=cfg.bias,
        task_type=cfg.task_type,
    )
    return get_peft_model(model, lcfg)
