"""
Config Loader Module

This module provides functionality for config loader.

Usage:
    from utils.config_loader import ...

Classes:
    [To be documented]

Functions:
    [To be documented]

Author: Codex Team
"""

from __future__ import annotations

import logging
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from codex_ml.utils.yaml_support import MissingPyYAMLError, safe_load
from omegaconf import DictConfig, OmegaConf

logger = logging.getLogger(__name__)


def _flatten_training_section(cfg: Mapping[str, Any]) -> dict[str, Any]:
    """Return a shallow copy of the training section if present, otherwise the whole mapping."""
    if "training" in cfg and isinstance(cfg["training"], Mapping):
        return dict(cfg["training"])
    return dict(cfg)


# Hydra import with robust fallbacks to support offline environments
try:  # pragma: no cover - optional dependency
    try:
        from hydra import compose, initialize_config_dir
        from hydra.errors import MissingConfigException
    except ImportError as e:
        error_type = type(e).__name__
        logger.debug("ImportError: <ERROR_TYPE>")
        logger.warning("ImportError: <ERROR_TYPE>", exc_info=True)
        from config_legacy import compose, initialize_config_dir
        from config_legacy.errors import MissingConfigException

    _HYDRA_AVAILABLE = True
except (ImportError, AttributeError):  # pragma: no cover - import guard
    try:
        from hydra_core import compose, initialize_config_dir  # type: ignore[no-redef]
        from hydra_core.errors import MissingConfigException  # type: ignore[no-redef]

        _HYDRA_AVAILABLE = True
    except (IOError, OSError):  # pragma: no cover - import guard
        compose = None

        initialize_config_dir = None

        class MissingConfigException(RuntimeError):  # type: ignore[no-redef]
            """Fallback error used when Hydra is unavailable."""

            def __init__(self, *, missing_cfg_file: str, message: str) -> None:
                super().__init__(message)
                self.missing_cfg_file = missing_cfg_file

        _HYDRA_AVAILABLE = False


def _find_cfg_dir() -> Path:
    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "configs" / "training"
        if candidate.is_dir():
            return candidate
    # default to repo-relative path if not found
    return here.parents[4] / "configs" / "training"


_CFG_DIR = _find_cfg_dir()
_PRIMARY = "base"


def _normalize_training_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize common training aliases and expose convenient top-level fields."""
    data = dict(payload)
    training = data.get("training")
    if isinstance(training, Mapping):
        training_map = dict(training)

        # Ensure lr/learning_rate are both populated from whichever is provided
        lr_value = training_map.get("lr", training_map.get("learning_rate"))
        if lr_value is not None:
            training_map.setdefault("lr", lr_value)
            training_map.setdefault("learning_rate", lr_value)

        # Ensure epochs/max_epochs are both populated from whichever is provided
        epochs_value = training_map.get("epochs", training_map.get("max_epochs"))
        if epochs_value is not None:
            training_map.setdefault("epochs", epochs_value)
            training_map.setdefault("max_epochs", epochs_value)

        data["training"] = training_map

        # Promote commonly used training keys to top-level for convenience
        alias_map = {
            "seed": "seed",
            "lr": "lr",
            "batch_size": "batch_size",
            "epochs": "epochs",
            "max_epochs": "epochs",
            "gradient_accumulation": "grad_accum",
            "grad_accum": "grad_accum",
            "device": "device",
            "dtype": "dtype",
            "model": "model",
            "model_name": "model_name",
        }
        for source_key, target_key in alias_map.items():
            if target_key in data and data[target_key] is not None:
                continue
            if source_key in training_map and training_map[source_key] is not None:
                data[target_key] = training_map[source_key]

        # Bubble up logging block if present under training
        if "logging" not in data and "logging" in training_map:
            data["logging"] = training_map["logging"]

    return data


# Detect whether DictConfig in the active env already supports attribute access
try:  # pragma: no cover - runtime capability detection
    _TEST_CFG = OmegaConf.create({"training": {}})
    _ = _TEST_CFG.training
except (IOError, OSError):  # AttributeError when attribute access unsupported
    _DICTCONFIG_SUPPORTS_ATTR = False
else:
    _DICTCONFIG_SUPPORTS_ATTR = True
finally:  # pragma: no cover - cleanup guard
    try:
        del _TEST_CFG
    except (ImportError, AttributeError) as e:
        error_type = type(e).__name__
        logger.debug("Exception: <ERROR_TYPE>")
        logger.warning("Exception: <ERROR_TYPE>", exc_info=True)


class _AttrDictConfig(DictConfig):
    """DictConfig-compatible object offering attribute access for mappings.

    Used when OmegaConf's DictConfig attribute access is unavailable in the environment.
    """

    def __init__(self, initial: Mapping[str, Any] | None = None) -> None:
        super().__init__()
        if initial:
            for key, value in initial.items():
                dict.__setitem__(self, key, self._wrap(value))

    @staticmethod
    def _wrap(value: Any) -> Any:
        if isinstance(value, Mapping) and not isinstance(value, DictConfig):
            return _AttrDictConfig(value)
        if isinstance(value, list):
            return [_AttrDictConfig._wrap(item) for item in value]
        if isinstance(value, tuple):
            return tuple(_AttrDictConfig._wrap(item) for item in value)
        return value

    def __getattr__(self, name: str) -> Any:
        if name in self:
            value = dict.__getitem__(self, name)
            wrapped = self._wrap(value)
            dict.__setitem__(self, name, wrapped)
            return wrapped
        raise AttributeError(name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith("_"):
            super().__setattr__(name, value)
        else:
            dict.__setitem__(self, name, self._wrap(value))

    def __setitem__(self, key: Any, value: Any) -> None:
        dict.__setitem__(self, key, self._wrap(value))


def _to_config_object(mapping: Mapping[str, Any]) -> DictConfig:
    """Create a DictConfig, normalizing training payload and ensuring attribute access."""
    normalized = _normalize_training_payload(mapping)
    if _DICTCONFIG_SUPPORTS_ATTR:
        return OmegaConf.create(normalized)
    return _AttrDictConfig(normalized)


def _read_yaml_mapping(path: Path) -> dict[str, Any]:
    """Read YAML file and return a plain Python mapping."""
    with path.open("r", encoding="utf-8") as fh:
        try:
            data = safe_load(fh) or {}
        except MissingPyYAMLError as exc:
            type(exc).__name__
            logger.debug("MissingPyYAMLError: <ERROR_TYPE>")
            raise RuntimeError(
                'PyYAML is required to parse configuration files. Install it via ``pip install "PyYAML>=6.0"`` '  # noqa: E501
                f"before loading {path}."
            ) from exc
    if not isinstance(data, Mapping):
        raise TypeError(f"Expected mapping at {path}, found {type(data).__name__}")
    return dict(data)


def _apply_overrides_to_mapping(
    mapping: dict[str, Any], overrides: Sequence[str]
) -> dict[str, Any]:
    """Apply dotlist overrides directly to a plain mapping (without OmegaConf dependency)."""
    for item in overrides:
        if "=" not in item:
            continue
        key, value = item.split("=", 1)
        try:
            parsed = safe_load(value)
        except MissingPyYAMLError as exc:
            type(exc).__name__
            logger.debug("MissingPyYAMLError: <ERROR_TYPE>")
            raise RuntimeError(
                'YAML overrides require PyYAML. Install it via ``pip install "PyYAML>=6.0"`` '
                "before specifying overrides."
            ) from exc
        target: dict[str, Any] = mapping
        parts = [part for part in key.split(".") if part]
        if not parts:
            continue
        for part in parts[:-1]:
            next_val = target.get(part)
            if not isinstance(next_val, dict):
                next_val = dict(next_val) if isinstance(next_val, Mapping) else {}
            target[part] = next_val
            target = target[part]
        target[parts[-1]] = parsed
    return mapping


@dataclass
class TrainingDefaults:
    seed: int = 42
    lr: float = 1e-3
    batch_size: int = 32
    epochs: int = 3
    logging: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "training": {
                "seed": self.seed,
                "lr": self.lr,
                "batch_size": self.batch_size,
                "epochs": self.epochs,
            },
            "logging": self.logging
            or {
                "enable_tensorboard": False,
                "enable_wandb": False,
                "mlflow_enable": False,
            },
        }


def load_training_cfg(
    *, allow_fallback: bool = True, overrides: Optional[list[str]] = None
) -> DictConfig:
    """Load Hydra config from ``configs/training/base.yaml`` with fallback.

    Resolution order:
    1) If Hydra is available and base config exists, compose via Hydra (resolving overrides).
    2) Else if base YAML exists, load it directly and apply overrides.
    3) Else if allow_fallback, return deterministic defaults (with overrides).
    4) Else raise MissingConfigException.
    """
    overrides = overrides or []

    cfg_dir = _CFG_DIR
    config_file = cfg_dir / f"{_PRIMARY}.yaml"
    hydra_ready = _HYDRA_AVAILABLE

    if hydra_ready and cfg_dir.is_dir() and config_file.is_file():
        # Hydra Compose API: https://hydra.cc/docs/advanced/compose_api/
        with initialize_config_dir(version_base=None, config_dir=str(cfg_dir)):
            hydra_cfg = compose(config_name=_PRIMARY, overrides=overrides)
        container = OmegaConf.to_container(hydra_cfg, resolve=True)
        if not isinstance(container, Mapping):
            raise TypeError("Hydra compose did not return a mapping configuration")
        return _to_config_object(container)

    if config_file.is_file():
        mapping = _read_yaml_mapping(config_file)
        if overrides:
            mapping = _apply_overrides_to_mapping(mapping, overrides)
        return _to_config_object(mapping)

    if not allow_fallback:
        raise MissingConfigException(
            missing_cfg_file=f"{_CFG_DIR}/{_PRIMARY}.yaml",
            message="Config file missing",
        )

    base = TrainingDefaults().to_dict()
    if overrides:
        base = _apply_overrides_to_mapping(base, overrides)
    return _to_config_object(base)


def load_config(*, config_path: str) -> DictConfig:
    """Load a YAML config file into an OmegaConf DictConfig.

    - Preserves the original structure
    - Adds convenient top-level aliases for values in the `training` block (without overwriting)
    - Ensures `training.lr` alias is set from `training.learning_rate` when missing
    """
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file {config_path} not found")
    with path.open("r", encoding="utf-8") as fh:
        try:
            data = safe_load(fh) or {}
        except MissingPyYAMLError as exc:
            type(exc).__name__
            logger.debug("MissingPyYAMLError: <ERROR_TYPE>")
            raise RuntimeError(
                'PyYAML is required to parse configuration files. Install it via ``pip install "PyYAML>=6.0"`` '  # noqa: E501
                f"before loading {config_path}."
            ) from exc

    if not isinstance(data, Mapping):
        raise TypeError("Config must be a mapping")

    # Create as-is, then add convenience keys
    cfg = OmegaConf.create(data)

    # Flatten the training section for convenience keys
    flattened = _flatten_training_section(data)

    # Add flattened keys at top-level if missing (do not overwrite explicit keys)
    for key, value in flattened.items():
        if key not in cfg:
            cfg[key] = value

    # Ensure training.lr alias exists when learning_rate is present
    training_block = cfg.get("training")
    if isinstance(training_block, Mapping) and "lr" not in training_block:
        if "learning_rate" in training_block:
            training_block["lr"] = training_block["learning_rate"]  # type: ignore[index]

    return cfg
