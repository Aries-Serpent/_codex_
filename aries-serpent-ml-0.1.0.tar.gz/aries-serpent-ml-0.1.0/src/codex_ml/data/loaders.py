"""
Dataset loaders for JSONL and CSV with deterministic checksum.

Enhancements (Extended tests support):
- Empty file returns 0 records, no error.
- UTF-8 BOM automatically handled (utf-8-sig).
- Malformed JSONL lines skipped (count in metadata['skipped_malformed']).
- CSV quoted fields preserved (csv.DictReader handles).
- Additional metadata fields: skipped_malformed, empty_file (bool).

Backward compatible (original signatures unchanged).
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import asyncio  # noqa: E402
import codecs  # noqa: E402
import csv  # noqa: E402
import hashlib  # noqa: E402
import json  # noqa: E402
import numbers  # noqa: E402
import os  # noqa: E402
import random  # noqa: E402
from collections.abc import Iterable, Iterator, Mapping, Sequence  # noqa: E402
from dataclasses import dataclass  # noqa: E402
from pathlib import Path  # noqa: E402
from typing import Any, Optional  # noqa: E402

from codex_ml.connectors.base import ConnectorError  # noqa: E402
from codex_ml.connectors.registry import get_connector  # noqa: E402
from codex_ml.data.loader import load_dataset as _load_text_dataset  # noqa: E402
from codex_ml.safety.filters import (  # noqa: E402
    SafetyFilters,
    SafetyResult,
)
from codex_ml.safety.filters import sanitize_output as filter_sanitize_output  # noqa: E402
from codex_ml.safety.filters import sanitize_prompt as filter_sanitize_prompt  # noqa: E402
from codex_ml.utils.error_log import log_error  # noqa: E402

__all__ = [
    "Sample",
    "collect_stats",
    "compute_file_checksum",
    "iter_jsonl",
    "iter_txt",
    "load_csv",
    "load_dataset",
    "load_jsonl",
    "split_indices",
    "stream_paths",
]

_CONNECTOR_URI_PREFIX = "connector://"
_CONNECTOR_CACHE_ENV = "CODEX_CONNECTOR_CACHE_ROOT"
_DEFAULT_CONNECTOR_CACHE = Path.home() / ".codex" / "connector_cache"


@dataclass(frozen=True)
class Sample:
    """Simple container for prompt/completion pairs."""

    prompt: str
    completion: str


def _resolve_connector_cache_root() -> Path:
    override = os.getenv(_CONNECTOR_CACHE_ENV)
    if override:
        try:
            return Path(override).expanduser().resolve()
        except OSError as e:
            type(e).__name__
            logger.debug("OSError: <ERROR_TYPE>")
            logger.warning("OSError: <ERROR_TYPE>", exc_info=True)
            return Path(override).expanduser()
    return _DEFAULT_CONNECTOR_CACHE


def _run_connector_coro(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError as e:
        type(e).__name__
        logger.debug("RuntimeError: <ERROR_TYPE>")
        logger.warning("RuntimeError: <ERROR_TYPE>", exc_info=True)
        return asyncio.run(coro)
    if loop.is_running():  # pragma: no cover - defensive for event-loop environments
        new_loop = asyncio.new_event_loop()
        try:
            return new_loop.run_until_complete(coro)
        finally:
            new_loop.close()
    return loop.run_until_complete(coro)


def _materialize_connector_uri(uri: str, *, cache_root: Path | None = None) -> list[Path]:
    body = uri[len(_CONNECTOR_URI_PREFIX) :]
    if not body:
        raise ValueError("connector URI must include a connector name and path")
    name, _, remote_path = body.partition("/")
    if not name:
        raise ValueError("connector URI missing connector name")
    remote_path = remote_path.lstrip("/")

    try:
        connector = get_connector(name)
    except KeyError as exc:
        type(exc).__name__
        logger.debug("KeyError: <ERROR_TYPE>")
        raise ValueError(f"unknown connector: {name}") from exc

    cache_base = (cache_root or _resolve_connector_cache_root()).expanduser() / name
    cache_base.mkdir(parents=True, exist_ok=True)

    normalized = remote_path or "."
    if normalized.endswith("/"):
        normalized = normalized.rstrip("/") or "."

    try:
        if normalized in {"", "."}:
            remote_files = list(_run_connector_coro(connector.list_files(".")))
        else:
            remote_files = list(_run_connector_coro(connector.list_files(normalized)))
    except ConnectorError as exc:
        type(exc).__name__
        logger.debug("ConnectorError: <ERROR_TYPE>")
        raise RuntimeError(f"connector list failed for {uri}: {exc}") from exc

    if not remote_files:
        raise FileNotFoundError(f"connector path produced no files: {uri}")

    materialized: list[Path] = []
    for remote_file in remote_files:
        relative = remote_file.lstrip("/")
        if not relative:
            continue
        destination = (cache_base / relative).resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            payload = _run_connector_coro(connector.read_file(remote_file))
        except ConnectorError as exc:
            type(exc).__name__
            logger.debug("ConnectorError: <ERROR_TYPE>")
            raise RuntimeError(f"connector read failed for {uri}: {exc}") from exc
        destination.write_bytes(payload)
        materialized.append(destination)

    return materialized


def compute_file_checksum(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def load_jsonl(path: str | Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"JSONL file not found: {p}")
    records: list[dict[str, Any]] = []
    skipped = 0
    with p.open("r", encoding="utf-8-sig") as f:  # utf-8-sig handles BOM
        for line_number, raw in enumerate(f, start=1):
            line = raw.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except (ValueError, TypeError):
                logger.warning("Exception occurred", exc_info=True)
                skipped += 1
                continue
            if not isinstance(obj, dict):
                raise ValueError(
                    f"Line {line_number}: expected JSON object but received {type(obj).__name__}"
                )
            records.append(obj)
    checksum = compute_file_checksum(p)
    meta = {
        "path": str(p),
        "format": "jsonl",
        "num_records": len(records),
        "checksum": checksum,
        "size_bytes": p.stat().st_size,
        "skipped_malformed": skipped,
        "empty_file": p.stat().st_size == 0,
    }
    return records, meta


def _normalize_csv_value(value: Any) -> Any:
    """Normalize raw CSV values to improve backwards compatibility."""

    if isinstance(value, str):
        # ``csv`` does not interpret backslash escaping, so legacy datasets that
        # relied on ``\"`` for embedded quotes would surface them literally.
        # Only apply escape handling to values that actually contain backslash
        # sequences — blanket ``unicode_escape`` corrupts UTF-8 multibyte text.
        if "\\" in value:
            try:
                return codecs.decode(value, "unicode_escape")
            except (IOError, OSError):
                return value.replace('\\"', '"')
        return value
    return value


def load_csv(path: str | Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"CSV file not found: {p}")
    records: list[dict[str, Any]] = []
    skipped_empty = 0
    with p.open("r", encoding="utf-8-sig", newline="") as f:  # utf-8-sig covers BOM
        reader = csv.DictReader(f, escapechar="\\")
        for row in reader:
            cleaned_row = {k: _normalize_csv_value(v) for k, v in row.items() if k is not None}
            if not cleaned_row:
                skipped_empty += 1
                continue
            if all(
                (value is None) or (isinstance(value, str) and not value.strip())
                for value in cleaned_row.values()
            ):
                skipped_empty += 1
                continue
            records.append(cleaned_row)
    checksum = compute_file_checksum(p)
    meta = {
        "path": str(p),
        "format": "csv",
        "num_records": len(records),
        "checksum": checksum,
        "size_bytes": p.stat().st_size,
        "empty_file": len(records) == 0,
        "skipped_empty_rows": skipped_empty,
    }
    return records, meta


def _resolve_split_size(total_size: int, split: float | int, *, name: str) -> int:
    """Translate a fractional or absolute split specification into an integer."""

    if isinstance(split, bool):  # guard bool subclass of int
        raise TypeError(f"{name}_split must be an int or float, received bool")
    if isinstance(split, int):
        if split < 0:
            raise ValueError(f"{name}_split cannot be negative")
        if split > total_size:
            raise ValueError(f"{name}_split={split} exceeds dataset size {total_size}")
        return int(split)
    if not 0.0 <= float(split) <= 1.0:
        raise ValueError(f"{name}_split fraction must be between 0 and 1 inclusive")
    # Use round-half-up via floor(x + 0.5) for stability.
    return int((total_size * float(split)) + 0.5)


def split_indices(
    total_size: int,
    *,
    val_split: float | int = 0.1,
    test_split: float | int = 0.1,
    seed: int | None = None,
) -> tuple[list[int], list[int], list[int]]:
    """Split ``range(total_size)`` into deterministic train/val/test indices.

    Parameters
    ----------
    total_size:
        Number of available samples.
    val_split / test_split:
        Either an absolute count or a fractional value in ``[0, 1]`` specifying
        how many examples should be reserved for validation and test sets.
    seed:
        Optional seed for reproducible shuffling.  ``None`` keeps the global
        random state untouched.
    """

    total = int(total_size)
    if total < 0:
        raise ValueError("total_size must be non-negative")
    if total == 0:
        return [], [], []

    def _is_fractional(value: float | int) -> bool:
        return isinstance(value, numbers.Real) and not isinstance(value, (bool, int))

    if _is_fractional(val_split) and _is_fractional(test_split):
        fraction_total = float(val_split) + float(test_split)
        if fraction_total > 1.0 + 1e-12:
            raise ValueError("Validation and test split fractions must sum to 1 or less")

    val_size = _resolve_split_size(total, val_split, name="val")
    remaining = total - val_size

    test_size = _resolve_split_size(total, test_split, name="test")
    if test_size > remaining:
        if _is_fractional(test_split):
            test_size = remaining
        else:
            raise ValueError("Validation and test splits exceed dataset size")

    if val_size + test_size > total:
        raise ValueError("Validation and test splits exceed dataset size")

    rng = random.Random(seed)  # nosec B311 — non-cryptographic ML sampling/shuffling
    indices = list(range(total))
    rng.shuffle(indices)

    val_indices = indices[:val_size]
    test_indices = indices[val_size : val_size + test_size]
    train_indices = indices[val_size + test_size :]

    # Sort splits for deterministic iteration while preserving random partition
    return sorted(train_indices), sorted(val_indices), sorted(test_indices)


def load_dataset(path: Path | str, *, language: str | None = None) -> list[dict[str, Any]]:
    """Load dataset records and optionally filter by language code."""

    resolved = Path(path)
    suffix = resolved.suffix.lower()

    if suffix in {".jsonl", ".ndjson"}:
        records, _ = load_jsonl(resolved)
    elif suffix == ".csv":
        records, _ = load_csv(resolved)
    else:
        records = [{"text": text} for text in _load_text_dataset(resolved)]

    if language is None:
        return records

    return [row for row in records if str(row.get("language")) == language]


def _validate_sample(obj: dict[str, Any]) -> Sample:
    if not isinstance(obj, dict):
        raise ValueError("Expected JSON object with prompt/completion fields")

    if "prompt" not in obj or "completion" not in obj:
        raise ValueError("Missing prompt/completion fields")

    prompt = obj["prompt"]
    completion = obj["completion"]

    if not isinstance(prompt, str) or not isinstance(completion, str):
        raise ValueError("Prompt and completion must be strings")

    return Sample(prompt=prompt, completion=completion)


def iter_jsonl(path: str | Path) -> Iterator[Sample]:
    """Iterate over a JSONL file yielding :class:`Sample` objects."""

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"JSONL file not found: {p}")

    with p.open("r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            yield _validate_sample(obj)


def iter_txt(path: str | Path, delimiter: str = "\t") -> Iterator[Sample]:
    """Iterate over a TSV (prompt\tcompletion) file."""

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"TXT file not found: {p}")

    with p.open("r", encoding="utf-8-sig") as f:
        for raw in f:
            line = raw.rstrip("\n")
            if not line:
                continue
            parts = line.split(delimiter, maxsplit=1)
            if len(parts) != 2:
                raise ValueError("Expected delimiter separating prompt and completion")
            prompt, completion = parts
            yield Sample(prompt=prompt, completion=completion)


def _should_generate_manifest(cfg: Any | None) -> bool:
    """Return ``True`` when either data or dataset configs enable manifests."""

    if cfg is None:
        return False

    dataset_cfg = getattr(cfg, "dataset", None)
    data_cfg = _coerce_data_cfg(cfg)

    for candidate in (dataset_cfg, data_cfg):
        if candidate is None:
            continue

        if isinstance(candidate, Mapping):
            if candidate.get("generate_manifest"):
                return True
        else:
            if getattr(candidate, "generate_manifest", False):
                return True

    return False


def _write_manifest(path: Path, fmt: str, count: int) -> None:
    manifest_data = {
        "path": str(path),
        "format": fmt,
        "num_records": count,
        "checksum": compute_file_checksum(path),
        "size_bytes": path.stat().st_size,
    }
    manifest_path = Path(f"{path}.manifest.json")
    manifest_path.write_text(json.dumps(manifest_data, indent=2), encoding="utf-8")


def _coerce_data_cfg(cfg: Any | None) -> Any | None:
    if cfg is None:
        return None
    data_cfg = getattr(cfg, "data", None)
    return data_cfg if data_cfg is not None else cfg


def _coerce_filters(value: Any) -> SafetyFilters | None:
    """Best-effort conversion for legacy ``safety_filters`` arguments."""

    if isinstance(value, SafetyFilters):
        return value

    if value is None or value is False:
        return None

    if value is True:
        try:
            return SafetyFilters.from_defaults()
        except (IOError, OSError):  # pragma: no cover - defensive
            return None

    if isinstance(value, (str, Path)):
        try:
            return SafetyFilters.from_policy_file(value)
        except (IOError, OSError):  # pragma: no cover - defensive
            return None

    if isinstance(value, Mapping):
        enabled = value.get("enabled")
        if enabled is False:
            return None

        policy_path = value.get("policy_path") or value.get("path")
        if policy_path:
            try:
                return SafetyFilters.from_policy_file(policy_path)
            except (IOError, OSError):  # pragma: no cover - defensive
                return None

        if enabled:
            try:
                return SafetyFilters.from_defaults()
            except Exception:  # pragma: no cover - defensive
                return None

    return None


def _resolve_safety_filters(
    cfg: Any | None,
    provided_filters: SafetyFilters | Any | None,
) -> SafetyFilters | None:
    converted = _coerce_filters(provided_filters)
    if converted is not None:
        return converted

    data_cfg = _coerce_data_cfg(cfg)
    if data_cfg is None:
        return None

    enabled = getattr(data_cfg, "safety_filter_enabled", None)
    if enabled is None:
        enabled = getattr(data_cfg, "safety_filter", None)
    if not enabled:
        return None

    policy_path = None
    for attr in ("safety_filter_policy_path", "safety_filter_policy", "policy_path"):
        value = getattr(data_cfg, attr, None)
        if value:
            policy_path = value
            break

    if policy_path:
        filters = _coerce_filters(policy_path)
        if filters is not None:
            return filters

    enabled = bool(enabled)
    if enabled:
        return _coerce_filters(True)

    return None


def _infer_format(path: Path, explicit: Optional[str]) -> str:
    if explicit and explicit.lower() not in {"auto", "default"}:
        return explicit.lower()

    suffix = path.suffix.lower()
    if suffix in {".jsonl", ".json"}:
        return "jsonl"
    if suffix in {".txt", ".tsv"}:
        return "txt"
    # Default to JSONL for backwards compatibility with legacy callers.
    return "jsonl"


def _log_safety_decision(path: Path, prompt: SafetyResult, completion: SafetyResult) -> None:
    try:
        context = json.dumps(
            {
                "path": str(path),
                "prompt_allowed": prompt.allowed,
                "prompt_blocked_rules": list(prompt.blocked_rules),
                "completion_allowed": completion.allowed,
                "completion_blocked_rules": list(completion.blocked_rules),
            },
            ensure_ascii=False,
        )
        log_error("data.safety", "dataset sample sanitized", context)
    except (IOError, OSError):
        logger.warning("Exception occurred", exc_info=True)
        # Logging should not interfere with dataset streaming.


def _apply_safety(sample: Sample, *, path: Path, filters: SafetyFilters | None) -> Sample:
    if filters is None:
        return sample

    prompt_decision = filter_sanitize_prompt(sample.prompt, filters=filters)
    completion_decision = filter_sanitize_output(sample.completion, filters=filters)

    if (
        prompt_decision.sanitized_text != sample.prompt
        or completion_decision.sanitized_text != sample.completion
    ):
        _log_safety_decision(path, prompt_decision, completion_decision)

    return Sample(
        prompt=prompt_decision.sanitized_text,
        completion=completion_decision.sanitized_text,
    )


def stream_paths(
    paths: Sequence[str | Path],
    fmt: str | None = None,
    *,
    max_samples: int | None = None,
    seed: int | None = None,
    num_workers: int | None = None,
    prefetch: int | None = None,
    delimiter: str = "\t",
    safety_filters: SafetyFilters | None = None,
    cfg: Any | None = None,
) -> Iterator[Sample]:
    """Stream samples from one or more dataset paths.

    The signature intentionally preserves the historical keyword arguments used
    by downstream tooling (``seed``, ``num_workers``, ``prefetch``,
    ``safety_filters``) even if this implementation processes files
    sequentially.  Callers depending on deterministic shuffling and safety
    filtering continue to function without modification.
    """

    del num_workers, prefetch  # preserved for backwards compatibility

    generated = 0
    generate_manifest = _should_generate_manifest(cfg)
    active_filters = _resolve_safety_filters(cfg, safety_filters)

    expanded_paths: list[Path] = []
    for entry in paths:
        if isinstance(entry, (str, Path)):
            raw = os.fspath(entry)
            if raw.startswith(_CONNECTOR_URI_PREFIX):
                expanded_paths.extend(_materialize_connector_uri(raw))
                continue
        expanded_paths.append(Path(entry))

    ordered_paths = expanded_paths
    if seed is not None:
        rng = random.Random(seed)  # nosec B311 — non-cryptographic ML sampling/shuffling
        rng.shuffle(ordered_paths)

    for path in ordered_paths:
        resolved_fmt = _infer_format(path, fmt)

        if resolved_fmt == "jsonl":
            iterator: Iterable[Sample] = iter_jsonl(path)
        elif resolved_fmt == "txt":
            iterator = iter_txt(path, delimiter=delimiter)
        else:
            raise ValueError(f"Unsupported dataset format: {resolved_fmt}")

        if generate_manifest:
            samples = list(iterator)
            _write_manifest(path, resolved_fmt, len(samples))
            iterable: Iterable[Sample] = samples
        else:
            iterable = iterator

        for sample in iterable:
            sanitized = _apply_safety(sample, path=path, filters=active_filters)
            yield sanitized
            generated += 1
            if max_samples is not None and generated >= max_samples:
                return


def collect_stats(
    samples: Iterable[Sample], *, sample_limit: int | None = None
) -> dict[str, float]:
    total = 0
    total_prompt_len = 0
    total_completion_len = 0
    total_prompt_tokens = 0
    total_completion_tokens = 0

    for sample in samples:
        if sample_limit is not None and total >= sample_limit:
            break
        total += 1
        prompt = sample.prompt
        completion = sample.completion
        total_prompt_len += len(prompt)
        total_completion_len += len(completion)
        total_prompt_tokens += len(prompt.split())
        total_completion_tokens += len(completion.split())

    if total == 0:
        return {
            "samples": 0,
            "avg_prompt_len": 0.0,
            "avg_completion_len": 0.0,
            "avg_prompt_tokens": 0.0,
            "avg_completion_tokens": 0.0,
        }

    return {
        "samples": total,
        "avg_prompt_len": total_prompt_len / total,
        "avg_completion_len": total_completion_len / total,
        "avg_prompt_tokens": total_prompt_tokens / total,
        "avg_completion_tokens": total_completion_tokens / total,
    }
