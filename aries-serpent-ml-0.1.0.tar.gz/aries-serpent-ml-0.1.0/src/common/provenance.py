"""
Provenance Module

This module provides functionality for provenance.

Usage:
    from common.provenance import ...

Classes:
    [To be documented]

Functions:
    [To be documented]

Author: Codex Team
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

try:
    from omegaconf import DictConfig, OmegaConf

    def _to_container(cfg: DictConfig) -> dict[str, Any]:
        return OmegaConf.to_container(cfg, resolve=True)

except ImportError:  # pragma: no cover - fallback for optional dependency
    DictConfig = dict  # type: ignore[misc,assignment]

    def _to_container(cfg: DictConfig) -> dict[str, Any]:
        return cfg


@dataclass
class DVCStageProvenance:
    stage: str
    outs: dict[str, dict[str, Any]]
    deps: dict[str, dict[str, Any]]
    params: dict[str, Any]


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _config_fingerprint(cfg: DictConfig) -> str:
    container = _to_container(cfg)
    yml = yaml.safe_dump(container, sort_keys=True)
    return _sha256_bytes(yml.encode("utf-8"))


def _read_dvc_lock(lock_path: Path) -> dict[str, Any]:
    if not lock_path.exists():
        return {}
    with lock_path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _deep_update_dict(target: dict[str, Any], new: dict[str, Any]) -> None:
    for key, value in new.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            _deep_update_dict(target[key], value)
        else:
            target[key] = value


def collect_dvc_stage(lock: dict[str, Any], stage: str = "prepare") -> DVCStageProvenance | None:
    stages = lock.get("stages") or {}
    s = stages.get(stage)
    if not s:
        return None
    outs_list = s.get("outs") or []
    deps_list = s.get("deps") or []
    raw_params = s.get("params") or {}

    params_by_file: dict[str, dict[str, Any]] = {}
    if isinstance(raw_params, dict):
        params_by_file = {
            key: dict(value) for key, value in raw_params.items() if isinstance(value, dict)
        }
    elif isinstance(raw_params, list):
        for entry in raw_params:
            if not isinstance(entry, dict):
                continue
            for filename, value in entry.items():
                if not isinstance(value, dict):
                    continue
                if filename not in params_by_file:
                    params_by_file[filename] = dict(value)
                else:
                    _deep_update_dict(params_by_file[filename], value)

    params = params_by_file.get("params.yaml", {})
    outs = {
        o["path"]: {k: v for k, v in o.items() if k != "path"} for o in outs_list if "path" in o
    }
    deps = {
        d["path"]: {k: v for k, v in d.items() if k != "path"} for d in deps_list if "path" in d
    }
    return DVCStageProvenance(stage=stage, outs=outs, deps=deps, params=params)


def _default_project_root() -> Path:
    """Return a writable default root, falling back to the current working directory."""

    return Path.cwd()


def _resolve_out_dir(project_root: Path, out_dir: Path | None) -> Path:
    if out_dir is None:
        return project_root / ".codex"
    if out_dir.is_absolute():
        return out_dir
    return project_root / out_dir


def write_provenance(
    cfg: DictConfig,
    stage: str = "prepare",
    out_dir: Path | None = None,
    project_root: Path | None = None,
) -> Path:
    project_root = project_root or _default_project_root()
    resolved_out_dir = _resolve_out_dir(project_root, out_dir)
    resolved_out_dir.mkdir(parents=True, exist_ok=True)
    lock = _read_dvc_lock(project_root / "dvc.lock")
    dvc_info: dict[str, Any] | None = None
    if lock:
        st = collect_dvc_stage(lock, stage=stage)
        if st:
            dvc_info = asdict(st)

    data = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "git_commit": os.environ.get("GIT_COMMIT", ""),
        "config_fingerprint_sha256": _config_fingerprint(cfg),
        "dvc": dvc_info,
    }
    out_path = resolved_out_dir / "provenance.json"
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    return out_path
