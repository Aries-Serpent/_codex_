"""Server-side adapter implementations."""
