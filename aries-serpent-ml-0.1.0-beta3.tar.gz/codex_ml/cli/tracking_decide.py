"""
Tracking Decide Module

This module provides functionality for tracking decide.

Usage:
    from cli.tracking_decide import ...

Classes:
    [To be documented]

Functions:
    [To be documented]

Author: Codex Team
"""

from __future__ import annotations

import json
import os
from collections.abc import Iterable, Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import asdict
from typing import Annotated, Optional

from codex_ml.codex_structured_logging import (
    ArgparseJSONParser,
    capture_exceptions,
    init_json_logging,
    log_event,
    run_cmd,
)
from codex_ml.tracking.mlflow_guard import (
    GuardDecision,
    bootstrap_offline_tracking_decision,
)

_ = (ArgparseJSONParser, run_cmd)

try:  # Optional dependency used for the public CLI.
    import typer
except ModuleNotFoundError:  # pragma: no cover - Typer not installed
    typer = None
else:  # pragma: no cover - namespace stub without Typer attributes
    if not hasattr(typer, "Typer"):
        typer = None


def _parse_env_overrides(values: Sequence[str]) -> dict[str, Optional[str]]:
    overrides: dict[str, Optional[str]] = {}
    for raw in values:
        if "=" not in raw:
            overrides[raw] = None
            continue
        key, value = raw.split("=", 1)
        overrides[key.strip()] = value if value != "" else None
    return overrides


@contextmanager
def _patched_environ(updates: Mapping[str, Optional[str]]) -> Iterator[None]:
    original: dict[str, str] = {}
    removed: set[str] = set()
    try:
        for key, value in updates.items():
            if key in os.environ:
                original[key] = os.environ[key]
            else:
                removed.add(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        yield
    finally:
        for key in updates:
            if key in original:
                os.environ[key] = original[key]
            elif key in removed:
                os.environ.pop(key, None)
            elif key in os.environ:
                os.environ.pop(key)


def decide(
    uri: Optional[str] = None,
    *,
    force: bool = False,
    env_overrides: Optional[Mapping[str, Optional[str]]] = None,
) -> GuardDecision:
    """Return the guard decision after applying ``env_overrides`` and ``uri``."""

    overrides: dict[str, Optional[str]] = dict(env_overrides or {})
    if uri is not None:
        overrides["MLFLOW_TRACKING_URI"] = uri
    with _patched_environ(overrides):
        return bootstrap_offline_tracking_decision(force=force, requested_uri=uri)


if typer is not None:  # pragma: no cover - exercised via CLI tests
    app = typer.Typer(help="Evaluate MLflow tracking guard decisions.")

    @app.command("decide")
    def decide_cmd(
        uri: Annotated[
            Optional[str],
            typer.Option(
                None,
                "--uri",
                help="Requested tracking URI (defaults to environment value).",
            ),
        ] = None,
        env: Annotated[
            Optional[Iterable[str]],
            typer.Option(
                None,
                "--env",
                help="Additional environment overrides as KEY=VALUE pairs.",
            ),
        ] = None,
        force: Annotated[
            bool,
            typer.Option(
                False,
                "--force",
                help="Force guard evaluation even if environment already configured.",
            ),
        ] = False,
        pretty: Annotated[
            bool,
            typer.Option(
                True,
                "--pretty/--no-pretty",
                help="Pretty-print the decision JSON.",
            ),
        ] = True,
    ) -> None:
        """Print the guard decision as JSON."""

        env_overrides = _parse_env_overrides(list(env or ()))
        try:
            decision = decide(uri, force=force, env_overrides=env_overrides)
        except (ValueError, TypeError) as exc:  # pragma: no cover - defensive fallback
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(code=1) from exc
        payload = asdict(decision)
        text = json.dumps(payload, indent=2 if pretty else None, sort_keys=True)
        typer.echo(text)

else:  # pragma: no cover - Typer missing
    app = None


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Entry point for ``python -m codex_ml.cli.tracking_decide``."""

    logger = init_json_logging()
    arg_list = list(argv) if argv is not None else []
    with capture_exceptions(logger):
        log_event(logger, "cli.start", prog="tracking-decide", args=arg_list)
        if typer is None:
            log_event(
                logger,
                "cli.finish",
                prog="tracking-decide",
                status="error",
                exit_code=1,
            )
            raise SystemExit(
                "Typer is required to use codex_ml.cli.tracking_decide; install it with "
                "`pip install typer`."
            )
        try:
            app.main(prog_name="codex-tracking", args=arg_list, standalone_mode=False)
        except typer.Exit as exc:
            exit_code = int(exc.exit_code or 0)
        else:
            exit_code = 0
        status = "ok" if exit_code == 0 else "error"
        log_event(
            logger,
            "cli.finish",
            prog="tracking-decide",
            status=status,
            exit_code=exit_code,
        )
        return exit_code


__all__ = ["app", "decide", "main"]
