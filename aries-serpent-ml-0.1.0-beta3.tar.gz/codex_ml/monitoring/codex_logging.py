"""Unified optional logging and hardware sampling utilities."""

from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import re
import shutil
import subprocess  # used with validated executable path
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional
from urllib.parse import urlparse

from codex_ml.monitoring._logger_types import CodexLoggers, TelemetryComponentStatus
from codex_ml.monitoring.prometheus import fallback_status as prometheus_fallback_status
from codex_ml.monitoring.system_metrics import sampler_status
from codex_ml.tracking.mlflow_guard import bootstrap_offline_tracking
from codex.logging.adapter import LoggerAdapter, NullLogger, get_default_logger

logger = logging.getLogger(__name__)

if TYPE_CHECKING:  # pragma: no cover - typing only
    pass

# Optional dependencies -----------------------------------------------------
try:  # pragma: no cover - optional
    import torch.utils.tensorboard as _tb

    SummaryWriter = _tb.SummaryWriter
except (IOError, OSError):  # pragma: no cover - tensorboard not installed
    SummaryWriter = None


try:  # pragma: no cover - optional
    import wandb
except (IOError, OSError):  # pragma: no cover - wandb not installed
    wandb = None

try:  # pragma: no cover - optional
    import mlflow
except (IOError, OSError):  # pragma: no cover - mlflow not installed
    mlflow = None


def _ensure_local_mlflow_tracking_uri_default() -> None:
    """Set a local MLflow file store when no tracking URI is configured."""

    bootstrap_offline_tracking(force=True, requested_uri=os.getenv("MLFLOW_TRACKING_URI"))


try:  # pragma: no cover - optional
    import psutil
except (ConnectionError, TimeoutError):  # pragma: no cover - psutil not installed
    psutil = None

if os.getenv("CODEX_DISABLE_NVML") == "1":  # pragma: no cover - env guard
    pynvml = None
else:
    try:  # pragma: no cover - optional
        import pynvml  # type: ignore
    except (ImportError, AttributeError):  # pragma: no cover - nvml not installed
        pynvml = None

try:  # pragma: no cover - optional
    import torch
except (IOError, OSError):  # pragma: no cover - torch not installed
    torch = None  # type: ignore[assignment]

SummaryWriter = None


try:  # pragma: no cover - optional
    if torch is not None:
        SummaryWriter = torch.utils.tensorboard.SummaryWriter


except (IOError, OSError):  # pragma: no cover - tensorboard not installed
    get_default_logger().debug("Suppressed exception in handler", exc_info=True)
_ensure_local_mlflow_tracking_uri_default()


def _mlflow_offline_enabled() -> bool:
    """Return ``True`` when MLflow tracking is explicitly enabled for offline use."""

    return os.getenv("MLFLOW_OFFLINE", "0") == "1"


def _maybe_init_mlflow_offline(tracking_uri: str | None = None) -> None:
    """Configure MLflow with a local default and optional offline tracking.

    When no tracking URI is configured we set ``file:./artifacts/mlruns`` so
    that local runs never hit remote services accidentally. If the environment
    flag ``MLFLOW_OFFLINE=1`` is provided we additionally coerce the tracking
    URI to a ``file:`` scheme and attempt to start offline tracking.
    """

    _ensure_local_mlflow_tracking_uri_default()
    if mlflow is None or not _mlflow_offline_enabled():
        return
    try:
        uri = _resolve_mlflow_tracking_uri(tracking_uri)
    except (ValueError, TypeError, RuntimeError):  # pragma: no cover - defensive guard
        return
    try:  # pragma: no cover - optional dependency
        mlflow.set_tracking_uri(uri)
    except (IOError, OSError):
        get_default_logger().warning("Exception occurred", exc_info=True)
        # Non-fatal: fall back to MLflow defaults while keeping tracking disabled.


def _resolve_mlflow_tracking_uri(candidate: str | None) -> str:
    """Resolve ``candidate`` to a local ``file:`` URI suitable for offline tracking."""

    if candidate:
        parsed = urlparse(candidate)
        if parsed.scheme and parsed.scheme != "file" and _mlflow_offline_enabled():
            raise ValueError(
                "MLflow tracking URI must use file:// scheme when offline guard enabled"
            )
        return candidate
    base = os.getenv("MLFLOW_TRACKING_URI") or "file:./artifacts/mlruns"
    if base.startswith("file:"):
        return base
    if "://" in base:
        parsed = urlparse(base)
        if parsed.scheme and parsed.scheme != "file" and _mlflow_offline_enabled():
            raise ValueError(
                "MLflow tracking URI must use file:// scheme when offline guard enabled"
            )
        return base
    return base


def _start_mlflow_offline(
    tracking_uri: str | None, experiment: str | None
) -> tuple[bool, Optional[str]]:
    """Attempt to start an MLflow run using offline-safe defaults."""

    if mlflow is None:
        return False, "not-installed"
    if not _mlflow_offline_enabled():
        return False, "offline-env-required"
    try:
        uri = _resolve_mlflow_tracking_uri(tracking_uri)
    except Exception as exc:  # pragma: no cover - defensive
        return False, f"uri-error:{exc}"
    _maybe_init_mlflow_offline(uri)
    try:  # pragma: no cover - mlflow optional
        exp_name = experiment or os.getenv("MLFLOW_EXPERIMENT", "codex")
        mlflow.set_experiment(exp_name)
        mlflow.start_run()
        return True, None
    except (ValueError, TypeError) as exc:  # pragma: no cover - optional
        return False, f"error:{exc.__class__.__name__}"


def init_logger(name: str = __name__) -> logging.Logger:
    """Return a standard library logger with JSON logging guardrails."""

    _maybe_init_mlflow_offline()
    logger_obj = logging.getLogger(name)
    if logger_obj.handlers:
        return logger_obj

    handler = logging.StreamHandler()
    if os.getenv("CODEX_JSON_LOGGING", "0") == "1":
        handler.setFormatter(
            logging.Formatter(
                fmt=json.dumps(
                    {
                        "time": "%(asctime)s",
                        "level": "%(levelname)s",
                        "name": "%(name)s",
                        "msg": "%(message)s",
                    }
                )
            )
        )
    else:
        fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        handler.setFormatter(logging.Formatter(fmt))
    logger_obj.addHandler(handler)
    logger_obj.setLevel(logging.INFO)
    logger_obj.propagate = False
    return logger_obj


_PSUTIL_WARN_KEY = "psutil_missing"
_TELEMETRY_BANNER_WARN_KEY = "telemetry_banner_emitted"
_LOGGER_WARNING_CONTEXTS: set[str] = set()

MAX_LOG_BYTES = int(os.environ.get("CODEX_ML_MAX_LOG_BYTES", 5 * 1024 * 1024))
_LOG_SAFETY_FILTERS = None
_LOG_SAFETY_CFG = None
_SENSITIVE_LOG_KEYS = (
    "text",
    "prompt",
    "completion",
    "input",
    "output",
    "input_text",
    "output_text",
)

_AWS_SECRET_PATTERN = "AWS_SECRET_ACCESS_" + "KEY"  # pragma: allowlist secret

_SECRET_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"(?i)(sk-[A-Za-z0-9]{10,})"),
    re.compile(r"(?i)(AKIA[0-9A-Z]{16})"),
    re.compile(r"(?i)(ASIA[0-9A-Z]{16})"),
    re.compile(rf"(?i)({_AWS_SECRET_PATTERN}\s*=\s*[A-Za-z0-9/+=]{{40}})"),
    re.compile(r"(?i)(AIza[0-9A-Za-z\-_]{35})"),
    re.compile(r"(?i)(ghp_[A-Za-z0-9]{36})"),
    re.compile(r"(?i)(xox[baprs]-[A-Za-z0-9\-]{10,})"),
)


def _apply_secret_patterns(value: str) -> str:
    if os.getenv("DISABLE_SECRET_FILTER", "0") == "1":
        return value
    masked = value
    for pattern in _SECRET_PATTERNS:
        masked = pattern.sub("[SECRET]", masked)
    return masked


def _try_git_commit() -> str | None:
    """Resolve the current git commit safely without shell usage."""

    git = shutil.which("git")
    if not git:
        return None
    try:
        root = Path(__file__).resolve().parents[3]
        return subprocess.check_output(  # nosec B603: static argv, shell disabled
            [git, "-C", str(root), "rev-parse", "HEAD"],
            text=True,
        ).strip()
    except (IOError, OSError) as exc:  # pragma: no cover - diagnostic only
        get_default_logger().debug("git commit detection failed", exc_info=exc)
        return None


_GIT_COMMIT = "unknown"
_commit_candidate = _try_git_commit()
if _commit_candidate:
    _GIT_COMMIT = _commit_candidate


def _emit_degradation_banner(loggers: CodexLoggers) -> CodexLoggers:
    issues: list[str] = []

    for status in loggers.degradations:
        if status.available:
            continue
        detail = f" ({status.detail})" if status.detail else ""
        issues.append(f"{status.name}{detail}")

    system_state = loggers.system_status
    if system_state is None:
        system_state = sampler_status()
        loggers.system_status = system_state
    if system_state.missing_dependencies:
        missing = ", ".join(system_state.missing_dependencies)
        note_suffix = ""
        if getattr(system_state, "notes", None):
            note_suffix = f" ({', '.join(system_state.notes)})"
        issues.append(f"system-metrics missing: {missing}{note_suffix}")
    elif system_state.degraded:
        note_suffix = ""
        if getattr(system_state, "notes", None):
            note_suffix = f" ({', '.join(system_state.notes)})"
        issues.append(f"system-metrics degraded{note_suffix}")

    prom = loggers.prometheus
    if prom is None:
        prom = prometheus_fallback_status()
        loggers.prometheus = prom
    prom_active, prom_path, prom_reason = prom
    if prom_active:
        detail = f" -> {prom_path}" if prom_path else ""
        if prom_reason:
            detail += f" ({prom_reason})"
        issues.append(f"prometheus fallback{detail}")

    if not (loggers.tb or loggers.wb or loggers.mlflow_active or loggers.gpu):
        issues.append("no telemetry sinks enabled")

    if issues and _TELEMETRY_BANNER_WARN_KEY not in _LOGGER_WARNING_CONTEXTS:
        get_default_logger().error(f"[telemetry] degraded: {'; '.join(issues)}")
        _LOGGER_WARNING_CONTEXTS.add(_TELEMETRY_BANNER_WARN_KEY)
    return loggers


def _get_safety_cfg() -> Any:
    """Return a cached SafetyConfig instance for log redaction."""

    global _LOG_SAFETY_CFG
    if _LOG_SAFETY_CFG is None:
        try:
            from codex_ml.safety import SafetyConfig

            _LOG_SAFETY_CFG = SafetyConfig()
        except (ImportError, AttributeError):  # pragma: no cover - safety module optional
            _LOG_SAFETY_CFG = None
    return _LOG_SAFETY_CFG


def _get_safety_filters() -> Any:
    """Return cached SafetyFilters instance when available."""

    global _LOG_SAFETY_FILTERS
    if _LOG_SAFETY_FILTERS is None:
        try:
            from codex_ml.safety import SafetyFilters

            _LOG_SAFETY_FILTERS = SafetyFilters.from_defaults()
        except (IOError, OSError):  # pragma: no cover - optional dependency
            _LOG_SAFETY_FILTERS = None
    return _LOG_SAFETY_FILTERS


def _maybe_rotate_log(path: Path) -> None:
    """Rotate ``path`` if it exceeds :data:`MAX_LOG_BYTES`."""

    if MAX_LOG_BYTES <= 0 or not path.exists():
        return
    try:
        size = path.stat().st_size
    except OSError:  # pragma: no cover - filesystem edge cases
        return
    if size < MAX_LOG_BYTES:
        return
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    rotated = path.with_name(f"{path.name}.{timestamp}")
    try:
        os.replace(path, rotated)
    except OSError:  # pragma: no cover - rotation best-effort
        return
    get_default_logger().info("Log file rotated: %s -> %s", path, rotated)


def _redact_sensitive_fields(record: dict[str, Any]) -> None:
    """Redact sensitive text fields before persisting NDJSON payloads."""

    cfg = _get_safety_cfg()
    filters = _get_safety_filters()
    redactions = record.get("redactions")
    if not isinstance(redactions, dict):
        redactions = {}
    from codex_ml.safety import sanitize_output  # local import to avoid cycles

    for key in _SENSITIVE_LOG_KEYS:
        value = record.get(key)
        if not isinstance(value, str) or not value:
            continue
        updated = value
        field_meta: dict[str, Any] = {}
        if filters is not None:
            try:
                result = filters.sanitize(value, stage=f"log.{key}")
            except Exception:  # pragma: no cover - filters best-effort
                result = None
            else:
                updated = result.sanitized_text
                matches = getattr(result, "matches", ())
                if matches:
                    rule_ids = sorted({m.rule_id for m in matches if getattr(m, "rule_id", None)})
                    if rule_ids:
                        field_meta["rules"] = rule_ids
                        field_meta["match_count"] = len(matches)
        safe = sanitize_output(updated, cfg)
        updated = safe.get("text", updated)
        redacted_counts = safe.get("redactions", {})
        for label, count in redacted_counts.items():
            if count:
                field_meta[label] = field_meta.get(label, 0) + int(count)
        record[key] = updated
        if field_meta:
            redactions[key] = field_meta
        elif key in redactions:
            redactions.pop(key, None)
    if redactions:
        record["redactions"] = redactions
    elif "redactions" in record:
        record.pop("redactions", None)


def init_telemetry(profile: str = "min") -> CodexLoggers:
    """Initialise telemetry components based on profile.

    When ``profile`` is "full" we attempt NVML-based GPU metrics but fall back
    to psutil-only sampling if NVML is unavailable.

    Parameters
    ----------
    profile : {"off", "min", "full"}
        Selects which logging backends to enable.

    Returns
    -------
    CodexLoggers
        Handles/flags for enabled logging backends and GPU telemetry.
    """
    tb = wb = mlf = False
    gpu = False
    if profile is None:
        profile = "min"

    # Default to minimal profile: enable TensorBoard and MLflow, disable W&B and GPU.
    if profile == "min":
        tb = True
        mlf = True
    elif profile == "full":
        tb = wb = mlf = True
        gpu = True

    # Try to initialise NVML when GPU telemetry requested; gracefully disable on failure.
    if gpu:
        try:  # pragma: no cover - depends on NVML
            import pynvml as _nv

            _nv.nvmlInit()
            # If init succeeds, immediately shutdown to avoid leaking handles; we sample later.
            _nv.nvmlShutdown()
        except (IOError, OSError):
            get_default_logger().warning("Exception occurred", exc_info=True)
            gpu = False

    components: list[TelemetryComponentStatus] = []
    tb_available = bool(tb and SummaryWriter is not None)
    if tb:
        components.append(
            TelemetryComponentStatus(
                "tensorboard", tb_available, None if tb_available else "not-installed"
            )
        )
    mlflow_available = False
    mlflow_detail = None
    if mlf:
        _maybe_init_mlflow_offline()
        if mlflow is None:
            mlflow_detail = "not-installed"
        elif not _mlflow_offline_enabled():
            mlflow_detail = "offline-env-required"
        else:
            _maybe_init_mlflow_offline(None)
            mlflow_available = True
    if mlf:
        components.append(
            TelemetryComponentStatus(
                "mlflow",
                mlflow_available,
                mlflow_detail,
            )
        )
    wandb_available = bool(wb and wandb is not None)
    if wb:
        components.append(
            TelemetryComponentStatus(
                "wandb", wandb_available, None if wandb_available else "not-installed"
            )
        )

    loggers = CodexLoggers(
        tb=True if tb_available else None,
        wb=True if wandb_available else None,
        mlflow_active=mlflow_available,
        gpu=gpu,
        degradations=tuple(components),
    )
    loggers.system_status = sampler_status()
    loggers.prometheus = prometheus_fallback_status()
    return _emit_degradation_banner(loggers)


# ---------------------------------------------------------------------------
# Argparse integration


def _codex_patch_argparse(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """Add monitoring flags to ``parser``."""

    add = parser.add_argument
    add("--enable-wandb", action="store_true", help="Enable Weights & Biases logging.")
    add("--mlflow-enable", action="store_true", help="Enable MLflow tracking.")
    add(
        "--mlflow-tracking-uri",
        type=str,
        default="",
        help="MLflow tracking URI (defaults to local ./mlruns).",
    )
    add(
        "--mlflow-experiment",
        type=str,
        default="codex",
        help="MLflow experiment name.",
    )
    add(
        "--tb-logdir",
        type=str,
        default="./runs",
        help="TensorBoard log directory.",
    )
    add("--wandb-project", type=str, default="codex-offline", help="W&B project name.")
    return parser


# ---------------------------------------------------------------------------
# Bootstrap helpers


def _codex_logging_bootstrap(args: argparse.Namespace) -> CodexLoggers:
    """Initialise enabled loggers based on ``args`` or Hydra config."""

    cfg = getattr(args, "hydra_cfg", None) or {}

    _maybe_init_mlflow_offline()

    if cfg:
        component_statuses: list[TelemetryComponentStatus] = []

        tb_handle = None
        tb_detail = None
        tb_cfg = cfg.get("tensorboard", {})
        if tb_cfg.get("enable"):
            if SummaryWriter is None:
                tb_detail = "not-installed"
            else:
                logdir = tb_cfg.get("logdir", "runs/tb")
                try:  # pragma: no cover - depends on tensorboard install
                    os.makedirs(logdir, exist_ok=True)
                    tb_handle = SummaryWriter(logdir)
                except (IOError, OSError) as exc:  # pragma: no cover - optional
                    tb_detail = f"error:{exc.__class__.__name__}"
            component_statuses.append(
                TelemetryComponentStatus("tensorboard", tb_handle is not None, tb_detail)
            )

        wb_handle = None
        wb_detail = None
        if cfg.get("wandb", {}).get("enable"):
            if wandb is None:
                wb_detail = "not-installed"
            else:
                try:  # pragma: no cover - wandb optional
                    project = cfg["wandb"].get("project", "codex")
                    mode = cfg["wandb"].get("mode", "offline")
                    wb_handle = wandb.init(project=project, mode=mode)
                except Exception as exc:  # pragma: no cover - optional
                    wb_detail = f"error:{exc.__class__.__name__}"
                    wb_handle = None
            component_statuses.append(
                TelemetryComponentStatus("wandb", wb_handle is not None, wb_detail)
            )

        mlflow_active = False
        mlflow_detail = None
        if cfg.get("mlflow", {}).get("enable"):
            if os.getenv("MLFLOW_OFFLINE") is None:
                os.environ["MLFLOW_OFFLINE"] = "1"
            tracking_uri = cfg["mlflow"].get("tracking_uri")
            if tracking_uri and mlflow is not None:
                os.environ["MLFLOW_TRACKING_URI"] = tracking_uri
                try:
                    mlflow.set_tracking_uri(tracking_uri)
                except (ValueError, TypeError, RuntimeError) as e:
                    type(e).__name__
                    get_default_logger().debug("Exception: <ERROR_TYPE>")
                    get_default_logger().warning("Exception: <ERROR_TYPE>", exc_info=True)
            mlflow_active, mlflow_detail = _start_mlflow_offline(
                cfg["mlflow"].get("tracking_uri"),
                cfg["mlflow"].get("experiment"),
            )
            if mlflow_active and tracking_uri and mlflow is not None:
                try:
                    mlflow.set_tracking_uri(tracking_uri)
                except (ValueError, TypeError, RuntimeError) as e:
                    type(e).__name__
                    get_default_logger().debug("Exception: <ERROR_TYPE>")
                    get_default_logger().warning("Exception: <ERROR_TYPE>", exc_info=True)
        component_statuses.append(TelemetryComponentStatus("mlflow", mlflow_active, mlflow_detail))

        loggers = CodexLoggers(
            tb=tb_handle,
            wb=wb_handle,
            mlflow_active=mlflow_active,
            degradations=tuple(component_statuses),
        )
        loggers.system_status = sampler_status()
        loggers.prometheus = prometheus_fallback_status()
        return _emit_degradation_banner(loggers)

    # Fallback to argparse flags
    component_statuses: list[TelemetryComponentStatus] = []  # type: ignore[no-redef]

    logdir = getattr(args, "tb_logdir", "") or "./runs"
    tb_handle = None
    tb_detail = None
    if SummaryWriter is None:
        tb_detail = "not-installed"
    else:
        try:  # pragma: no cover - depends on tensorboard install
            os.makedirs(logdir, exist_ok=True)
            tb_handle = SummaryWriter(logdir)
        except (IOError, OSError) as exc:  # pragma: no cover - optional
            tb_detail = f"error:{exc.__class__.__name__}"
            tb_handle = None
    component_statuses.append(
        TelemetryComponentStatus("tensorboard", tb_handle is not None, tb_detail)
    )

    wb_handle = None
    wb_detail = None
    if getattr(args, "enable_wandb", False):
        if wandb is None:
            wb_detail = "not-installed"
        else:
            try:  # pragma: no cover - wandb may not be installed
                mode = os.getenv("WANDB_MODE", "offline")
                if mode not in {"offline", "disabled"}:
                    mode = "disabled"
                wb_handle = wandb.init(
                    project=getattr(args, "wandb_project", "codex-offline"),
                    mode=mode,
                    dir=logdir,
                )
            except Exception as exc:  # pragma: no cover - optional
                wb_detail = f"error:{exc.__class__.__name__}"
                wb_handle = None
        component_statuses.append(
            TelemetryComponentStatus("wandb", wb_handle is not None, wb_detail)
        )

    mlflow_active = False
    mlflow_detail = None
    if getattr(args, "mlflow_enable", False):
        if os.getenv("MLFLOW_OFFLINE") is None:
            os.environ["MLFLOW_OFFLINE"] = "1"
        tracking_uri = getattr(args, "mlflow_tracking_uri", "")
        if tracking_uri and mlflow is not None:
            os.environ["MLFLOW_TRACKING_URI"] = tracking_uri
            try:
                mlflow.set_tracking_uri(tracking_uri)
            except (ValueError, TypeError, RuntimeError) as e:
                type(e).__name__
                get_default_logger().debug("Exception: <ERROR_TYPE>")
                get_default_logger().warning("Exception: <ERROR_TYPE>", exc_info=True)
        mlflow_active, mlflow_detail = _start_mlflow_offline(
            getattr(args, "mlflow_tracking_uri", ""),
            getattr(args, "mlflow_experiment", "codex"),
        )
        if mlflow_active and getattr(args, "mlflow_tracking_uri", None) and mlflow is not None:
            try:
                mlflow.set_tracking_uri(getattr(args, "mlflow_tracking_uri", ""))
            except (ValueError, TypeError, RuntimeError) as e:
                type(e).__name__
                get_default_logger().debug("Exception: <ERROR_TYPE>")
                get_default_logger().warning("Exception: <ERROR_TYPE>", exc_info=True)
        component_statuses.append(TelemetryComponentStatus("mlflow", mlflow_active, mlflow_detail))

    loggers = CodexLoggers(
        tb=tb_handle,
        wb=wb_handle,
        mlflow_active=mlflow_active,
        degradations=tuple(component_statuses),
    )
    loggers.system_status = sampler_status()
    loggers.prometheus = prometheus_fallback_status()
    return _emit_degradation_banner(loggers)


# ---------------------------------------------------------------------------
# System metrics


def _git_commit() -> Optional[str]:
    """Return the cached git commit hash when available."""

    return None if _GIT_COMMIT == "unknown" else _GIT_COMMIT


def _codex_sample_system() -> dict[str, Any]:
    """Gather CPU/GPU metrics and basic environment details."""

    metrics: dict[str, Any] = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
    }
    commit = _git_commit()
    if commit:
        metrics["git_commit"] = commit
    if torch is not None:
        torch_version = getattr(torch, "__version__", None)
        if torch_version:
            metrics["torch"] = torch_version
        version_mod = getattr(torch, "version", None)
        cuda_version = getattr(version_mod, "cuda", None)
        if cuda_version:
            metrics["cuda"] = cuda_version
    if psutil is not None:
        try:
            metrics["cpu_percent"] = float(psutil.cpu_percent(interval=0.0))
            metrics["ram_percent"] = float(psutil.virtual_memory().percent)
        except (ValueError, TypeError, RuntimeError) as exc:
            type(exc).__name__
            get_default_logger().debug("Exception: <ERROR_TYPE>")
            get_default_logger().debug("psutil metrics unavailable", exc_info=exc)
    elif _PSUTIL_WARN_KEY not in _LOGGER_WARNING_CONTEXTS:
        get_default_logger().warning("psutil not installed; system metrics will be unavailable")
        _LOGGER_WARNING_CONTEXTS.add(_PSUTIL_WARN_KEY)

    # Prefer NVML for GPU stats with per-device enumeration
    gpu_done = False
    if pynvml is not None:
        try:  # pragma: no cover - depends on GPU/NVML availability
            pynvml.nvmlInit()
            count = pynvml.nvmlDeviceGetCount()
            gpus = []
            util_sum = 0.0
            for i in range(count):
                h = pynvml.nvmlDeviceGetHandleByIndex(i)
                util = pynvml.nvmlDeviceGetUtilizationRates(h)
                mem = pynvml.nvmlDeviceGetMemoryInfo(h)
                temp = pynvml.nvmlDeviceGetTemperature(h, 0)
                power = pynvml.nvmlDeviceGetPowerUsage(h) / 1000.0
                util_sum += float(util.gpu)
                gpus.append(
                    {
                        "device": i,
                        "util": float(util.gpu),
                        "mem_used": float(mem.used),
                        "mem_total": float(mem.total),
                        "temp_c": float(temp),
                        "power_w": float(power),
                    }
                )
            metrics["gpus"] = gpus
            metrics["gpu_util_mean"] = util_sum / max(1, len(gpus))
            pynvml.nvmlShutdown()
            gpu_done = True
        except (ValueError, TypeError, RuntimeError) as exc:
            type(exc).__name__
            get_default_logger().debug("Exception: <ERROR_TYPE>")
            get_default_logger().debug("NVML sampling failed", exc_info=exc)
            gpu_done = False

    if not gpu_done and torch is not None and hasattr(torch, "cuda") and torch.cuda.is_available():
        gpus = []
        util_sum = 0.0
        try:  # pragma: no cover - optional
            for i in range(torch.cuda.device_count()):
                props = torch.cuda.get_device_properties(i)
                used = float(torch.cuda.memory_allocated(i))
                total = float(props.total_memory)
                util = None
                if hasattr(torch.cuda, "utilization"):
                    try:
                        util = float(torch.cuda.utilization(i))
                    except (ValueError, TypeError, RuntimeError) as exc:
                        type(exc).__name__
                        get_default_logger().debug("Exception: <ERROR_TYPE>")
                        get_default_logger().debug("torch CUDA utilization unavailable", exc_info=exc)
                        util = None
                if util:
                    util_sum += util
                gpus.append(
                    {
                        "device": i,
                        "util": util,
                        "mem_used": used,
                        "mem_total": total,
                    }
                )
            if gpus:
                metrics["gpus"] = gpus
                metrics["gpu_util_mean"] = util_sum / max(1, len(gpus))
        except (ValueError, TypeError, RuntimeError) as exc:
            type(exc).__name__
            get_default_logger().debug("Exception: <ERROR_TYPE>")
            get_default_logger().debug("torch CUDA sampling failed", exc_info=exc)

    return metrics


# ---------------------------------------------------------------------------
# Logging


def _filter_scalars(values: dict[str, Any]) -> dict[str, float]:
    out: dict[str, float] = {}
    for k, v in values.items():
        try:
            out[k] = float(v)
        except (ValueError, TypeError, RuntimeError):
            get_default_logger().warning("Exception occurred", exc_info=True)
            continue
    return out


def _codex_log_all(step: int, scalars: dict[str, Any], loggers: CodexLoggers) -> None:
    """Log ``scalars`` at ``step`` to all enabled sinks."""

    values = _filter_scalars(scalars)

    if loggers.tb is not None:
        try:  # pragma: no cover - tensorboard optional
            for k, v in values.items():
                loggers.tb.add_scalar(k, v, step)
        except (ValueError, TypeError, RuntimeError) as exc:
            type(exc).__name__
            get_default_logger().debug("Exception: <ERROR_TYPE>")
            get_default_logger().debug("tensorboard add_scalar failed", exc_info=exc)

    if loggers.wb is not None:
        try:  # pragma: no cover - wandb optional
            loggers.wb.log({**values, "step": step})
        except (ValueError, TypeError, RuntimeError) as exc:
            type(exc).__name__
            get_default_logger().debug("Exception: <ERROR_TYPE>")
            get_default_logger().debug("wandb log failed", exc_info=exc)

    if loggers.mlflow_active and mlflow is not None:
        try:  # pragma: no cover - mlflow optional
            mlflow.log_metrics(values, step=step)
        except (IOError, OSError) as exc:
            type(exc).__name__
            get_default_logger().debug("Exception: <ERROR_TYPE>")
            get_default_logger().debug("mlflow log_metrics failed", exc_info=exc)


def write_ndjson(path: str | os.PathLike[str], record: dict[str, Any]) -> None:
    """Append ``record`` to ``path`` as NDJSON with rotation and redaction."""

    if not isinstance(record, dict):
        raise TypeError("record must be a mapping")
    _redact_sensitive_fields(record)
    path_obj = Path(path)
    path_obj.parent.mkdir(parents=True, exist_ok=True)
    _maybe_rotate_log(path_obj)
    with path_obj.open("a", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=True)
        f.write("\n")


__all__ = [
    "CodexLoggers",
    "TelemetryComponentStatus",
    "_codex_log_all",
    "_codex_logging_bootstrap",
    "_codex_patch_argparse",
    "_codex_sample_system",
    "init_logger",
    "init_telemetry",
    "write_ndjson",
]
