"""Utilities to keep MLflow tracking pinned to a local file-backed store."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_LITERAL_LOCAL_URI = "file:./artifacts/mlruns"

__all__ = [
    "DEFAULT_LITERAL_LOCAL_URI",
    "GuardDecision",
    "bootstrap_offline_tracking",
    "bootstrap_offline_tracking_decision",
    "ensure_file_backend",
    "ensure_file_backend_decision",
    "last_decision",
]


ALLOW_REMOTE_ENV = "MLFLOW_ALLOW_REMOTE"
ADDITIONAL_ALLOW_REMOTE_ENVS = (
    "CODEX_ALLOW_REMOTE_TRACKING",
    "CODEX_MLFLOW_ALLOW_REMOTE",
)


@dataclass(frozen=True)
class GuardDecision:
    """Outcome of an MLflow guard evaluation."""

    requested_uri: str
    effective_uri: str
    fallback_reason: Optional[str]
    allow_remote_flag: str
    allow_remote: bool
    system_metrics_enabled: bool

    @property
    def uri(self) -> str:
        """Return the effective tracking URI."""

        return self.effective_uri

    @property
    def allow_remote_env(self) -> str:
        """Name of the environment variable that toggles remote tracking."""

        return ALLOW_REMOTE_ENV


def _default_tracking_dir() -> Path:
    candidate = os.environ.get("CODEX_MLFLOW_LOCAL_DIR", "artifacts/mlruns")
    path = Path(candidate).expanduser()
    if not path.is_absolute():
        path = (REPO_ROOT / path).resolve()
    path.mkdir(parents=True, exist_ok=True)
    return path


def _as_file_uri(path_like: str) -> str:
    path = Path(path_like).expanduser()
    if not path.is_absolute():
        path = (REPO_ROOT / path).resolve()
    path.mkdir(parents=True, exist_ok=True)
    return path.as_uri()


def _normalise_candidate(uri: str, *, allow_remote: bool) -> tuple[str, Optional[str]]:
    if not uri:
        return _default_tracking_dir().as_uri(), None

    parsed = urlparse(uri)
    if parsed.scheme in {"", "file"}:
        if parsed.scheme == "file":
            # Feature gate for localhost allowlist
            _enable_loopback = os.environ.get("CODEX_LOCAL_LOOPBACK", "true").lower() == "true"
            _default_localhosts = (
                {"", "localhost", "127.0.0.1", "::1"} if _enable_loopback else {""}
            )

            netloc = parsed.netloc or ""
            if netloc not in _default_localhosts:
                if not allow_remote:
                    return _default_tracking_dir().as_uri(), "non_local_host"
                return uri, None
            target = Path(parsed.path or ".")
            # Ensure the directory exists but keep the literal URI unchanged.
            _as_file_uri(str(target))
            return uri, None

        # ``uri`` or similar shorthand values should be preserved verbatim so
        # that tests relying on literal passthrough keep working while still
        # guarding against accidental remote schemes.
        separators = {os.sep}
        if os.altsep:
            separators.add(os.altsep)
        if not any(sep in uri for sep in separators):
            return uri, None

        target = Path(uri)
        return _as_file_uri(str(target)), None

    if allow_remote:
        return uri, None

    return _default_tracking_dir().as_uri(), "non_file_scheme"


def _coerce_bool_flag(value: Optional[str]) -> bool:
    if value is None:
        return False
    text = value.strip().lower()
    return text in {"1", "true", "yes", "on"}


def _record_decision(decision: GuardDecision) -> GuardDecision:
    global _LAST_DECISION
    _LAST_DECISION = decision
    return decision


def _apply_guard(
    *,
    requested_uri: Optional[str],
    allow_remote: bool,
    allow_remote_flag: Optional[str],
    force: bool,
) -> GuardDecision:
    tracking_env = os.environ.get("MLFLOW_TRACKING_URI", "").strip()
    codex_env = os.environ.get("CODEX_MLFLOW_URI", "").strip()
    explicit_request = (requested_uri or "").strip()

    local_override_raw = os.environ.get("CODEX_MLFLOW_LOCAL_DIR", "")
    local_override = local_override_raw.strip()
    preferred_local: Optional[str] = None
    if local_override:
        parsed_override = urlparse(local_override)
        if parsed_override.scheme in {"", "file"}:
            # Feature gate for localhost allowlist
            _enable_loopback = os.environ.get("CODEX_LOCAL_LOOPBACK", "true").lower() == "true"
            _default_localhosts = (
                {"", "localhost", "127.0.0.1", "::1"} if _enable_loopback else {""}
            )

            if parsed_override.scheme != "file" or parsed_override.netloc in _default_localhosts:
                preferred_local = local_override
        else:
            # ``Path`` treats things like ``C:\`` as absolute even though ``urlparse``
            # reports a scheme. Guard against Windows drive letters by normalising the
            # override to a proper ``file:`` URI when ``Path`` sees an anchor. Without
            # this, downstream normalisation would parse ``C:\mlruns`` as the scheme
            # ``c`` and treat it as remote, clobbering the intended override.
            if Path(local_override).anchor:
                preferred_local = _as_file_uri(local_override)

    # Explicit runtime URIs should win over local-dir defaults so callers that
    # intentionally set MLFLOW_TRACKING_URI (for example via tests/CLI flags)
    # are not silently overridden by a stale CODEX_MLFLOW_LOCAL_DIR value.
    candidate = explicit_request or tracking_env or codex_env or preferred_local
    recorded_request = candidate or ""
    normalised, fallback_reason = _normalise_candidate(candidate or "", allow_remote=allow_remote)

    if force or not tracking_env or tracking_env != normalised:
        os.environ["MLFLOW_TRACKING_URI"] = normalised
    if force or not codex_env or codex_env != normalised:
        os.environ["CODEX_MLFLOW_URI"] = normalised

    if ("MLFLOW_ENABLE_SYSTEM_METRICS" not in os.environ) or force:
        os.environ["MLFLOW_ENABLE_SYSTEM_METRICS"] = "false"

    system_metrics_enabled = _coerce_bool_flag(os.environ.get("MLFLOW_ENABLE_SYSTEM_METRICS"))
    flag_value = allow_remote_flag or ("1" if allow_remote else "")
    decision = GuardDecision(
        requested_uri=recorded_request,
        effective_uri=normalised,
        fallback_reason=fallback_reason,
        allow_remote_flag=flag_value,
        allow_remote=allow_remote,
        system_metrics_enabled=system_metrics_enabled,
    )
    return _record_decision(decision)


_LAST_DECISION: Optional[GuardDecision] = None


def ensure_file_backend(
    *,
    allow_remote: bool = False,
    force: bool = False,
    allow_remote_flag: Optional[str] = None,
    requested_uri: Optional[str] = None,
) -> str:
    """Ensure MLflow uses a ``file:`` URI unless remote backends are allowed."""

    decision = _apply_guard(
        requested_uri=requested_uri,
        allow_remote=allow_remote,
        allow_remote_flag=allow_remote_flag,
        force=force,
    )
    return decision.effective_uri


def ensure_file_backend_decision(
    *,
    allow_remote: bool = False,
    force: bool = False,
    allow_remote_flag: Optional[str] = None,
    requested_uri: Optional[str] = None,
) -> GuardDecision:
    """Return the full guard decision while enforcing the MLflow backend."""

    return _apply_guard(
        requested_uri=requested_uri,
        allow_remote=allow_remote,
        allow_remote_flag=allow_remote_flag,
        force=force,
    )


def bootstrap_offline_tracking(*, force: bool = False, requested_uri: str | None = None) -> str:
    """Bootstrap tracking configuration respecting the remote override flag."""

    allow_remote_flag = os.environ.get(ALLOW_REMOTE_ENV, "").strip()
    allow_remote = _coerce_bool_flag(allow_remote_flag)

    if not allow_remote:
        for env_name in ADDITIONAL_ALLOW_REMOTE_ENVS:
            raw_value = os.environ.get(env_name)
            if raw_value is None:
                continue
            stripped = raw_value.strip()
            if _coerce_bool_flag(stripped):
                os.environ[ALLOW_REMOTE_ENV] = stripped
                allow_remote_flag = stripped
                allow_remote = True
                break
    return ensure_file_backend(
        allow_remote=allow_remote,
        allow_remote_flag=allow_remote_flag,
        force=force,
        requested_uri=requested_uri,
    )


def bootstrap_offline_tracking_decision(
    *, force: bool = False, requested_uri: str | None = None
) -> GuardDecision:
    """Return the guard decision used during bootstrap."""

    allow_remote_flag = os.environ.get(ALLOW_REMOTE_ENV, "").strip()
    allow_remote = _coerce_bool_flag(allow_remote_flag)

    if not allow_remote:
        for env_name in ADDITIONAL_ALLOW_REMOTE_ENVS:
            raw_value = os.environ.get(env_name)
            if raw_value is None:
                continue
            stripped = raw_value.strip()
            if _coerce_bool_flag(stripped):
                os.environ[ALLOW_REMOTE_ENV] = stripped
                allow_remote_flag = stripped
                allow_remote = True
                break
    return ensure_file_backend_decision(
        allow_remote=allow_remote,
        allow_remote_flag=allow_remote_flag,
        force=force,
        requested_uri=requested_uri,
    )


def last_decision() -> Optional[GuardDecision]:
    """Return the most recent guard decision, if any."""

    return _LAST_DECISION
