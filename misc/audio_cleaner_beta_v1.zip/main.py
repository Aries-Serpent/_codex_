import sys
import argparse
import os
from PyQt5.QtWidgets import QApplication
from gui.main_window import MainWindow
from cli.cli_interface import parse_cli_args, run_cli_mode

def main():
    # Ensure templates directory exists before anything else
    templates_dir = os.path.join(os.path.dirname(__file__), "templates")
    os.makedirs(templates_dir, exist_ok=True)
    
    parser = argparse.ArgumentParser(description='Audio Cleaner Application')
    parser.add_argument('--cli', action='store_true', help='Run application in CLI mode. GUI otherwise.')
    parser.add_argument('--input_folder', type=str, help='Input folder path (required if using CLI)')
    parser.add_argument('--output_folder', type=str, help='Output folder path (required if using CLI)')
    parser.add_argument('--profile', type=str, default='', help='Cleaning profile JSON filename. Optional in CLI mode.')

    args = parser.parse_args()

    if args.cli:
        if not args.input_folder or not args.output_folder:
            parser.error('CLI mode requires --input_folder and --output_folder arguments.')
        run_cli_mode(input_folder=args.input_folder, 
                     output_folder=args.output_folder, 
                     profile_path=args.profile)
    else:
        app = QApplication(sys.argv)
        window = MainWindow()
        window.show()
        sys.exit(app.exec_())

if __name__ == "__main__":
    main()