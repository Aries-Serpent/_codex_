import numpy as np
from sklearn.cluster import KMeans
import os
import json

class ClusteringEngine:
    def __init__(self, profiles_folder='./templates'):
        # Ensure templates directory exists
        os.makedirs(profiles_folder, exist_ok=True)
        
        self.profiles = self.load_profiles(profiles_folder)
        
        # If no profiles found, create a default one
        if not self.profiles:
            self._create_default_profile(profiles_folder)
            self.profiles = self.load_profiles(profiles_folder)
        
        self.kmeans = KMeans(n_clusters=max(1, len(self.profiles)))
        self.fit_clusterer()

    def _create_default_profile(self, folder):
        """Create a default profile if none exists"""
        default_profile = {
            "name": "Standard Podcast Cleaning",
            "features": {
                "pitch": 120.0,
                "spectral_centroid": 2500.0,
                "rms": 0.05,
                "zcr": 0.1
            },
            "cleaning_params": {
                "trim_silence": True,
                "hp_freq": 80,
                "normalize_level": 0.9,
                "noise_gate_threshold": 0.01
            }
        }
        
        profile_path = os.path.join(folder, "default_profile.json")
        with open(profile_path, 'w', encoding='utf-8') as f:
            json.dump(default_profile, f, indent=2)
            print(f"Created default profile: {profile_path}")

    def load_profiles(self, folder):
        profiles = []
        try:
            for file in os.listdir(folder):
                if file.endswith('.json'):
                    try:
                        with open(os.path.join(folder, file)) as fp:
                            profiles.append(json.load(fp))
                    except Exception as e:
                        print(f"Error loading profile {file}: {e}")
        except Exception as e:
            print(f"Error accessing profiles directory {folder}: {e}")
        
        return profiles

    def fit_clusterer(self):
        if self.profiles:
            feature_vectors = [self.profile_to_vector(p) for p in self.profiles]
            self.kmeans.fit(feature_vectors)

    def profile_to_vector(self, profile):
        feats = profile['features']
        return np.array([
            feats['pitch'],
            feats['spectral_centroid'],
            feats['rms'],
            feats['zcr']
        ])

    def match_profile(self, features):
        feat_vector = np.array([
            features['pitch'],
            features['spectral_centroid'],
            features['rms'],
            features['zcr']
        ]).reshape(1, -1)
        label = self.kmeans.predict(feat_vector)[0]
        return self.profiles[label]
