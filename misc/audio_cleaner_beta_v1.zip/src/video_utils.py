from moviepy.editor import VideoFileClip
import os

def extract_audio(mp4_path, output_audio_path):
    """
    Extract audio track from an MP4 video and save it as a WAV file.
    """
    video = VideoFileClip(mp4_path)
    audio = video.audio
    audio.write_audiofile(output_audio_path, codec='pcm_s16le')
    audio.close()
    video.close()
    return output_audio_path
