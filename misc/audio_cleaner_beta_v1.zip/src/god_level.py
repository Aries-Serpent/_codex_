import numpy as np
from scipy.signal import butter, sosfilt
from .quick_trim import quick_trim

class GodLevelCleaner:
    def __init__(self):
        pass

    def process_audio(self, y, sr, params):
        if params.get("trim_silence", True):
            y = quick_trim(y)

        y = self.highpass_filter(y, sr, params.get("hp_freq", 80))
        y = self.normalize(y, params.get("normalize_level", 0.9))
        y = self.noise_gate(y, params.get("noise_gate_threshold", 0.01))

        return y

    def highpass_filter(self, y, sr, cutoff=80):
        sos = butter(4, cutoff, btype='highpass', fs=sr, output='sos')
        return sosfilt(sos, y)

    def normalize(self, y, peak=0.9):
        max_amp = np.max(np.abs(y))
        if max_amp == 0:
            return y
        return (y / max_amp) * peak

    def noise_gate(self, y, threshold):
        y[np.abs(y) < threshold] = 0
        return y
