import librosa

def quick_trim(y, top_db=20):
    """
    Quickly trims silent sections from start and end.
    """
    y_trimmed, _ = librosa.effects.trim(y, top_db=top_db)
    return y_trimmed
