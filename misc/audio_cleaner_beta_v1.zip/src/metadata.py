import librosa
import numpy as np

def extract_features(y, sr):
    pitch = librosa.yin(y, fmin=50, fmax=300, sr=sr)
    pitch_mean = np.median(pitch[pitch > 0])
    spectral_centroid = librosa.feature.spectral_centroid(y=y, sr=sr).mean()
    rms = librosa.feature.rms(y=y).mean()
    zcr = librosa.feature.zero_crossing_rate(y).mean()

    return {
        'pitch': pitch_mean if not np.isnan(pitch_mean) else 0,
        'spectral_centroid': float(spectral_centroid),
        'rms': float(rms),
        'zcr': float(zcr)
    }
