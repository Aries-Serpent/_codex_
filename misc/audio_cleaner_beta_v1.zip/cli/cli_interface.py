import os
import tempfile
import librosa
import soundfile as sf
from src.god_level import GodLevelCleaner
from src.metadata import extract_features
from src.clustering import ClusteringEngine
from src.video_utils import extract_audio
import json

def parse_cli_args():
    # Parsing is performed in main.py for simplicity; centralize handling.
    pass

def load_profile(profile_path):
    with open(profile_path, 'r') as fp:
        return json.load(fp)

def run_cli_mode(input_folder, output_folder, profile_path=None):
    cleaner = GodLevelCleaner()
    
    # Load profile or initialize clustering engine if missing
    if profile_path:
        profile = load_profile(profile_path)
    else:
        # Ensure templates directory exists before clustering
        templates_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "templates")
        os.makedirs(templates_dir, exist_ok=True)
        engine = ClusteringEngine()
        profile = None

    os.makedirs(output_folder, exist_ok=True)

    for filename in os.listdir(input_folder):
        input_filepath = os.path.join(input_folder, filename)
        ext = filename.lower().split('.')[-1]

        if ext in ('wav', 'mp3', 'flac'):
            y, sr = librosa.load(input_filepath, sr=None, mono=True)
        elif ext == 'mp4':
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                temp_audio_path = extract_audio(input_filepath, tmp.name)
                y, sr = librosa.load(temp_audio_path, sr=None, mono=True)
            os.unlink(temp_audio_path)
        else:
            print(f"Skipping unsupported file format: {filename}")
            continue
        
        if not profile:
            features = extract_features(y, sr)
            profile = engine.match_profile(features)
            print(f'Auto-selected profile: {profile["name"]}')
        else:
            print(f'Using provided profile: {profile["name"]}')
        
        cleaned_audio = cleaner.process_audio(y, sr, profile['cleaning_params'])
        output_filename = os.path.join(output_folder, f"clean_{os.path.splitext(filename)[0]}.wav")
        sf.write(output_filename, cleaned_audio, sr)
        print(f"Processed {filename} ==> {output_filename}")
