# 🎵 Audio Cleaner 🎵  

Audio Cleaner is a versatile Python application capable of cleaning audio files, extracting audio metadata, and auto-selecting cleaning profiles via audio clustering. It now also supports extracting audio directly from MP4 video files!

---

## 🚀 **Installation**

```
pip install -r requirements.txt
```

---

## 🌟 **Feature Highlights:**
- Silence Trimming  
- High-pass filters and Normalization  
- Noise gating  
- Metadata extraction (Pitch, RMS, Spectral Centroid, Zero Crossing Rate)  
- Clustering-based auto-profile matching  
- **Supported formats**: WAV, MP3, FLAC, and MP4 (audio extraction)  
- GUI and CLI interfaces provided  

---

## 🎨 **GUI Mode (Drag-and-Drop)**

Run GUI mode simply by:

```
python main.py
```

- Drag-and-drop audio or MP4 video files  
- Select cleaning profiles manually or auto-select via clustering  
- View extracted audio metadata  

---

## 🔧 **Command-Line Mode**

To batch process via CLI:

```
python main.py --cli --input_folder ./input_audio --output_folder ./output_audio --profile example_profile.json
```

This enables quick bulk audio-cleaning workflows easily integrable with automated setups.

---

## 📦 **Packaging with PyInstaller**

Project includes a suitable PyInstaller spec file using:

```
pyinstaller build/audio_cleaner.spec
```

---

## 📕 **Project Docs**

Quench your technical curiosity by reviewing in-depth architecture and usage notes in `docs/whitepaper.txt`.

---

## 🧠 **Customization Notes:**

- Cleaning parameters and feature extraction logic found clearly in `templates/example_profile.json`  
- Feel encouraged to create new profiles specific to your domain.  

---

Enjoy cleaning your audios effortlessly!
