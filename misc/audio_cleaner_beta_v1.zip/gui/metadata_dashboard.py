from PyQt5.QtWidgets import QLabel, QWidget, QVBoxLayout, QMainWindow
import matplotlib.pyplot as plt
import numpy as np

class MetadataDashboard(QMainWindow):
    def __init__(self, metadata):
        super().__init__()
        self.setWindowTitle("📊 Audio Metadata Dashboard")
        self.metadata = metadata
        self.init_ui()

    def init_ui(self):
        central_widget = QWidget()
        layout = QVBoxLayout()

        for key, value in self.metadata.items():
            label = QLabel(f"{key}: {value:.4f}")
            layout.addWidget(label)

        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)
