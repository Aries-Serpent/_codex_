import sys
import os
import json
import tempfile
import librosa
import soundfile as sf
from PyQt5.QtWidgets import (
    QMainWindow, QApplication, QWidget, QLabel, QPushButton, QFileDialog,
    QVBoxLayout, QListWidget, QMessageBox, QComboBox
)
from PyQt5.QtCore import Qt
from src.god_level import GodLevelCleaner
from src.metadata import extract_features
from src.clustering import ClusteringEngine
from src.video_utils import extract_audio

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🎵 Audio Cleaner")

        self.cleaner = GodLevelCleaner()
        self.engine = ClusteringEngine()

        self.init_ui()

    def init_ui(self):
        self.central = QWidget()
        self.layout = QVBoxLayout()

        self.label = QLabel("📁 Drag and Drop Audio Files Here 📁")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setAcceptDrops(True)
        self.label.dragEnterEvent = self.drag_enter_event
        self.label.dropEvent = self.drop_event
        self.layout.addWidget(self.label)

        self.file_list = QListWidget()
        self.layout.addWidget(self.file_list)

        profile_label = QLabel("🎚️ Select Cleaning Profile:")
        self.layout.addWidget(profile_label)

        self.profiles_combo = QComboBox()
        self.load_profiles()
        self.layout.addWidget(self.profiles_combo)

        self.clean_button = QPushButton("✨ Clean Audio Files ✨")
        self.clean_button.clicked.connect(self.clean_audio_files)
        self.layout.addWidget(self.clean_button)

        self.metadata_button = QPushButton("🔍 View Metadata")
        self.metadata_button.clicked.connect(self.view_metadata)
        self.layout.addWidget(self.metadata_button)

        self.central.setLayout(self.layout)
        self.setCentralWidget(self.central)

    def load_profiles(self):
        self.profiles = []
        templates_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "templates")
        os.makedirs(templates_dir, exist_ok=True)  # Ensure directory exists
        
        for file in os.listdir(templates_dir):
            if file.endswith('.json'):
                with open(os.path.join(templates_dir, file), 'r') as fp:
                    profile = json.load(fp)
                    self.profiles.append(profile)
                    self.profiles_combo.addItem(profile['name'])

    def drag_enter_event(self, event):
        event.acceptProposedAction()

    def drop_event(self, event):
        from PyQt5.QtWidgets import QMessageBox
        for url in event.mimeData().urls():
            filepath = url.toLocalFile()
            if filepath.lower().endswith(('.wav', '.mp3', '.flac', '.mp4')):
                self.file_list.addItem(filepath)
            else:
                QMessageBox.warning(self, "Unsupported file", f"File {filepath} has an unsupported format.")

    def clean_audio_files(self):
        from src.video_utils import extract_audio
        import tempfile
        output_dir = QFileDialog.getExistingDirectory(self, "🗂️ Select Output Directory")
        if not output_dir:
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.warning(self, "⚠️ Warning", "No output directory selected!")
            return

        profile = self.profiles[self.profiles_combo.currentIndex()]
        params = profile["cleaning_params"]

        for idx in range(self.file_list.count()):
            filepath = self.file_list.item(idx).text()
            ext = filepath.lower().split('.')[-1]

            if ext in ('wav', 'mp3', 'flac'):
                y, sr = librosa.load(filepath, sr=None, mono=True)
            elif ext == 'mp4':
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                    temp_audio_path = extract_audio(filepath, tmp.name)
                    y, sr = librosa.load(temp_audio_path, sr=None, mono=True)
                os.unlink(temp_audio_path)
            else:
                from PyQt5.QtWidgets import QMessageBox
                QMessageBox.warning(self, "Unsupported file", f"Skipping unsupported format: {filepath}")
                continue

            cleaned_y = self.cleaner.process_audio(y, sr, params)
            output_filename = os.path.join(output_dir, f"clean_{os.path.splitext(os.path.basename(filepath))[0]}.wav")
            sf.write(output_filename, cleaned_y, sr)
        from PyQt5.QtWidgets import QMessageBox
        QMessageBox.information(self, "✅ Done", "All audio files cleaned successfully!")

    def view_metadata(self):
        from gui.metadata_dashboard import MetadataDashboard
        if self.file_list.currentItem():
            selected_file = self.file_list.currentItem().text()
            y, sr = librosa.load(selected_file, sr=None, mono=True)
            features = extract_features(y, sr)
            self.metadata_window = MetadataDashboard(features)
            self.metadata_window.show()
        else:
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.warning(self, "⚠️ No Selection", "Please select an audio file from the list!")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())
