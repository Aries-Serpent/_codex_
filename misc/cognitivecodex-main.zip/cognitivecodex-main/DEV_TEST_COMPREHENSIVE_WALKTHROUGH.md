# Comprehensive Development Test Walkthrough

## CodeGenerator Component - Lazy Initialization Pattern

> **Generated:** 2026-01-06T06:10:00Z  
> **Purpose:** Complete development testing guide with visual diagrams for AI Agent intuition  
> **Audience:** Developers, QA Engineers, AI Agents  
> **Status:** Production-Ready Reference

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Architecture Overview](#architecture-overview)
3. [Component State Machine](#component-state-machine)
4. [Test Scenario Matrix](#test-scenario-matrix)
5. [Manual Testing Walkthrough](#manual-testing-walkthrough)
6. [Automated Testing Guide](#automated-testing-guide)
7. [Expected Behavior Specifications](#expected-behavior-specifications)
8. [Visual Design System](#visual-design-system)
9. [Troubleshooting Guide](#troubleshooting-guide)

---

## Executive Summary

### Component Purpose

The **CodeGenerator** component implements a lazy initialization pattern for API client management, supporting graceful fallback to mock/demo mode when the production API is unavailable or misconfigured.

### Key Features

✅ **Lazy Client Initialization** - Clients created on-demand, not at module load  
✅ **Graceful Degradation** - Automatic fallback to mock client  
✅ **Hot Module Replacement** - API key changes without reload  
✅ **Visual Status Indicators** - Real-time connection state feedback  
✅ **Comprehensive Validation** - Input validation with character limits

### Testing Coverage

- **Unit Tests:** 14 tests target (implementation in progress)
- **E2E Tests:** 26 scenarios (ready for execution)
- **Manual Tests:** 4 scenarios across 5 test cases
- **Target Pass Rate:** 100%

---

## Architecture Overview

```mermaid
graph TB
    subgraph "CodeGenerator Component Architecture"
        A[User Interface] --> B[Component State]
        B --> C{API Client Factory}
        C -->|Has Key| D[CodexAPIClient]
        C -->|No Key| E[MockCodexAPIClient]
        D --> F{API Status Check}
        F -->|Success| G[Connected State]
        F -->|Failure| H{Fallback Logic}
        E --> I[Mock Status Check]
        I -->|Success| J[Demo Mode State]
        I -->|Failure| K[Error State]
        H -->|Try Mock| E
        H -->|Mock Fails| K
        B --> L[UI Rendering]
        L --> M[Status Indicators]
        L --> N[Input Validation]
        L --> O[Action Buttons]
        G --> P[Enable Generation]
        J --> P
        K --> Q[Disable Generation]
        P --> R[Code Generation Flow]
        R --> S[Display Results]
    end
```

### Component Layers

```mermaid
graph LR
    subgraph "Layer 1: UI Presentation"
        A1[Status Badge]
        A2[Input Textarea]
        A3[Generate Button]
        A4[Error/Info Messages]
        A5[Results Display]
    end
    
    subgraph "Layer 2: State Management"
        B1[API Status State]
        B2[Error State]
        B3[Info Message State]
        B4[Loading State]
        B5[Result State]
        B6[Prompt State]
    end
    
    subgraph "Layer 3: Business Logic"
        C1[Client Factory]
        C2[Status Checker]
        C3[Code Generator]
        C4[Fallback Handler]
        C5[Validator]
    end
    
    subgraph "Layer 4: External APIs"
        D1[CodexAPI]
        D2[MockAPI]
    end
    
    A1 --> B1
    A2 --> B6
    A3 --> B4
    A4 --> B2
    A4 --> B3
    A5 --> B5
    B1 --> C2
    B4 --> C3
    B6 --> C5
    C1 --> D1
    C1 --> D2
    C2 --> C4
    C3 --> C4
```

---

## Component State Machine

```mermaid
stateDiagram-v2
    [*] --> Initial: Component Mounts
    Initial --> Checking: useEffect Triggers
    Checking --> APIKeyPresent: Check Env Var
    Checking --> NoAPIKey: No Env Var
    
    APIKeyPresent --> APIConnected: getStatus() Success
    APIKeyPresent --> APIFailed: getStatus() Failure
    
    NoAPIKey --> MockAvailable: Mock getStatus() Success
    NoAPIKey --> ErrorState: Mock getStatus() Failure
    
    APIFailed --> MockAvailable: Fallback to Mock
    APIFailed --> ErrorState: Mock Also Fails
    
    APIConnected --> Ready: Status = "connected"
    MockAvailable --> DemoMode: Status = "connected" + Info
    ErrorState --> Disabled: Status = "error"
    
    Ready --> Generating: User Clicks Generate
    DemoMode --> Generating: User Clicks Generate
    Disabled --> Disabled: Button Disabled
    
    Generating --> Success: Code Generated
    Generating --> MockFallback: API Fails, Try Mock
    Generating --> Failed: Both Fail
    
    MockFallback --> Success: Mock Succeeds
    
    Success --> Ready: Show Results
    Success --> DemoMode: Show Results (Demo)
    Failed --> ErrorState: Show Error
    
    Ready --> Checking: 30s Timer
    DemoMode --> Checking: 30s Timer
    ErrorState --> Checking: 30s Timer
    
    note right of Checking
        Yellow indicator
        "Checking..." text
    end note
    
    note right of Ready
        Green indicator
        "Connected" text
        Button enabled
    end note
    
    note right of DemoMode
        Green indicator
        "Connected" text
        Blue info message
        Button enabled
    end note
    
    note right of ErrorState
        Red indicator
        "Error" text
        Red error message
        Button disabled
    end note
```

### State Transition Table

| Current State | Event | Condition | Next State | UI Changes |
|--------------|-------|-----------|------------|------------|
| Initial | Mount | - | Checking | Yellow dot, "Checking..." |
| Checking | API Check | Has key + Success | APIConnected | Green dot, "Connected" |
| Checking | API Check | Has key + Fail | APIFailed | → Mock check |
| Checking | API Check | No key | NoAPIKey | → Mock check |
| APIFailed | Fallback | Mock success | MockAvailable | Green dot, Blue info |
| NoAPIKey | Mock Check | Mock success | MockAvailable | Green dot, Blue info |
| NoAPIKey | Mock Check | Mock fail | ErrorState | Red dot, Red error |
| MockAvailable | - | - | DemoMode | Info: "Using demo mode" |
| * | 30s Timer | - | Checking | Recheck status |

---

## Test Scenario Matrix

```mermaid
graph TD
    subgraph "Test Coverage Matrix"
        A[Test Scenarios] --> B[Test 2: No API Key]
        A --> C[Test 3: With API Key]
        A --> D[Test 4: Mock Fallback]
        A --> E[Test 5: Environment Config]
        
        B --> B1[Error Message Display]
        B --> B2[Demo Mode Activation]
        B --> B3[Button State Management]
        
        C --> C1[Checking Status Initial]
        C --> C2[Status Transition]
        C --> C3[Button Enable After Check]
        
        D --> D1[Character Validation]
        D --> D2[Character Count Display]
        D --> D3[UI Structure Validation]
        
        E --> E1[Timing Config Variations]
        E --> E2[API URL Configurations]
    end
```

### Test Coverage Breakdown

| Scenario | Unit Tests | E2E Tests | Manual Tests | Status |
|----------|-----------|-----------|--------------|--------|
| **Test 2: No API Key** | Required | 4 ready | Required | 🟡 In Progress |
| **Test 3: With API Key** | Required | 6 ready | Required | 🟡 In Progress |
| **Test 4: Mock Fallback** | Required | 6 ready | Required | 🟡 In Progress |
| **Test 5: Environment** | Required | 5 ready | Optional | 🟡 In Progress |
| **Component Structure** | Required | 2 ready | Optional | 🟡 In Progress |
| **Real Workflows** | N/A | 3 ready | Recommended | ⚪ Pending |
| **Accessibility** | N/A | 2 ready | Recommended | ⚪ Pending |

---

## Manual Testing Walkthrough

### Prerequisites

```bash
# 1. Navigate to project directory
cd /workspaces/spark-template

# 2. Install dependencies (if not already done)
npm install

# 3. Verify environment variables
echo "Current VITE_CODEX_KEY: ${VITE_CODEX_KEY:-<not set>}"
echo "Current VITE_CODEX_API: ${VITE_CODEX_API:-<not set>}"
```

---

### Test 2: No API Key Scenario

**Objective:** Verify graceful degradation to demo mode when API key is absent

#### Step-by-Step Instructions

```bash
# 1. Remove API key from environment
unset VITE_CODEX_KEY

# 2. Start development server
npm run dev

# Expected output:
# ➜  Local:   http://localhost:5173/
# ➜  press h + enter to show help
```

#### Expected UI State (Diagram)

```
┌─────────────────────────────────────────────────────────┐
│ Code Generation             API Status: ● Connected     │
│                                          ↑              │
│                                    (Green dot)          │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Describe the code you want to generate                 │
│ ┌───────────────────────────────────────────────┐     │
│ │ Example: Create a FastAPI endpoint...        │     │
│ │                                               │     │
│ │                                       0/5000  │     │
│ └───────────────────────────────────────────────┘     │
│                                                         │
│         ┌─────────────────────────┐                    │
│         │ ⚡ Generate Code        │ ← ENABLED          │
│         └─────────────────────────┘                    │
│                                                         │
│ ┌────────────────────────────────────────────────┐    │
│ │ ℹ️ Info                                        │    │
│ │ Using demo mode (API key not configured)      │    │
│ └────────────────────────────────────────────────┘    │
│         ↑ Blue info box (not red error)               │
└─────────────────────────────────────────────────────────┘
```

#### Verification Checklist

- [ ] **Status Indicator:** Green dot (●) visible
- [ ] **Status Text:** Shows "Connected" in green
- [ ] **Info Message:** Blue info box with "Using demo mode"
- [ ] **Error Message:** NO red error box displayed
- [ ] **Generate Button:** ENABLED (not grayed out)
- [ ] **Character Counter:** Shows "0 / 5000"

#### Interactive Test Steps

1. **Enter Invalid Prompt** (< 10 characters)
```
Type: "Hello"
Expected: 
- Character count: "5 / 5000 (min: 10)"
- Textarea border: Red (border-destructive)
- Button: Disabled
```

2. **Enter Valid Prompt** (≥ 10 characters)
```
Type: "Create a hello world function"
Expected:
- Character count: "29 / 5000"
- Textarea border: Normal (no red)
- Button: Enabled
```

3. **Click Generate Button**
```
Expected:
- Button text: "Generating Code..." with spinner
- After ~1-2 seconds:
  * Toast notification: "Code generated successfully (Demo Mode)"
  * Code appears below with syntax highlighting
  * Copy and Download buttons visible
  * k₁ factor displayed (e.g., "k₁ factor: 0.5000")
```

4. **Test Copy Functionality**
```
Click "Copy" button
Expected:
- Toast: "Code copied to clipboard"
- Code copied to system clipboard
```

5. **Test Download Functionality**
```
Click "Download" button
Expected:
- File downloads: "generated_code.py"
- Toast: "Code downloaded"
```

---

### Test 3: With API Key Scenario

**Objective:** Verify normal operation when API key is configured

#### Step-by-Step Instructions

```bash
# 1. Set valid API key
export VITE_CODEX_KEY="test-api-key-12345"
export VITE_CODEX_API="http://localhost:8000"

# 2. Start development server
npm run dev
```

#### Expected UI State (Initial)

```
┌─────────────────────────────────────────────────────────┐
│ Code Generation             API Status: ● Checking...   │
│                                          ↑              │
│                                    (Yellow dot)         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│            ⏳ Checking API connection...                │
└─────────────────────────────────────────────────────────┘
```

#### Expected UI State (After Status Check - Success)

```
┌─────────────────────────────────────────────────────────┐
│ Code Generation             API Status: ● Connected     │
│                                          ↑              │
│                                    (Green dot)          │
├─────────────────────────────────────────────────────────┤
│                                                         │
│            ✅ Button ENABLED (no info, no error)        │
└─────────────────────────────────────────────────────────┘
```

#### Expected UI State (After Status Check - Failure → Mock Fallback)

```
┌─────────────────────────────────────────────────────────┐
│ Code Generation             API Status: ● Connected     │
│                                          ↑              │
│                                    (Green dot)          │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ ┌────────────────────────────────────────────────┐    │
│ │ ℹ️ Info                                        │    │
│ │ API connection failed, using demo mode         │    │
│ └────────────────────────────────────────────────┘    │
│         ↑ Blue info box (graceful fallback)           │
└─────────────────────────────────────────────────────────┘
```

#### Verification Checklist

- [ ] **Initial State:** Yellow dot + "Checking..."
- [ ] **After Check (Success):** Green dot + "Connected" + No messages
- [ ] **After Check (Fail):** Green dot + "Connected" + Blue info message
- [ ] **Button State:** Enabled after status check completes
- [ ] **Periodic Recheck:** Status rechecks every 30 seconds
- [ ] **Generate Works:** Code generation functions correctly
- [ ] **Toast Messages:** Include OR exclude "(Demo Mode)" appropriately

---

### Test 4: Mock Fallback Scenario

**Objective:** Verify automatic fallback when API calls fail

#### Step-by-Step Instructions

```bash
# 1. Set invalid API key to force fallback
export VITE_CODEX_KEY="invalid-key-will-fail-auth"
export VITE_CODEX_API="http://localhost:8000"

# 2. Start development server
npm run dev
```

#### Interactive Test Steps

1. **Observe Initial State**
```
Expected:
- Yellow dot, "Checking..."
- After check: Green dot, Blue info "API connection failed..."
```

2. **Test Prompt Validation**
```
Test Case 1: Short input (< 10 chars)
Input: "Short"
Expected:
- Counter: "5 / 5000 (min: 10)"
- Red border on textarea
- Button disabled

Test Case 2: Valid input (10+ chars)
Input: "Create a hello world function"
Expected:
- Counter: "29 / 5000"
- Normal border
- Button enabled
```

3. **Generate Code with Mock Fallback**
```
1. Enter: "Create a Python function to add two numbers"
2. Click "Generate Code"

Expected Flow:
a) Button shows "Generating Code..." with spinner
b) Component tries API first (fails with invalid key)
c) Component falls back to mock automatically
d) Toast: "Code generated successfully (Demo Mode)"
e) Generated code displays
f) k₁ factor: ~0.5000 (mock typically lower than real API)
```

4. **Test Character Counter Edge Cases**
```
Test exactly 10 characters:
Input: "Test12345!" (10 chars)
Expected: Counter "10 / 5000", button enabled

Test exactly 5000 characters:
Input: [5000 character string]
Expected: Counter "5000 / 5000", button enabled

Test over 5000:
Input: [5001 character string]
Expected: Counter "5001 / 5000", validation error (if implemented)
```

---

### Test 5: Environment Configuration

**Objective:** Verify component handles various environment configurations

#### Configuration Matrix

```mermaid
graph LR
    A[Environment Configs] --> B[Timing Variations]
    A --> C[API URL Variations]
    
    B --> B1[Default: 800ms]
    B --> B2[Fast: 200ms]
    B --> B3[Slow: 2000ms]
    B --> B4[Invalid: -100]
    B --> B5[Missing: undefined]
    
    C --> C1[Default: localhost]
    C --> C2[Custom: api.example.com]
    C --> C3[Invalid: malformed-url]
    C --> C4[Missing: undefined]
```

#### Test Configurations

**Config 1: Default (No Env Vars)**
```bash
unset VITE_STAGE_EXECUTION_TIME_MS
unset VITE_CODEX_API
export VITE_CODEX_KEY="test-key"

npm run dev
```
Expected: Component renders, uses defaults (800ms, localhost:8000)

**Config 2: Fast Timing**
```bash
export VITE_STAGE_EXECUTION_TIME_MS="200"
export VITE_CODEX_API="http://localhost:8000"
export VITE_CODEX_KEY="test-key"

npm run dev
```
Expected: Component renders, cascade animations faster

**Config 3: Slow Timing**
```bash
export VITE_STAGE_EXECUTION_TIME_MS="2000"
npm run dev
```
Expected: Component renders, cascade animations slower

**Config 4: Invalid Timing (Boundary Test)**
```bash
export VITE_STAGE_EXECUTION_TIME_MS="-100"
npm run dev
```
Expected: Component renders, falls back to default (800ms)

**Config 5: Custom API URL**
```bash
export VITE_CODEX_API="https://api.production.example.com"
export VITE_CODEX_KEY="prod-key"
npm run dev
```
Expected: Component attempts connection to custom URL

#### Verification Checklist

- [ ] **All Configs Render:** Component loads without crashes
- [ ] **Timing Variations:** Visual cascade speed matches config
- [ ] **URL Variations:** Network requests target correct URL
- [ ] **Invalid Handling:** Graceful fallback to defaults
- [ ] **Missing Vars:** Uses documented default values

---

## Expected Behavior Specifications

### Input Validation Rules

```mermaid
graph TD
    A[User Input] --> B{Length Check}
    B -->|< 10 chars| C[Invalid: Too Short]
    B -->|10-5000 chars| D[Valid]
    B -->|> 5000 chars| E[Invalid: Too Long]
    
    C --> F[Red border]
    C --> G[Show min requirement]
    C --> H[Disable button]
    
    D --> I[Normal border]
    D --> J[Hide requirements]
    D --> K[Enable button if API ready]
    
    E --> L[Red border]
    E --> M[Show max exceeded]
    E --> N[Disable button]
    
    K --> O{API Status?}
    O -->|connected| P[Button Enabled]
    O -->|error| Q[Button Disabled]
    O -->|checking| R[Button Disabled]
```

### Button Enable Logic

```mermaid
graph LR
    A[Generate Button] --> B{Conditions}
    B --> C[loading === false]
    B --> D[isValidPrompt === true]
    B --> E[apiStatus !== 'error']
    
    C --> F{AND}
    D --> F
    E --> F
    
    F -->|All True| G[ENABLED]
    F -->|Any False| H[DISABLED]
```

**Truth Table:**

| loading | isValidPrompt | apiStatus | Button State |
|---------|---------------|-----------|--------------|
| true    | true          | connected | DISABLED     |
| false   | false         | connected | DISABLED     |
| false   | true          | error     | DISABLED     |
| false   | true          | checking  | DISABLED     |
| **false** | **true**    | **connected** | **ENABLED** ✅ |

### Status Indicator Colors

```mermaid
graph LR
    A[API Status] --> B{Status Value}
    B -->|connected| C[Green Dot]
    B -->|error| D[Red Dot]
    B -->|checking| E[Yellow Dot]
    
    C --> F["Green Text: 'Connected'"]
    D --> G["Red Text: 'Error'"]
    E --> H["Yellow Text: 'Checking...'"]
```

---

## Visual Design System

### Color Palette

| Element | Color | Usage |
|---------|-------|-------|
| **Success / Connected** | `oklch(0.75 0.18 140)` (Green) | Status indicators, success messages |
| **Error** | `oklch(0.55 0.22 25)` (Red) | Error states, validation failures |
| **Warning / Checking** | `oklch(0.65 0.20 60)` (Yellow) | Loading states, pending status |
| **Info** | `oklch(0.70 0.15 220)` (Blue) | Demo mode messages, helpful hints |
| **Border Invalid** | `destructive` (Red) | Invalid input borders |

### Status Indicator Styles

```css
/* Connected State */
.status-dot-connected {
  background-color: rgb(34 197 94); /* green-500 */
  animation: pulse 2s ease-in-out infinite;
}

.status-text-connected {
  color: rgb(34 197 94);
}

/* Error State */
.status-dot-error {
  background-color: rgb(239 68 68); /* red-500 */
}

.status-text-error {
  color: rgb(239 68 68);
}

/* Checking State */
.status-dot-checking {
  background-color: rgb(234 179 8); /* yellow-500 */
  animation: pulse 1.5s ease-in-out infinite;
}

.status-text-checking {
  color: rgb(234 179 8);
}
```

---

## Troubleshooting Guide

### Common Issues

#### Issue 1: Status Stuck on "Checking..."

**Symptoms:**
- Yellow dot persists indefinitely
- No transition to connected or error state

**Diagnosis:**
```bash
# Check console for errors
# Look for: "Failed to fetch" or CORS errors
```

**Solution:**
1. Verify API endpoint is accessible
2. Check CORS configuration
3. Ensure mock client fallback is working

#### Issue 2: Button Remains Disabled

**Symptoms:**
- Status shows "Connected"
- Valid prompt entered (10+ chars)
- Button still disabled

**Diagnosis:**
```typescript
// Check state values in React DevTools
apiStatus === 'connected' // Should be true
isValidPrompt === true     // Should be true
loading === false          // Should be true
```

**Solution:**
1. Verify all three conditions are met
2. Check for JavaScript errors in console
3. Ensure state updates are propagating correctly

#### Issue 3: Mock Fallback Not Triggering

**Symptoms:**
- API fails but no blue info message
- Red error shown instead of graceful degradation

**Diagnosis:**
```bash
# Check mock client availability
# Verify MockCodexAPIClient is imported correctly
```

**Solution:**
1. Ensure MockCodexAPIClient class exists
2. Check async/await in fallback logic
3. Verify try/catch blocks are correct

#### Issue 4: Toast Messages Not Appearing

**Symptoms:**
- Code generates successfully
- No toast notification shown

**Diagnosis:**
```typescript
// Check if Sonner is properly set up
// Verify <Toaster /> component is in App.tsx
```

**Solution:**
1. Add `<Toaster />` to root component
2. Import `toast` from 'sonner'
3. Check browser console for errors

---

## Success Criteria

### ✅ Component Implementation Complete When:

1. **Visual Feedback**
   - [ ] Status indicator shows correct color (green/red/yellow)
   - [ ] Status text matches indicator state
   - [ ] Info messages appear in blue boxes
   - [ ] Error messages appear in red boxes

2. **State Management**
   - [ ] API status checks on mount
   - [ ] Status rechecks every 30 seconds
   - [ ] Graceful fallback to mock when API fails
   - [ ] No API key scenario shows demo mode

3. **Input Validation**
   - [ ] Character counter updates in real-time
   - [ ] Minimum 10 characters enforced
   - [ ] Maximum 5000 characters displayed
   - [ ] Invalid input shows red border

4. **Button Behavior**
   - [ ] Disabled during loading
   - [ ] Disabled with invalid prompt
   - [ ] Disabled with error status
   - [ ] Enabled only when all conditions met

5. **Code Generation**
   - [ ] API calls work with valid key
   - [ ] Mock fallback triggers on API failure
   - [ ] Toast messages indicate mode (Demo or normal)
   - [ ] Generated code displays with syntax highlighting

6. **User Actions**
   - [ ] Copy button copies code to clipboard
   - [ ] Download button saves file as .py
   - [ ] Both actions show success toasts

---

## Related Documentation

- [Implementation Status Report](./IMPLEMENTATION_STATUS.md)
- [Lazy Initialization Guide](./LAZY_INITIALIZATION_GUIDE.md)
- [Codex Integration Master Plan](./CODEX_INTEGRATION_MASTER_PLAN.md)
- [Product Requirements Document](./PRD.md)

---

**Document Version:** 1.0.0  
**Last Updated:** 2026-01-06  
**Maintained By:** Codex AI Development Team
