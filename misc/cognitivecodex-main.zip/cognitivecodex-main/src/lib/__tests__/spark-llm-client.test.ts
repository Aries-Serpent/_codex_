import { describe, it, expect, vi, beforeEach } from 'vitest';
import { SparkLLMClient } from '../spark-llm-client';
import { CodexRequest } from '../codex-api-client';

describe('SparkLLMClient', () => {
  let client: SparkLLMClient;

  beforeEach(() => {
    client = new SparkLLMClient();
    
    vi.stubGlobal('spark', {
      llmPrompt: (strings: TemplateStringsArray, ...values: any[]) => {
        return strings.reduce((acc, str, i) => acc + str + (values[i] || ''), '');
      },
      llm: vi.fn().mockResolvedValue(`def hello_world():
    """A simple hello world function"""
    print("Hello, World!")
    return "success"

if __name__ == "__main__":
    result = hello_world()
    print(f"Result: {result}")`),
    });
  });

  describe('Code Generation', () => {
    it('should generate code using Spark Runtime LLM', async () => {
      const request: CodexRequest = {
        prompt: 'Create a hello world function',
        context: { language: 'python', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response).toBeDefined();
      expect(response.code).toBeTruthy();
      expect(response.metadata).toBeDefined();
      expect(response.quantum_metrics).toBeDefined();
    });

    it('should include prompt in LLM request', async () => {
      const request: CodexRequest = {
        prompt: 'Create a FastAPI endpoint',
        context: { language: 'python', tier: 'B' },
      };

      await client.generateCode(request);

      expect(spark.llm).toHaveBeenCalled();
      const callArg = (spark.llm as any).mock.calls[0][0];
      expect(callArg).toContain('Create a FastAPI endpoint');
      expect(callArg).toContain('python');
    });

    it('should return properly formatted response', async () => {
      const request: CodexRequest = {
        prompt: 'Create a test function',
        context: { language: 'python', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response.code).toBeTypeOf('string');
      expect(response.metadata.k1_factor).toBeTypeOf('number');
      expect(response.metadata.coherence).toBeTypeOf('number');
      expect(response.metadata.cache_hit).toBeTypeOf('boolean');
      expect(response.metadata.processing_time_ms).toBeTypeOf('number');
      expect(response.quantum_metrics.superposition_states).toBeTypeOf('number');
      expect(response.quantum_metrics.entanglement_score).toBeTypeOf('number');
    });

    it('should calculate realistic k1 factor (0.28-0.33)', async () => {
      const request: CodexRequest = {
        prompt: 'Create a function',
        context: { language: 'python', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response.metadata.k1_factor).toBeGreaterThanOrEqual(0.28);
      expect(response.metadata.k1_factor).toBeLessThanOrEqual(0.33);
    });

    it('should include quantum metrics in response', async () => {
      const request: CodexRequest = {
        prompt: 'Create a function',
        context: { language: 'python', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response.quantum_metrics.superposition_states).toBeGreaterThanOrEqual(2);
      expect(response.quantum_metrics.superposition_states).toBeLessThanOrEqual(5);
      expect(response.quantum_metrics.entanglement_score).toBeGreaterThanOrEqual(0.78);
      expect(response.quantum_metrics.entanglement_score).toBeLessThanOrEqual(0.96);
    });
  });

  describe('Fallback Behavior', () => {
    it('should fall back to template code on LLM error', async () => {
      vi.stubGlobal('spark', {
        llmPrompt: (strings: TemplateStringsArray, ...values: any[]) => {
          return strings.reduce((acc, str, i) => acc + str + (values[i] || ''), '');
        },
        llm: vi.fn().mockRejectedValue(new Error('LLM error')),
      });

      const request: CodexRequest = {
        prompt: 'Create a test function',
        context: { language: 'python', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response).toBeDefined();
      expect(response.code).toContain('def ');
      expect(response.code).toContain('"""');
    });

    it('should generate valid Python template', async () => {
      vi.stubGlobal('spark', {
        llmPrompt: (strings: TemplateStringsArray, ...values: any[]) => {
          return strings.reduce((acc, str, i) => acc + str + (values[i] || ''), '');
        },
        llm: vi.fn().mockRejectedValue(new Error('LLM error')),
      });

      const request: CodexRequest = {
        prompt: 'Create a data processing function',
        context: { language: 'python', tier: 'B' },
      };

      const response = await client.generateCode(request);

      expect(response.code).toContain('def ');
      expect(response.code).toContain('try:');
      expect(response.code).toContain('except');
      expect(response.code).toContain('return');
    });

    it('should generate valid JavaScript/TypeScript template', async () => {
      vi.stubGlobal('spark', {
        llmPrompt: (strings: TemplateStringsArray, ...values: any[]) => {
          return strings.reduce((acc, str, i) => acc + str + (values[i] || ''), '');
        },
        llm: vi.fn().mockRejectedValue(new Error('LLM error')),
      });

      const request: CodexRequest = {
        prompt: 'Create an async function',
        context: { language: 'javascript', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response.code).toContain('async function');
      expect(response.code).toContain('try {');
      expect(response.code).toContain('catch');
      expect(response.code).toContain('return');
    });
  });

  describe('Status Checking', () => {
    it('should return healthy status', async () => {
      const status = await client.getStatus();

      expect(status.healthy).toBe(true);
      expect(status.mode).toBe('AI-Powered');
      expect(status.model).toContain('gpt-4o-mini');
    });

    it('should indicate Spark Runtime model', async () => {
      const status = await client.getStatus();

      expect(status.model).toContain('Spark Runtime');
    });
  });

  describe('Multi-language Support', () => {
    it('should support Python code generation', async () => {
      const request: CodexRequest = {
        prompt: 'Create a hello world function',
        context: { language: 'python', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response.code).toBeTruthy();
      expect(response.metadata).toBeDefined();
    });

    it('should support JavaScript/TypeScript code generation', async () => {
      const request: CodexRequest = {
        prompt: 'Create an async function',
        context: { language: 'typescript', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response.code).toBeTruthy();
      expect(response.metadata).toBeDefined();
    });
  });

  describe('Performance Metrics', () => {
    it('should track processing time', async () => {
      const request: CodexRequest = {
        prompt: 'Create a function',
        context: { language: 'python', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response.metadata.processing_time_ms).toBeGreaterThan(0);
    });

    it('should include coherence metric', async () => {
      const request: CodexRequest = {
        prompt: 'Create a function',
        context: { language: 'python', tier: 'A' },
      };

      const response = await client.generateCode(request);

      expect(response.metadata.coherence).toBeGreaterThan(0.6);
      expect(response.metadata.coherence).toBeLessThanOrEqual(1.0);
    });
  });
});

