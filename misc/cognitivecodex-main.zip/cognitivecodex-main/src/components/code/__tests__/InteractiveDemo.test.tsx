import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { InteractiveDemo } from '../InteractiveDemo';

const mockSpark = {
  llmPrompt: vi.fn((strings: TemplateStringsArray, ...values: any[]) => {
    return strings.reduce((acc, str, i) => acc + str + (values[i] || ''), '');
  }),
  llm: vi.fn(),
};

(global as any).spark = mockSpark;

describe('InteractiveDemo - Interactive Execution (18 tests)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockSpark.llm.mockResolvedValue('Hello from Codex AI!\nExecution completed successfully.\n');
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.useRealTimers();
  });

  describe('Component Rendering (4 tests)', () => {
    it('should render code editor with syntax highlighting', () => {
      render(<InteractiveDemo script='print("Hello")' language="python" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toBeInTheDocument();
      expect(textarea).toHaveValue('print("Hello")');
    });

    it('should show execution controls (Run, Clear)', () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      expect(screen.getByRole('button', { name: /run/i })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /clear/i })).toBeInTheDocument();
    });

    it('should display status badge (Idle, Running, Success, Failed)', () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      expect(screen.getByText('Idle')).toBeInTheDocument();
    });

    it('should render resource metrics panel', () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      expect(screen.getByText(/cpu/i)).toBeInTheDocument();
      expect(screen.getByText(/memory/i)).toBeInTheDocument();
      expect(screen.getByText(/time/i)).toBeInTheDocument();
    });
  });

  describe('Code Execution Simulation (6 tests)', () => {
    it('should execute code and display output', async () => {
      render(<InteractiveDemo script='print("Hello World")' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        expect(screen.getByText(/Hello from Codex AI!/i)).toBeInTheDocument();
      }, { timeout: 5000 });
    });

    it('should show running status during execution', async () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(100);

      await waitFor(() => {
        expect(screen.getByText('Running')).toBeInTheDocument();
      });
    });

    it('should update progress indicator (0% → 100%)', async () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(1500);

      const progressBars = screen.getAllByRole('progressbar');
      expect(progressBars.length).toBeGreaterThan(0);
    });

    it('should calculate realistic execution time', async () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        const timeElements = screen.queryAllByText(/\d+ms/);
        expect(timeElements.length).toBeGreaterThan(0);
      }, { timeout: 5000 });
    });

    it('should track CPU and memory usage', async () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        const cpuElement = screen.queryByText(/cpu/i);
        expect(cpuElement).toBeInTheDocument();
      }, { timeout: 5000 });
    });

    it('should display timestamp of execution', async () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        expect(mockSpark.llm).toHaveBeenCalled();
      }, { timeout: 5000 });
    });
  });

  describe('Output Display (3 tests)', () => {
    it('should show stdout in Output tab', async () => {
      render(<InteractiveDemo script='print("Output test")' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        expect(screen.getByRole('tab', { name: /output/i })).toBeInTheDocument();
      }, { timeout: 5000 });
    });

    it('should show stderr in Errors tab', async () => {
      mockSpark.llm.mockResolvedValue('ERROR: Something went wrong\n');
      
      render(<InteractiveDemo script='raise Exception("Error")' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        expect(screen.getByRole('tab', { name: /errors/i })).toBeInTheDocument();
      }, { timeout: 5000 });
    });

    it('should switch between Output and Errors tabs', () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      const outputTab = screen.getByRole('tab', { name: /output/i });
      const errorsTab = screen.getByRole('tab', { name: /errors/i });

      expect(outputTab).toBeInTheDocument();
      expect(errorsTab).toBeInTheDocument();

      fireEvent.click(errorsTab);
      expect(errorsTab).toHaveAttribute('data-state', 'active');
    });
  });

  describe('Error Handling (2 tests)', () => {
    it('should display error status for failed execution', async () => {
      mockSpark.llm.mockRejectedValue(new Error('Execution failed'));
      
      render(<InteractiveDemo script='invalid code' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        expect(screen.getByText('Failed')).toBeInTheDocument();
      }, { timeout: 5000 });
    });

    it('should show error messages in stderr', async () => {
      mockSpark.llm.mockRejectedValue(new Error('Syntax error'));
      
      render(<InteractiveDemo script='invalid syntax' language="python" />);

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        expect(screen.getByText('Failed')).toBeInTheDocument();
      }, { timeout: 5000 });
    });
  });

  describe('Code Editing (2 tests)', () => {
    it('should allow user to edit code', () => {
      render(<InteractiveDemo script='print("Original")' language="python" />);

      const textarea = screen.getByRole('textbox') as HTMLTextAreaElement;
      fireEvent.change(textarea, { target: { value: 'print("Modified")' } });

      expect(textarea.value).toBe('print("Modified")');
    });

    it('should execute edited code correctly', async () => {
      render(<InteractiveDemo script='print("Original")' language="python" />);

      const textarea = screen.getByRole('textbox');
      fireEvent.change(textarea, { target: { value: 'print("New code")' } });

      const runButton = screen.getByRole('button', { name: /run/i });
      fireEvent.click(runButton);

      await vi.advanceTimersByTimeAsync(3500);

      await waitFor(() => {
        expect(mockSpark.llm).toHaveBeenCalled();
        const callArg = mockSpark.llm.mock.calls[0][0];
        expect(callArg).toContain('print("New code")');
      }, { timeout: 5000 });
    });
  });

  describe('Resource Monitoring (1 test)', () => {
    it('should display CPU, Memory, and Time metrics with icons', () => {
      render(<InteractiveDemo script='print("Test")' language="python" />);

      expect(screen.getByText(/cpu/i)).toBeInTheDocument();
      expect(screen.getByText(/memory/i)).toBeInTheDocument();
      expect(screen.getByText(/time/i)).toBeInTheDocument();
    });
  });
});
