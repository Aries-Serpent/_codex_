import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { CodeGenerator } from '../CodeGenerator';
import { CodexAPIClient } from '@/lib/codex-api-client';
import { MockCodexAPIClient } from '@/lib/mock-api-client';

vi.mock('@/lib/codex-api-client');
vi.mock('@/lib/mock-api-client');
vi.mock('sonner', () => ({
  toast: {
    success: vi.fn(),
    error: vi.fn(),
  },
}));

describe('CodeGenerator - Lazy Initialization Tests (PR #2705)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    delete import.meta.env.VITE_CODEX_KEY;
    delete import.meta.env.VITE_CODEX_API;
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('Test 2: No API Key Scenario', () => {
    beforeEach(() => {
      import.meta.env.VITE_CODEX_KEY = undefined;
      
      vi.mocked(MockCodexAPIClient).mockImplementation(() => ({
        getStatus: vi.fn().mockResolvedValue({ healthy: true, metrics: {} }),
        generateCode: vi.fn().mockResolvedValue({
          code: 'def hello():\n    print("Hello")',
          metadata: {
            k1_factor: 0.5000,
            coherence: 0.685,
            cache_hit: false,
            processing_time_ms: 150,
          },
          quantum_metrics: {
            superposition_states: 3,
            entanglement_score: 0.42,
          },
        }),
      } as any));
    });

    it('should display info message when API key is missing', async () => {
      render(<CodeGenerator />);

      await waitFor(() => {
        const infoElement = screen.queryByText(/using demo mode/i);
        expect(infoElement).toBeInTheDocument();
      }, { timeout: 3000 });
    });

    it('should show "Connected" status with mock fallback', async () => {
      render(<CodeGenerator />);

      await waitFor(() => {
        expect(screen.getByText(/connected/i)).toBeInTheDocument();
      }, { timeout: 3000 });

      const errorMessage = screen.queryByText(/unable to connect/i);
      expect(errorMessage).not.toBeInTheDocument();
    });

    it('should enable generate button with mock fallback', async () => {
      render(<CodeGenerator />);

      await waitFor(() => {
        expect(screen.getByText(/connected/i)).toBeInTheDocument();
      });

      const textarea = screen.getByPlaceholderText(/example: create a fastapi/i);
      fireEvent.change(textarea, { target: { value: 'Create a hello world function' } });

      const generateButton = screen.getByRole('button', { name: /generate code/i });
      
      await waitFor(() => {
        expect(generateButton).not.toBeDisabled();
      });
    });
  });

  describe('Test 3: With API Key Scenario', () => {
    beforeEach(() => {
      import.meta.env.VITE_CODEX_KEY = 'test-api-key-12345';
      import.meta.env.VITE_CODEX_API = 'http://localhost:8000';

      vi.mocked(CodexAPIClient).mockImplementation(() => ({
        getStatus: vi.fn().mockResolvedValue({ healthy: true, metrics: {} }),
        generateCode: vi.fn().mockResolvedValue({
          code: 'def hello():\n    print("Hello")',
          metadata: {
            k1_factor: 0.3500,
            coherence: 0.685,
            cache_hit: true,
            processing_time_ms: 120,
          },
          quantum_metrics: {
            superposition_states: 5,
            entanglement_score: 0.78,
          },
        }),
      } as any));
    });

    it('should show "Checking..." status initially', () => {
      render(<CodeGenerator />);
      
      expect(screen.getByText(/checking\.\.\./i)).toBeInTheDocument();
    });

    it('should transition to "Connected" or "Error" status', async () => {
      render(<CodeGenerator />);

      await waitFor(() => {
        const connectedText = screen.queryByText(/connected/i);
        const errorText = screen.queryByText(/error/i);
        expect(connectedText || errorText).toBeInTheDocument();
      }, { timeout: 3000 });
    });

    it('should enable generate button after status check completes', async () => {
      render(<CodeGenerator />);

      await waitFor(() => {
        expect(screen.getByText(/connected/i)).toBeInTheDocument();
      });

      const textarea = screen.getByPlaceholderText(/example: create a fastapi/i);
      fireEvent.change(textarea, { target: { value: 'Create a Python function' } });

      const generateButton = screen.getByRole('button', { name: /generate code/i });
      
      await waitFor(() => {
        expect(generateButton).not.toBeDisabled();
      });
    });
  });

  describe('Test 4: Mock Fallback Scenario', () => {
    beforeEach(() => {
      import.meta.env.VITE_CODEX_KEY = 'invalid-key-will-fail-auth';
      
      vi.mocked(CodexAPIClient).mockImplementation(() => ({
        getStatus: vi.fn().mockRejectedValue(new Error('401 Unauthorized')),
        generateCode: vi.fn().mockRejectedValue(new Error('401 Unauthorized')),
      } as any));

      vi.mocked(MockCodexAPIClient).mockImplementation(() => ({
        getStatus: vi.fn().mockResolvedValue({ healthy: true, metrics: {} }),
        generateCode: vi.fn().mockResolvedValue({
          code: 'def add(a, b):\n    return a + b',
          metadata: {
            k1_factor: 0.5000,
            coherence: 0.685,
            cache_hit: false,
            processing_time_ms: 150,
          },
          quantum_metrics: {
            superposition_states: 3,
            entanglement_score: 0.42,
          },
        }),
      } as any));
    });

    it('should accept prompt input of at least 10 characters', async () => {
      render(<CodeGenerator />);

      const textarea = screen.getByPlaceholderText(/example: create a fastapi/i);
      
      fireEvent.change(textarea, { target: { value: 'Short' } });
      expect(screen.getByText(/5 \/ 5000/)).toBeInTheDocument();
      expect(screen.getByText(/\(min: 10\)/)).toBeInTheDocument();

      fireEvent.change(textarea, { target: { value: 'Create a hello world function' } });
      expect(screen.getByText(/29 \/ 5000/)).toBeInTheDocument();
      expect(screen.queryByText(/\(min: 10\)/)).not.toBeInTheDocument();
    });

    it('should show character count and validation', () => {
      render(<CodeGenerator />);

      const textarea = screen.getByPlaceholderText(/example: create a fastapi/i);
      
      fireEvent.change(textarea, { target: { value: 'Test' } });
      expect(screen.getByText(/4 \/ 5000/)).toBeInTheDocument();
      
      fireEvent.change(textarea, { target: { value: 'Valid prompt with sufficient length' } });
      expect(screen.getByText(/36 \/ 5000/)).toBeInTheDocument();
    });

    it('should have copy and download buttons after generation', async () => {
      render(<CodeGenerator />);

      await waitFor(() => {
        expect(screen.getByText(/connected/i)).toBeInTheDocument();
      });

      const textarea = screen.getByPlaceholderText(/example: create a fastapi/i);
      fireEvent.change(textarea, { target: { value: 'Create a Python function to add two numbers' } });

      const generateButton = screen.getByRole('button', { name: /generate code/i });
      fireEvent.click(generateButton);

      await waitFor(() => {
        expect(screen.getByRole('button', { name: /copy/i })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: /download/i })).toBeInTheDocument();
      }, { timeout: 5000 });
    });
  });

  describe('Test 5: Environment Variable Configuration', () => {
    it('should render component regardless of VITE_STAGE_EXECUTION_TIME_MS', () => {
      import.meta.env.VITE_STAGE_EXECUTION_TIME_MS = '200';
      
      const { container } = render(<CodeGenerator />);
      expect(container).toBeInTheDocument();
      
      delete import.meta.env.VITE_STAGE_EXECUTION_TIME_MS;
    });

    it('should handle various VITE_CODEX_API configurations', () => {
      const apiUrls = [
        'http://localhost:8000',
        'https://api.example.com',
        undefined,
      ];

      apiUrls.forEach(url => {
        import.meta.env.VITE_CODEX_API = url;
        const { container } = render(<CodeGenerator />);
        expect(container).toBeInTheDocument();
      });
    });
  });

  describe('Component Structure Validation', () => {
    it('should render all expected UI sections', () => {
      render(<CodeGenerator />);

      expect(screen.getByText(/code generation/i)).toBeInTheDocument();
      expect(screen.getByText(/api status/i)).toBeInTheDocument();
      expect(screen.getByPlaceholderText(/example: create a fastapi/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /generate code/i })).toBeInTheDocument();
    });

    it('should show character count with proper formatting', () => {
      render(<CodeGenerator />);

      const textarea = screen.getByPlaceholderText(/example: create a fastapi/i);
      
      expect(screen.getByText(/0 \/ 5000/)).toBeInTheDocument();
      
      fireEvent.change(textarea, { target: { value: 'Test' } });
      expect(screen.getByText(/4 \/ 5000/)).toBeInTheDocument();
    });

    it('should apply correct styling based on validation state', () => {
      render(<CodeGenerator />);

      const textarea = screen.getByPlaceholderText(/example: create a fastapi/i);
      
      fireEvent.change(textarea, { target: { value: 'Short' } });
      
      expect(textarea).toHaveClass('border-destructive');
      
      fireEvent.change(textarea, { target: { value: 'Valid prompt with sufficient length' } });
      
      expect(textarea).not.toHaveClass('border-destructive');
    });
  });
});
