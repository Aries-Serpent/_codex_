#!/bin/bash

echo "Running test suite..."
cd /workspaces/spark-template

# Run tests with coverage
npm test -- --coverage --reporter=verbose 2>&1 | tee test-results.txt

echo ""
echo "===== TEST EXECUTION COMPLETE ====="
echo ""
echo "Check test-results.txt for full output"
