# [Report]: Capability Matrix  
> Generated: 2025-12-05 20:59:43 UTC | Author: audit_system  
 Roles: [Primary: Automated Auditor], [Secondary: Provenance Engine]  Energy: 5  

## 1. Summary
Total Capabilities: 39
Low Maturity (< 0.7) : 16

## 2. Capability Scores
| ID | Score | Functionality | Consistency | Tests | Safeguards | Docs | Evidence Count |
|----|-------|--------------:|------------:|------:|-----------:|-----:|---------------:|
| archival-bundling | 0.76 | 1.00 | 0.89 | 0.25 | 0.83 | 1.00 | 201 |
| checkpointing | 0.87 | 1.00 | 0.88 | 0.68 | 0.83 | 1.00 | 106 |
| ci-cd-pipeline | 0.85 | 1.00 | 0.92 | 0.47 | 1.00 | 1.00 | 310 |
| code-quality-tooling | 0.83 | 1.00 | 0.87 | 0.52 | 0.83 | 1.00 | 238 |
| configuration | 0.76 | 1.00 | 0.77 | 0.22 | 1.00 | 1.00 | 282 |
| data-pipeline | 0.80 | 1.00 | 0.88 | 0.41 | 0.83 | 1.00 | 181 |
| deployment-infrastructure | 0.65 | 0.80 | 0.68 | 0.14 | 0.83 | 1.00 | 63 |
| documentation-system | 0.68 | 0.75 | 0.94 | 0.00 | 1.00 | 1.00 | 635 |
| duplication_ratio | 0.40 | 0.00 | 0.79 | 0.28 | 1.00 | 0.13 | 4299 |
| evaluation-metrics | 0.82 | 1.00 | 0.88 | 0.46 | 0.83 | 1.00 | 135 |
| example-evidence-v2 | 1.16 | 2.00 | 0.88 | 0.71 | 1.00 | 1.00 | 112 |
| experiment-management | 0.80 | 1.00 | 0.79 | 0.35 | 1.00 | 1.00 | 159 |
| inference-serving | 0.63 | 0.33 | 0.80 | 0.44 | 0.83 | 1.00 | 25 |
| logging-tracking | 0.80 | 1.00 | 0.84 | 0.31 | 1.00 | 1.00 | 298 |
| mcp-authz-authn | 0.83 | 1.50 | 0.96 | 0.46 | 0.83 | 0.16 | 24 |
| mcp-configuration | 0.63 | 1.00 | 0.80 | 0.41 | 0.67 | 0.16 | 54 |
| mcp-error-handling | 0.97 | 2.00 | 0.92 | 0.54 | 0.83 | 0.16 | 13 |
| mcp-lifecycle-management | 0.22 | 0.00 | 1.00 | 0.00 | 0.00 | 0.16 | 0 |
| mcp-multi-tenant | 0.65 | 1.00 | 1.00 | 0.60 | 0.17 | 0.16 | 5 |
| mcp-observability | 0.92 | 2.00 | 0.87 | 0.29 | 1.00 | 0.16 | 790 |
| mcp-protocol-surface | 0.67 | 1.00 | 0.87 | 0.40 | 0.83 | 0.16 | 15 |
| mcp-rate-limiting | 0.94 | 2.00 | 0.83 | 0.50 | 0.83 | 0.16 | 30 |
| mcp-schema-validation | 0.61 | 1.00 | 0.86 | 0.14 | 0.83 | 0.16 | 58 |
| mcp-security-safeguards | 0.64 | 1.00 | 0.93 | 0.12 | 1.00 | 0.16 | 329 |
| mcp-tooling-registry | 0.62 | 1.00 | 0.88 | 0.50 | 0.33 | 0.16 | 8 |
| mcp-tools-integration | 0.65 | 1.00 | 0.94 | 0.15 | 1.00 | 0.16 | 411 |
| mcp-versioning-compat | 0.89 | 2.00 | 1.00 | 0.57 | 0.17 | 0.16 | 7 |
| ml-serving | 0.88 | 1.00 | 0.79 | 0.70 | 1.00 | 1.00 | 111 |
| peft_hooks | 0.46 | 1.00 | 1.00 | 0.00 | 0.00 | 0.06 | 0 |
| reproducibility | 0.86 | 1.00 | 0.89 | 0.53 | 1.00 | 1.00 | 92 |
| safeguards_keywords | 0.45 | 1.00 | 1.00 | 0.00 | 0.00 | 0.02 | 0 |
| safety-security | 0.73 | 1.00 | 0.86 | 0.33 | 0.50 | 1.00 | 51 |
| status-reporting | 0.76 | 1.00 | 0.90 | 0.11 | 1.00 | 1.00 | 502 |
| structural-integrity | 0.58 | 1.00 | 0.90 | 0.00 | 0.67 | 0.32 | 10 |
| testing-infrastructure | 0.91 | 0.75 | 0.89 | 0.99 | 1.00 | 1.00 | 1208 |
| tokenization | 0.80 | 1.00 | 0.83 | 0.53 | 0.67 | 1.00 | 116 |
| training-engine | 0.83 | 1.00 | 0.85 | 0.44 | 1.00 | 1.00 | 246 |
| unified-training | 0.84 | 1.00 | 0.60 | 1.00 | 0.50 | 1.00 | 5 |
| vector-stores | 0.49 | 0.00 | 1.00 | 1.00 | 0.00 | 0.27 | 3 |

## 3. Low Maturity Focus
| ID | Score | Primary Deficit |
|----|-------|-----------------|
| deployment-infrastructure | 0.65 | tests |
| documentation-system | 0.68 | tests |
| duplication_ratio | 0.40 | functionality |
| inference-serving | 0.63 | functionality |
| mcp-configuration | 0.63 | documentation |
| mcp-lifecycle-management | 0.22 | functionality |
| mcp-multi-tenant | 0.65 | documentation |
| mcp-protocol-surface | 0.67 | documentation |
| mcp-schema-validation | 0.61 | tests |
| mcp-security-safeguards | 0.64 | tests |
| mcp-tooling-registry | 0.62 | documentation |
| mcp-tools-integration | 0.65 | tests |
| peft_hooks | 0.46 | tests |
| safeguards_keywords | 0.45 | tests |
| structural-integrity | 0.58 | tests |
| vector-stores | 0.49 | functionality |

## 4. Weight Reference
| Component | Weight |
|-----------|-------:|
| functionality | 0.25 |
| consistency | 0.20 |
| tests | 0.25 |
| safeguards | 0.15 |
| documentation | 0.15 |

## 5. Capability Detail Sections
### archival-bundling
Score: 0.7643

Components:
- Functionality: 1.0
- Consistency: 0.885572
- Tests: 0.248756
- Safeguards: 0.833333
- Documentation: 1.0

Meta:
- layer: storage
- priority: high
- category: reproducibility
- missing_detectors: ['archive', 'bundle', 'manifest']

Patterns Found: archive, bundle, manifest

Evidence Files (first 10):
```
.codex/archive/README_UPDATED.md
.codex/copilot_bridge/manifests/bridge_manifest.schema.json
.codex/copilot_bridge/var/manifests/.gitkeep
.codex/evidence/archive_ops.jsonl
.codex/evidence/artifacts/archive_plan_root_cleanup_2025-10-17.json
.codex/reports/Archive_Policy_Operations.md
.codex/reports/archive_policy_operations.md
.codex/reports/merge_summary_archive_policy_20251024.txt
.codex/status/manifest-2025-09-22T02-15-21Z.json
.codex/validation/20250910T052842Z/post_manifest.json
```
### checkpointing
Score: 0.8703

Components:
- Functionality: 1.0
- Consistency: 0.877358
- Tests: 0.679245
- Safeguards: 0.833333
- Documentation: 1.0


Patterns Found: load, save_checkpoint

Evidence Files (first 10):
```
codex_ml/utils/checkpointing.py
configs/schemas/checkpoint_manifest.schema.json
docs/CHECKPOINTS.md
docs/checkpoint_integrity.md
docs/checkpoint_schema_v2.md
docs/guides/CHECKPOINT_SAFETY.md
docs/guides/checkpointing.md
docs/how-to/checkpoint_metadata.md
docs/modules/checkpoint_manager.md
docs/training/Checkpointing_Surfaces.md
```
### ci-cd-pipeline
Score: 0.8508

Components:
- Functionality: 1.0
- Consistency: 0.919355
- Tests: 0.467742
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- github_actions: 44
- pre_commit_hooks: 3
- ci_configs: 2
- validation_scripts: 261
- note: GitHub Actions present but not activated per AGENTS.md

Patterns Found: automation, ci, pre-commit, validation, workflow

Evidence Files (first 10):
```
.codex/smoke/import_check.py
.github/scripts/validate_agents_infrastructure.sh
.github/workflows/archive-gates.yml.disabled
.github/workflows/audit_chain.yml
.github/workflows/automation_ingest.yml
.github/workflows/capability-audit.yml
.github/workflows/ci.yml
.github/workflows/container-build.yml
.github/workflows/coverage_report.yml
.github/workflows/daily_status_cron.yml
```
### code-quality-tooling
Score: 0.8292

Components:
- Functionality: 1.0
- Consistency: 0.869748
- Tests: 0.521008
- Safeguards: 0.833333
- Documentation: 1.0

Meta:
- formatters: 2
- linters: 5
- type_checkers: 9
- security_scanners: 159
- quality_scripts: 68

Patterns Found: format, lint, quality, security-scan, type-check

Evidence Files (first 10):
```
.bandit.yaml
.bandit.yml
.codex/evidence/phase5_privacy_safety.jsonl
.codex/ruff.json
.editorconfig
.github/ISSUE_TEMPLATE/security.yml
.github/ISSUE_TEMPLATE/security_gap.md
.github/docs/DEPLOYMENT_ORCHESTRATION_SECURITY_SUMMARY.md
.github/docs/Security_Gates_Copilot.md
.github/docs/Security_Session_Copilot.md
```
### configuration
Score: 0.7580

Components:
- Functionality: 1.0
- Consistency: 0.769504
- Tests: 0.216312
- Safeguards: 1.0
- Documentation: 1.0


Patterns Found: config, hydra

Evidence Files (first 10):
```
.codex/copilot_bridge/config/bridge.config.json
.codex/evidence/phase4_hydra_check.jsonl
.codex/hydra_last/config.yaml
.editorconfig
.github/ISSUE_TEMPLATE/config.yml
.github/docs/ARCHIVE_CONFIG_ADR.md
.github/docs/SBOM_Config_InstructionEnhancement.md
.pre-commit-config.yaml
agents/codex_client/codex_client/config.py
agents/codex_client/tests/test_config.py
```
### data-pipeline
Score: 0.8029

Components:
- Functionality: 1.0
- Consistency: 0.878453
- Tests: 0.40884
- Safeguards: 0.833333
- Documentation: 1.0


Patterns Found: loader, split

Evidence Files (first 10):
```
.github/workflows/data_validation.yml
codex_ml/data/checksums.py
conf/data/local.yaml
configs/deployment/hhg_logistics/data/default.yaml
configs/schemas/data.schema.yaml
configs/schemas/dataset_manifest.schema.json
configs/training/data/base.yaml
configs/training/data/offline/tiny_corpus.yaml
configs/training/data/tiny.yaml
data/.gitkeep
```
### deployment-infrastructure
Score: 0.6472

Components:
- Functionality: 0.8
- Consistency: 0.68254
- Tests: 0.142857
- Safeguards: 0.833333
- Documentation: 1.0

Meta:
- docker_configs: 9
- k8s_manifests: 0
- helm_charts: 2
- service_definitions: 49
- deploy_scripts: 3

Patterns Found: deploy, docker, helm, service

Evidence Files (first 10):
```
.dockerignore
Dockerfile
Dockerfile.gpu
Dockerfile.local
Dockerfile.local-codex-env
deploy/helm/Chart.yaml
deploy/helm/values.yaml
deploy/interactive_entrypoint.sh
deploy/setup_universal.sh
docker-compose.yml
```
### documentation-system
Score: 0.6758

Components:
- Functionality: 0.75
- Consistency: 0.935433
- Tests: 0.004724
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- markdown_count: 633
- rst_count: 0
- config_count: 1
- total_docs: 635

Patterns Found: docs, markdown, mkdocs

Evidence Files (first 10):
```
README.md
docs/ARCHITECTURE.md
docs/Architecture.md
docs/CHANGELOG.md
docs/CHANGELOG/change_log.md
docs/CHANGELOG/changelog_codex.md
docs/CHANGELOG/changelog_session_logging.md
docs/CHECKPOINTS.md
docs/CLI.md
docs/CODEX_STRUCTURE_CONSOLIDATION_PROMPT.md
```
### duplication_ratio
Score: 0.3967

Components:
- Functionality: 0.0
- Consistency: 0.788323
- Tests: 0.280298
- Safeguards: 1.0
- Documentation: 0.126183


Patterns Found: None

Evidence Files (first 10):
```
.bandit.yaml
.bandit.yml
.codex/DO_NOT_ACTIVATE_ACTIONS.txt
.codex/DO_NOT_ACTIVATE_GITHUB_ACTIONS
.codex/GATES_REPORT.txt
.codex/README.md
.codex/README.md.bak
.codex/action_log.ndjson
.codex/analysis_metrics.jsonl
.codex/archive/README_UPDATED.md
```
### evaluation-metrics
Score: 0.8161

Components:
- Functionality: 1.0
- Consistency: 0.881481
- Tests: 0.459259
- Safeguards: 0.833333
- Documentation: 1.0


Patterns Found: metric, perplexity

Evidence Files (first 10):
```
.github/docs/PostMergeValidation_IssueTemplate_InstructionEnhancement.md
IMPLEMENTATION_COMPLETE_EVALUATION_LOOP.md
VERIFICATION_REPORT_EVALUATION_LOOP.md
conf/evaluation/minimal.yaml
conf/minimal_eval.yaml
configs/deployment/hhg_logistics/eval/default.yaml
configs/evaluation/base.yaml
configs/evaluation/default.yaml
configs/evaluation/metrics/offline/weighted_accuracy.yaml
configs/evaluation/offline.yaml
```
### example-evidence-v2
Score: 1.1554

Components:
- Functionality: 2.0
- Consistency: 0.883929
- Tests: 0.714286
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- detector_version: v2
- source: example_v2
- _evidence_v2: [{'path': 'codex_ml/utils/checkpointing.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/checkpointing/__init__.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/checkpointing/atomic_io.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/checkpointing/best_k_retention.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/checkpointing/bestk.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/checkpointing/checkpoint_core.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/checkpointing/compat.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/checkpointing/schema_v2.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/checkpointing/utils.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/cli/checkpoint_validate.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/serving/inference_server.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/telemetry/server.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/training/rng_checkpoint.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/utils/checkpoint.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/utils/checkpoint_core.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/utils/checkpoint_event.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/utils/checkpoint_integrity.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/utils/checkpoint_manager.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/utils/checkpoint_retention.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/codex_ml/utils/checkpointing.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/hhg_logistics/monitor/serve_report.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/hhg_logistics/serve/__init__.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/hhg_logistics/serve/app.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/hhg_logistics/serve/smoke.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/mcp/server/__init__.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/training/checkpoint_manager.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/training/checkpointing.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/utils/checkpoint.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'src/utils/checkpointing.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'temp/bridge_codex_copilot_bridge/mcp/server/main.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'temp/bridge_codex_copilot_bridge/mcp/server/server.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'test_mcp_server.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_checkpoint_integrity_tolerant.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_checkpoint_integrity_wiring.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_checkpoint_load_roundtrip.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_checkpoint_peft_state.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_checkpoint_schema.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_integrity_snapshot.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_no_direct_atomic_write_usage.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_run_metadata_sidecar.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_runmeta_enrichment.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpoint/test_state_providers.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/__init__.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_atomic_io.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_atomic_write.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_atomicity_and_resume.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_best_not_pruned.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_best_promotion.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_bestk.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_canonical_json.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_checkpoint_comprehensive.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_checkpoint_core_io.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_checkpoint_json_event.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_checkpoint_retention.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_checkpoint_schema_and_compat.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_checkpointing_compat.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_corrupt_checkpoint_load.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_load_latest.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_meta_schema.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_periodic_and_trim.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_resume_optimizer_rng_equivalence.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_retention_and_digest.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_retention_local.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_rng_state_checkpoint.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_rng_state_roundtrip.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_roundtrip.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_schema_v2_basic.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_schema_v2_jcs_numbers.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/checkpointing/test_schema_v2_upgrade.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/cli/test_cli_checkpoint_validate.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/codex_ml/test_checkpoint_core.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/codex_ml/test_checkpoint_utils.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/codex_ml/test_inference_server.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/hhg_logistics/serve/test_app.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/mcp/test_server.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/smoke/test_checkpoint_hashing.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/telemetry/test_metrics_server.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_actions_server_smoke.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_bundle.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_checksum.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_checksum_and_retention.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_commit_meta.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_corrupt_load.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_corruption.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_integrity.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_integrity_corruption.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_manager.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_metadata.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_provenance.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_restore_rng_torch.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_roundtrip.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_save_resume.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_sha_rng.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_system_meta.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpoint_util.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpointing.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/test_checkpointing_utils_extra.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/training/test_checkpoint_compat.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/training/test_checkpoint_integrity.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/training/test_checkpoint_manager_basic.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/training/test_checkpoint_manager_callback.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/training/test_checkpoint_manifest.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/training/test_checkpoint_resume.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/training/test_checkpoint_rng_restore.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/utils/test_checkpoint_remote.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/utils/test_checkpoint_rng.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/utils/test_checkpointing.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/utils/test_checkpointing_core.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tests/utils/test_checkpointing_safe_load.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tools/actions_server.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'tools/validate_checkpoint.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}, {'path': 'training/checkpoint_manager.py', 'sha': None, 'ranges': [{'start_line': 1, 'end_line': 40}], 'confidence': 0.9, 'excerpt': None}]

Patterns Found: checkpoint, serve

Evidence Files (first 10):
```
codex_ml/utils/checkpointing.py
src/codex_ml/checkpointing/__init__.py
src/codex_ml/checkpointing/atomic_io.py
src/codex_ml/checkpointing/best_k_retention.py
src/codex_ml/checkpointing/bestk.py
src/codex_ml/checkpointing/checkpoint_core.py
src/codex_ml/checkpointing/compat.py
src/codex_ml/checkpointing/schema_v2.py
src/codex_ml/checkpointing/utils.py
src/codex_ml/cli/checkpoint_validate.py
```
### experiment-management
Score: 0.7965

Components:
- Functionality: 1.0
- Consistency: 0.792453
- Tests: 0.352201
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- mlflow_integration: 38
- wandb_integration: 4
- experiment_utils: 30
- metadata_files: 89

Patterns Found: experiment, metadata, mlflow, tracking, wandb

Evidence Files (first 10):
```
.codex/copilot_bridge/manifests/bridge_manifest.schema.json
.codex/copilot_bridge/var/manifests/.gitkeep
.codex/evidence/provenance/root-cleanup/intoto.jsonl
.codex/evidence/provenance/root-cleanup/slsa.json
.codex/status/manifest-2025-09-22T02-15-21Z.json
.codex/status/provenance.json
.codex/validation/20250910T052842Z/post_manifest.json
.codex/validation/20250910T052842Z/pre_manifest.json
.codex/validation/20250910T071257Z/post_manifest.json
.codex/validation/20250910T071257Z/pre_manifest.json
```
### inference-serving
Score: 0.6283

Components:
- Functionality: 0.333333
- Consistency: 0.8
- Tests: 0.44
- Safeguards: 0.833333
- Documentation: 1.0

Meta:
- layer: serving
- interface: http

Patterns Found: serve

Evidence Files (first 10):
```
.codex/copilot_bridge/bridge/server.js
configs/deployment/hhg_logistics/serve/local.yaml
copilot/extension/server/index.js
docs/guides/inference_server_guide.md
scripts/local/serve_local.sh
src/codex_ml/serving/inference_server.py
src/codex_ml/telemetry/server.py
src/hhg_logistics/monitor/serve_report.py
src/hhg_logistics/serve/__init__.py
src/hhg_logistics/serve/app.py
```
### logging-tracking
Score: 0.7951

Components:
- Functionality: 1.0
- Consistency: 0.83557
- Tests: 0.312081
- Safeguards: 1.0
- Documentation: 1.0


Patterns Found: log, mlflow

Evidence Files (first 10):
```
.codex/action_log.ndjson
.codex/automation_out/change_log.md
.codex/automation_out/db_catalog.json
.codex/change_log-large.md
.codex/change_log.md
.codex/change_log_compare_report.json
.codex/codex_run.log
.codex/copilot_bridge/var/logs/.gitkeep
.codex/errors_codex.log
.codex/evidence/phase5_structured_logging.jsonl
```
### mcp-authz-authn
Score: 0.8299

Components:
- Functionality: 1.5
- Consistency: 0.958333
- Tests: 0.458333
- Safeguards: 0.833333
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['API-Key', 'authenticate', 'authorize']

Patterns Found: API-Key, authenticate, authorize

Evidence Files (first 10):
```
agents/codex_client/codex_client/bridge.py
scripts/deployment_orchestrator.py
scripts/space_traversal/detectors/mcp_authz_authn.py
services/api/main.py
services/ita/app/main.py
services/ita/app/security.py
services/ita/tests/test_contract.py
services/ita/tests/test_endpoints.py
src/mcp/__init__.py
src/mcp/auth.py
```
### mcp-configuration
Score: 0.6348

Components:
- Functionality: 1.0
- Consistency: 0.796296
- Tests: 0.407407
- Safeguards: 0.666667
- Documentation: 0.157729

Meta:
- category: mcp
- layer: infrastructure
- detector_version: 1.0
- config_types: ['mcp.json', 'environment', 'yaml', 'python']
- missing_detectors: ['config', 'environment', 'mcp.json']

Patterns Found: config, environment, mcp.json

Evidence Files (first 10):
```
.codex/codex.env.json
.codex/copilot_bridge/.env.example
.codex/copilot_bridge/config/bridge.config.json
.codex/flags.env
.codex/hydra_last/config.yaml
.env.docker.example
.env.example
.github/ISSUE_TEMPLATE/config.yml
.pre-commit-config.yaml
conf/config.yaml
```
### mcp-error-handling
Score: 0.9679

Components:
- Functionality: 2.0
- Consistency: 0.923077
- Tests: 0.538462
- Safeguards: 0.833333
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['HTTPException', 'MCPError', 'error']

Patterns Found: MCPError, error payload

Evidence Files (first 10):
```
scripts/space_traversal/detectors/mcp_error_handling.py
services/ita/app/main.py
src/mcp/__init__.py
src/mcp/errors.py
src/mcp/server/__init__.py
temp/bridge_codex_copilot_bridge/mcp/server/server.py
test_mcp_server.py
tests/mcp/test_error_handling_extended.py
tests/mcp/test_mcp_core_smoke.py
tests/mcp/test_observability.py
```
### mcp-lifecycle-management
Score: 0.2237

Components:
- Functionality: 0.0
- Consistency: 1.0
- Tests: 0.0
- Safeguards: 0.0
- Documentation: 0.157729

Meta:
- category: mcp
- priority: high
- framework: FastAPI
- detector_version: 1.0
- missing_detectors: ['healthz', 'shutdown', 'startup']

Patterns Found: None

Evidence Files (first 10):
```
```
### mcp-multi-tenant
Score: 0.6487

Components:
- Functionality: 1.0
- Consistency: 1.0
- Tests: 0.6
- Safeguards: 0.166667
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['isolation', 'tenant']

Patterns Found: tenant

Evidence Files (first 10):
```
policies/tenant_policy.schema.json
scripts/space_traversal/detectors/__pycache__/mcp_multi_tenant.cpython-310.pyc
scripts/space_traversal/detectors/mcp_multi_tenant.py
services/msp_gateway/middleware/tenant_context.py
tests/mcp/test_multi_tenant_extended.py
```
### mcp-observability
Score: 0.9194

Components:
- Functionality: 2.0
- Consistency: 0.870886
- Tests: 0.286076
- Safeguards: 1.0
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['logging', 'metrics', 'tracing']

Patterns Found: X-Request-Id, init_json_logging, metrics, prometheus

Evidence Files (first 10):
```
.codex/README.md
.codex/change_log-large.md
.codex/change_log.md
.codex/notes/CODEBASE_AUDIT.md
.codex/notes/Codex_Questions.md
.codex/notes/MERGE_NOTES.md
.codex/reports/PHASE2_FINAL_STATUS.md
.codex/results.md
.codex/run_repo_scout.py
.codex/status/_codex_status_update-2025-08-28.md
```
### mcp-protocol-surface
Score: 0.6720

Components:
- Functionality: 1.0
- Consistency: 0.866667
- Tests: 0.4
- Safeguards: 0.833333
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['FastAPI', 'endpoint', 'jsonrpc']

Patterns Found: FastAPI, jsonrpc

Evidence Files (first 10):
```
scripts/space_traversal/detectors/mcp_error_handling.py
scripts/space_traversal/detectors/mcp_lifecycle_management.py
scripts/space_traversal/detectors/mcp_protocol_surface.py
services/msp_gateway/app.py
src/codex/api/app.py
src/codex_ml/serving/inference_server.py
src/hhg_logistics/serve/app.py
src/mcp/errors.py
src/mcp/server/__init__.py
temp/bridge_codex_copilot_bridge/mcp/server/server.py
```
### mcp-rate-limiting
Score: 0.9403

Components:
- Functionality: 2.0
- Consistency: 0.833333
- Tests: 0.5
- Safeguards: 0.833333
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['RateLimiter', 'throttle']

Patterns Found: RateLimiter, rate_limit

Evidence Files (first 10):
```
scripts/ops/codex_mint_tokens_per_run.py
scripts/space_traversal/detectors/mcp_rate_limiting.py
services/api/main.py
services/ita/app/main.py
services/msp_gateway/config.py
services/msp_gateway/main.py
services/msp_gateway/middleware/__init__.py
services/msp_gateway/middleware/rate_limit.py
services/msp_gateway/middleware/tenant_context.py
src/codex/zendesk/monitoring/zendesk_metrics.py
```
### mcp-schema-validation
Score: 0.6056

Components:
- Functionality: 1.0
- Consistency: 0.862069
- Tests: 0.137931
- Safeguards: 0.833333
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['BaseModel', 'OpenAPI', 'schema']

Patterns Found: BaseModel, OpenAPI

Evidence Files (first 10):
```
actions/openapi.yaml
agents/codex_client/codex_client/models.py
configs/development/noxfile.py
conftest.py
noxfile.py
scripts/space_traversal/detectors/mcp_schema_validation.py
services/api/main.py
services/ita/app/models.py
services/ita/openapi.yaml
services/msp_gateway/config.py
```
### mcp-security-safeguards
Score: 0.6387

Components:
- Functionality: 1.0
- Consistency: 0.927052
- Tests: 0.118541
- Safeguards: 1.0
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['confirm', 'dry_run', 'sanitize']

Patterns Found: confirm, dry_run, sanitize

Evidence Files (first 10):
```
.codex/change_log-large.md
.codex/change_log.md
.codex/results.md
.codex/scripts/local_ci.py
.codex/status/_codex_status_update-2025-09-03.md
.codex/status/_codex_status_update-2025-09-04.md
.codex/status/_codex_status_update-2025-09-05.md
.codex/status/_codex_status_update-2025-09-07.md
.codex/status/_codex_status_update-2025-09-14.md
.codex/status/_codex_status_update-2025-09-15.md
```
### mcp-tooling-registry
Score: 0.6237

Components:
- Functionality: 1.0
- Consistency: 0.875
- Tests: 0.5
- Safeguards: 0.333333
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['registry', 'tools']

Patterns Found: mcp.json, registry

Evidence Files (first 10):
```
scripts/space_traversal/detectors/__pycache__/mcp_tooling_registry.cpython-310.pyc
scripts/space_traversal/detectors/mcp_tooling_registry.py
src/mcp/registry.py
temp/bridge_codex_copilot_bridge/mcp/examples/mcp.json
temp/bridge_codex_copilot_bridge/mcp/mcp.json
tests/mcp/test_registry.py
tests/tools/test_codex_gap_registry.py
tools/codex_gap_registry.py
```
### mcp-tools-integration
Score: 0.6496

Components:
- Functionality: 1.0
- Consistency: 0.944039
- Tests: 0.148418
- Safeguards: 1.0
- Documentation: 0.157729

Meta:
- layer: integration

Patterns Found: mcp, tool

Evidence Files (first 10):
```
.github/docs/_Copilot_MCP-MCPReviewFrom2286.md
.github/prompts/CODEX_MCP_COMPLETE_PATCHSETs.md
.github/prompts/MCP_AUDIT_AND_IMPLEMENTATION_PLAN.md
.github/prompts/MCP_MAPPING_OUTLINE.md
.github/prompts/Patchset_1-2_MCP_Core_Module_Integration.md
.github/prompts/mcp_core_module.md
MCP_100_PERCENT_ROADMAP.md
MCP_CAPABILITIES_REFERENCE.md
MCP_DEVELOPER_GUIDE.md
MCP_FAQ.md
```
### mcp-versioning-compat
Score: 0.8915

Components:
- Functionality: 2.0
- Consistency: 1.0
- Tests: 0.571429
- Safeguards: 0.166667
- Documentation: 0.157729

Meta:
- category: mcp
- missing_detectors: ['MCP_VERSIONS', 'negotiate_version']

Patterns Found: MCP_VERSIONS, negotiate_version

Evidence Files (first 10):
```
scripts/space_traversal/detectors/mcp_versioning_compat.py
src/mcp/server/__init__.py
src/mcp/versioning.py
test_mcp_server.py
tests/mcp/test_mcp_core_smoke.py
tests/mcp/test_protocol.py
tests/mcp/test_server.py
```
### ml-serving
Score: 0.8842

Components:
- Functionality: 1.0
- Consistency: 0.792793
- Tests: 0.702703
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- layer: inference
- priority: high
- category: deployment
- missing_detectors: ['api', 'predict', 'serve']

Patterns Found: api, predict, serve

Evidence Files (first 10):
```
.codex/copilot_bridge/bridge/server.js
P1_FIX_API_KEY_OPTIONAL.md
actions/openapi.yaml
configs/deployment/hhg_logistics/serve/local.yaml
copilot/extension/server/index.js
data/zendesk_api_index.json
docs/INFERENCE_PIPELINE.md
docs/INFERENCE_SERVING_GUIDE.md
docs/api.md
docs/api/README.md
```
### peft_hooks
Score: 0.4595

Components:
- Functionality: 1.0
- Consistency: 1.0
- Tests: 0.0
- Safeguards: 0.0
- Documentation: 0.063091

Meta:
- _evidence_v2: {'cli/script_polish.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'cli/train_codex.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'cli/update_runner.py': ['lora'], 'codex_addons/metrics/collector.py': ['lora'], 'codex_task_executor.py': ['lora'], 'models/chat_model.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'models/lora/_test_utils.py': ['LoraConfig', 'lora', 'peft'], 'models/peft_utils.py': ['peft'], 'nox_sessions/docs_validation.py': ['peft'], 'noxfile.py': ['peft'], 'scripts/codex_ready_task_runner.py': ['peft'], 'scripts/make_quickstart_notebook.py': ['lora'], 'scripts/space_traversal/detectors/detector_peft.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft', 'prepare_model_for_kbit_training'], 'scripts/train.py': ['lora'], 'services/api/main.py': ['lora', 'peft'], 'src/codex/cli.py': ['lora'], 'src/codex/training.py': ['lora', 'peft'], 'src/codex_ml/cli/codex_cli.py': ['peft'], 'src/codex_ml/cli/config.py': ['lora'], 'src/codex_ml/cli/generate.py': ['lora'], 'src/codex_ml/cli/hydra_main.py': ['lora'], 'src/codex_ml/cli/infer.py': ['lora'], 'src/codex_ml/cli/train.py': ['lora'], 'src/codex_ml/codex_model.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/codex_ml/config_schema.py': ['LoraConfig', 'lora'], 'src/codex_ml/hf_loader.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/codex_ml/interfaces/__init__.py': ['peft'], 'src/codex_ml/interfaces/peft_hooks.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/codex_ml/interfaces/rl.py': ['lora'], 'src/codex_ml/model_registry.py': ['lora', 'peft'], 'src/codex_ml/modeling/__init__.py': ['lora'], 'src/codex_ml/modeling/codex_model.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/codex_ml/modeling/codex_model_loader.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/codex_ml/modeling/factory.py': ['lora', 'peft'], 'src/codex_ml/models/factory.py': ['lora', 'peft'], 'src/codex_ml/models/peft_hooks.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/codex_ml/models/registry.py': ['lora', 'peft'], 'src/codex_ml/models/utils/__init__.py': ['lora', 'peft'], 'src/codex_ml/models/utils/peft.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/codex_ml/peft/peft_adapter.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/codex_ml/tracking/init_experiment.py': ['lora'], 'src/codex_ml/train_loop.py': ['lora'], 'src/codex_ml/training/functional_training.py': ['lora', 'peft'], 'src/codex_ml/training/legacy_api.py': ['lora', 'peft'], 'src/codex_ml/utils/modeling.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/hhg_logistics/model/adapters.py': ['peft'], 'src/hhg_logistics/model/peft_utils.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/hhg_logistics/registry/__init__.py': ['peft'], 'src/hhg_logistics/serve/app.py': ['peft'], 'src/hhg_logistics/train.py': ['lora', 'peft'], 'src/modeling.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'src/training/checkpointing.py': ['get_peft_model', 'lora', 'peft'], 'src/training/config.py': ['lora'], 'src/training/engine_hf_trainer.py': ['lora', 'peft'], 'src/training/functional_training.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/checkpoint/test_checkpoint_peft_state.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/cli/test_generate_safety.py': ['lora'], 'tests/cli/test_infer_cli_lora.py': ['lora'], 'tests/config/test_config_settings.py': ['lora'], 'tests/config/test_validate_config.py': ['LoraConfig', 'lora'], 'tests/helpers/optional_dependencies.py': ['peft'], 'tests/integration/test_build_api_docs_integration.py': ['peft'], 'tests/modeling/test_codex_model.py': ['lora', 'peft'], 'tests/modeling/test_decoder_only.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/modeling/test_lora_minimal.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/modeling/test_modeling_module.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/models/test_chat_model.py': ['lora', 'peft'], 'tests/models/test_lora_integration.py': ['lora'], 'tests/models/test_models_registry_api.py': ['lora'], 'tests/models/test_peft_optional.py': ['lora', 'peft'], 'tests/models/test_peft_smoke.py': ['lora', 'peft'], 'tests/models/test_peft_utils.py': ['peft'], 'tests/models/test_registry_dtype.py': ['lora'], 'tests/models/test_registry_validation.py': ['lora'], 'tests/peft/test_apply_lora.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/peft/test_peft_smoke.py': ['lora', 'peft'], 'tests/peft_tests/test_peft_comprehensive.py': ['LoraConfig', 'lora', 'peft'], 'tests/services/api/test_rate_limit_middleware.py': ['lora'], 'tests/space_traversal/test_detector_peft.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/test_cli_train_engine.py': ['lora'], 'tests/test_codex_model.py': ['lora', 'peft'], 'tests/test_codexml_cli.py': ['lora'], 'tests/test_docs_examples_paths.py': ['lora'], 'tests/test_engine_hf_trainer.py': ['lora'], 'tests/test_engine_hf_trainer_lora.py': ['lora', 'peft'], 'tests/test_hf_loader_peft_guard.py': ['peft'], 'tests/test_hf_loader_registry.py': ['peft'], 'tests/test_hf_trainer_lora_config.py': ['lora'], 'tests/test_loader_registry.py': ['lora'], 'tests/test_model_factory.py': ['lora', 'peft'], 'tests/test_model_factory_lora_validation.py': ['lora'], 'tests/test_model_loader.py': ['get_peft_model', 'lora', 'peft'], 'tests/test_model_registry_helpers.py': ['lora'], 'tests/test_modeling_module.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/test_modeling_utils.py': ['get_peft_model', 'lora', 'peft'], 'tests/test_peft_adapter.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/test_peft_gating.py': ['peft'], 'tests/test_peft_hooks.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tests/test_peft_integration.py': ['lora', 'peft'], 'tests/test_train_codex_cli_merge.py': ['lora'], 'tests/test_training_integration_flags.py': ['lora'], 'tests/tracking/test_init_experiment_tags.py': ['lora'], 'tests/training/test_engine_hf_trainer_lora_cfg.py': ['lora'], 'tests/training/test_functional_training_main.py': ['lora'], 'tests/training/test_lora_optional.py': ['lora', 'peft'], 'tests/training/test_lora_toggles.py': ['lora'], 'tests/training/test_training_config_module.py': ['lora'], 'tests/unit/test_adapters.py': ['peft'], 'tests/unit/test_build_api_docs.py': ['peft'], 'tests/unit/test_cli_prompt_sanitisation.py': ['lora'], 'tests/unit/test_modeling_module.py': ['lora', 'peft'], 'tests/unit/test_peft_utils.py': ['lora', 'peft'], 'tests/utils/test_modeling.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tools/apply_codex_audit_tasks.py': ['lora'], 'tools/apply_pyproject_packaging.py': ['peft'], 'tools/apply_stack_polish.py': ['lora', 'peft'], 'tools/build_api_docs.py': ['peft'], 'tools/codex_audit_orchestrator.py': ['lora', 'peft'], 'tools/codex_execute_audit.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft'], 'tools/codex_gap_registry.py': ['lora', 'peft'], 'training/config.py': ['lora'], 'training/engine_hf_trainer.py': ['lora', 'peft'], 'training/functional_training.py': ['LoraConfig', 'get_peft_model', 'lora', 'peft']}

Patterns Found: LoraConfig, get_peft_model, lora, peft, prepare_model_for_kbit_training

Evidence Files (first 10):
```
```
### reproducibility
Score: 0.8614

Components:
- Functionality: 1.0
- Consistency: 0.891304
- Tests: 0.532609
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- seed_management: 28
- repro_utils: 30
- determinism_configs: 8
- integrity_validation: 36

Patterns Found: deterministic, reproducibility, rng_state, seed, sha256

Evidence Files (first 10):
```
.codex/validation/file_integrity_compare.json
DETERMINISTIC_AUDIT_REPORT_v1.1.0.md
_codex_reports/2025-10-06/reproducibility.json
_codex_reports/2025-10-06/seed_scan.json
artifacts_sha256.txt
codex_ml/data/checksums.py
codex_reproducibility_manifest.json
configs/base/deterministic.yaml
docs/checkpoint_integrity.md
docs/explanations/reproducibility.md
```
### safeguards_keywords
Score: 0.4524

Components:
- Functionality: 1.0
- Consistency: 1.0
- Tests: 0.0
- Safeguards: 0.0
- Documentation: 0.015773

Meta:
- _evidence_v2: {'.codex/README.md': 2, '.codex/change_log-large.md': 2, '.codex/disabled_workflows/release-upload.yml': 2, '.codex/notes/CODEBASE_AUDIT.md': 2, '.codex/notes/ERROR_CAPTURE_BLOCKS.md': 1, '.codex/notes/MERGE_NOTES.md': 1, '.codex/notes/REPRO_NOTES.md': 1, '.codex/reports/PHASE2_STANDARDIZATION_SUMMARY.md': 1, '.codex/scripts/maintenance.sh': 3, '.codex/scripts/setup.sh': 3, '.codex/status/_codex_status_update-2025-08-28.md': 3, '.codex/status/_codex_status_update-2025-09-02.md': 2, '.codex/status/_codex_status_update-2025-09-03.md': 2, '.codex/status/_codex_status_update-2025-09-04.md': 2, '.codex/status/_codex_status_update-2025-09-05.md': 2, '.codex/status/_codex_status_update-2025-09-07.md': 4, '.codex/status/_codex_status_update-2025-09-14.md': 4, '.codex/status/_codex_status_update-2025-09-15.md': 4, '.codex/status/_codex_status_update-2025-09-16.md': 3, '.codex/status/_codex_status_update-2025-09-18.md': 4, '.codex/status/_codex_status_update-2025-09-20.md': 4, '.codex/status/_codex_status_update-2025-09-21.md': 3, '.codex/status/_codex_status_update-2025-09-22.md': 3, '.codex/status/_codex_status_update-2025-09-23.md': 3, '.codex/status/status_update_change_log.md': 1, '.codex/validation/20250910T052842Z/post_filelist.txt': 4, '.codex/validation/20250910T052842Z/pre_filelist.txt': 4, '.codex/validation/20250910T071257Z/post_filelist.txt': 4, '.codex/validation/20250910T071257Z/pre_filelist.txt': 4, '.codex/validation/20250910T080054Z/post_filelist.txt': 4, '.codex/validation/20250910T080054Z/pre_filelist.txt': 4, '.codex/validation/20250910T113918Z/post_filelist.txt': 4, '.codex/validation/20250910T113918Z/pre_filelist.txt': 4, '.codex/validation/20250910T135035Z/pre_filelist.txt': 4, '.codex/validation/20250910T151757Z/post_filelist.txt': 4, '.codex/validation/20250910T151757Z/pre_filelist.txt': 4, '.codex/validation/20250910T210555Z/post_filelist.txt': 4, '.codex/validation/20250910T210555Z/pre_filelist.txt': 4, '.codex/validation/AUDIT_RECOMMENDATIONS.md': 1, '.codex/validation/tests_docs_links_audit.md': 1, '.copilot-space/workflow.yaml': 6, '.github/ISSUE_TEMPLATE/capability_request.md': 1, '.github/_workflows_disabled/release-upload.yml': 2, '.github/copilot_agent_task_prompt_v1.2.6.md': 1, '.github/copilot_agent_task_prompt_v1.2.7.md': 1, '.github/copilot_agent_task_prompt_v1.3.0_consolidation.md': 1, '.github/copilot_prompts/Coverage_96-99_NextIteration.md': 1, '.github/docs/ARCHIVE_IMPROVEMENTS_USAGE.md': 1, '.github/docs/Copilot_Audit_InstructionEnhancement.md': 1, '.github/docs/Coverage_Gating_Restoration_Enhanced_Copilot.md': 1, '.github/docs/Implementation_LLMAutoFixHook.md': 1, '.github/docs/OpenQuestions-UPDATED-ArchiveConsolidation.md': 2, '.github/docs/PR_2207_DEPLOYMENT_PLAYBOOK.md': 1, '.github/docs/PR_v1_3_0_Consolidation_Submission.md': 1, '.github/docs/Remaining_Implementation_Plan_Copilot.md': 3, '.github/docs/Security_Gates_Copilot.md': 1, '.github/prompts/Audit_Status_Update_Review_Iteration_Plan.md': 6, '.github/prompts/CODEX_MCP_COMPLETE_PATCHSETs.md': 6, '.github/prompts/ChatGPT_Codex_Assistant_Implementation_Verification.md': 6, '.github/prompts/MCP_AUDIT_AND_IMPLEMENTATION_PLAN.md': 3, '.github/prompts/additional_helpful_files.md': 6, '.github/pull_request_template.md': 2, '.github/scripts/imds_diagnostic.sh': 1, '.github/templates/_codex_status_update_template.md': 1, 'AGENTS.md': 1, 'ARCHIVAL_BUNDLING_COMPLETE.md': 1, 'ARTIFACTS_AND_COVERAGE_SUMMARY.md': 1, 'ARTIFACTS_VERIFICATION_SUMMARY.md': 2, 'AUDIT_REMEDIATION_STATUS.md': 1, 'BRANCH_VERIFICATION_REPORT.md': 1, 'CHANGELOG_CodexAudit.md': 2, 'CHANGELOG_CodexAudit_batch5_addition.md': 2, 'CHANGES.md': 2, 'CODEX_STATUS_IMPLEMENTATION_SUMMARY.md': 1, 'COMPLETE_GAP_REMEDIATION_SUMMARY.md': 1, 'COPILOT_PR_TEMPLATE_USAGE_GUIDE.md': 2, 'DEEP_RESEARCH_PROGRESS_UPDATE.md': 1, 'DEEP_RESEARCH_STATUS_UPDATE.md': 1, 'DEEP_RESEARCH_UNRESOLVED_ISSUES_COMPLETE.md': 1, 'FINAL_COMPLETION_REPORT.md': 2, 'FINAL_IMPLEMENTATION_REPORT.md': 2, 'FINAL_VERIFICATION_COMPLETE.md': 6, 'FINAL_VERIFICATION_REPORT.md': 1, 'FINAL_VERIFICATION_SUMMARY.md': 1, 'GAP_REMEDIATION_FINAL_SUMMARY.md': 1, 'GAP_REMEDIATION_PLAN.md': 1, 'GAP_REMEDIATION_STATUS.md': 1, 'IMPLEMENTATION_COMPLETE_EVALUATION_LOOP.md': 1, 'IMPLEMENTATION_SUMMARY_OLD.md': 2, 'IMPLEMENTATION_SUMMARY_PR2163.md': 1, 'IMPLEMENTATION_VALIDATION.md': 2, 'MATURITY_IMPLEMENTATION_SUMMARY.md': 1, 'MATURITY_IMPROVEMENT_PLAN.md': 6, 'MCP_100_PERCENT_ROADMAP.md': 5, 'MCP_CAPABILITIES_REFERENCE.md': 2, 'MCP_FAQ.md': 3, 'MCP_IMPLEMENTATION_SUMMARY.md': 3, 'MCP_INTEGRATION_COMPLETE.md': 2, 'MCP_INTEGRATION_PR2297_SUMMARY.md': 1, 'MCP_SCORE_REMEDIATION_COMPLETE.md': 6, 'MCP_SECURITY_GUIDE.md': 5, 'MCP_USER_PROMPTS_FINAL.md': 5, 'MERGE_READINESS_CONFIRMATION.md': 1, 'MSP_IMPLEMENTATION_SUMMARY.md': 1, 'NEWCOMER_GUIDE.md': 2, 'NEXT_COPILOT_PROMPT.md': 1, 'PROMOTION_READINESS_PR2205.yaml': 1, 'PR_2389_CHECKLIST_VALIDATION.md': 2, 'PR_TEMPLATE_COMPREHENSIVE.md': 2, 'README.md': 1, 'REMAINING_WORK.md': 2, 'SELECTION_REPORT.md': 1, 'SESSION_SUMMARY_2025-12-04.md': 2, 'STATUS_SCHEMA_IMPLEMENTATION.md': 3, 'STATUS_UPDATE_AUDIT_REPORT.md': 2, 'TEST_EXECUTION_REPORT.md': 1, 'Traversal_Workflow.md': 6, 'UPDATED_AUDIT_REPORT_2025-12-04.md': 3, 'Usage_Guide.md': 6, 'VALIDATION_REPORT_v1.2.4.md': 1, 'VERIFICATION_ARTIFACTS_MANIFEST.md': 1, 'VERIFICATION_REPORT_EVALUATION_LOOP.md': 1, 'WAVE2_IMPLEMENTATION.md': 1, 'WAVE4_IMPLEMENTATION.md': 2, 'WORK_SUMMARY.md': 2, '_codex/status/_codex_status_update-2025-09-21.md': 3, '_codex/status/_codex_status_update-2025-09-22.md': 3, '_codex_/AGENTS.md': 2, '_codex_/codex_index.yaml': 2, '_codex_reports/2025-10-06/_codex_status_update-2025-10-06.md': 2, '_codex_reports/2025-10-06/audit_raw.md': 3, '_codex_reports/audit_requirement_mapping.md': 1, '_codex_reports/errors_2025-10-19.md': 1, '_codex_reports/status_update_2025-10-19.md': 1, 'actions/openapi.yaml': 1, 'analysis/audit_pipeline.py': 1, 'analysis/parsers.py': 1, 'analysis/root_python_migration_plan.md': 2, 'artifacts/MIGRATION_SUMMARY.md': 1, 'artifacts/security/bandit.txt': 3, 'automation/atomic_patch_task_sequence.yaml': 2, 'automation/automated_patch_task_sequence.md': 1, 'automation/codex_ready_executor.py': 1, 'automation/codex_ready_task_sequence_v2.yaml': 2, 'cli/ast_upgrade.py': 1, 'cli/patch_runner.py': 2, 'cli/script_polish.py': 3, 'cli/setup.py': 1, 'cli/task_sequence.py': 2, 'cli/train_schema_demo.py': 2, 'cli/update_runner.py': 1, 'codex_addons/metrics/collector.py': 1, 'codex_digest/README.md': 1, 'codex_digest/mapper.py': 1, 'codex_implement_status_update_PLAN_(2025‑11‑09).md': 4, 'codex_ml/data/checksums.py': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part01.txt': 2, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part02.txt': 2, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part03.txt': 2, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part05.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part06.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part08.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part10.txt': 2, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part11.txt': 2, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part12.txt': 2, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part13.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part14.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part15.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part16.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part18.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part20.txt': 2, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part21.txt': 2, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part22.txt': 1, 'codex_plans/batchsetpatchset_segments/batchsetpatchset_part23.txt': 2, 'codex_plans/track_A.md': 1, 'codex_plans/track_B.md': 1, 'codex_plans/track_C.md': 1, 'codex_plans/track_D.md': 1, 'codex_plans/track_E.md': 1, 'codex_plans/track_G.md': 2, 'codex_ready_task_sequence.yaml': 2, 'codex_regression/__init__.py': 1, 'codex_status_update.md': 2, 'codex_task_executor.py': 2, 'codex_task_sequence.yaml': 2, 'codex_task_sequence_lora_metrics.md': 3, 'codex_utils/__init__.py': 3, 'codex_utils/json_report.py': 2, 'codex_utils/mlflow_offline.py': 1, 'codex_utils/repro.py': 2, 'codex_utils/tracking/__init__.py': 1, 'codex_utils/tracking/guards.py': 2, 'conf/config.yaml': 1, 'conf/data/local.yaml': 1, 'conf/experiment/basic.yaml': 1, 'conf/experiment/default.yaml': 1, 'conf/experiment/sweep.yaml': 2, 'conf/training/minimal.yaml': 1, 'config_legacy/errors.py': 1, 'configs/README.md': 1, 'configs/base/app.yaml': 1, 'configs/base/base.yaml': 2, 'configs/base/base_config.py': 1, 'configs/base/default.yaml': 2, 'configs/base/defaults.yaml': 2, 'configs/base/deterministic.yaml': 1, 'configs/base/hydra.yaml': 1, 'configs/base/offline/catalogue.yaml': 1, 'configs/base/offline/tiny_fixtures.yaml': 2, 'configs/base/params.yaml': 1, 'configs/defaults.yaml': 2, 'configs/deploy/reasoning_pod.yaml': 1, 'configs/deployment/hhg_logistics/config.yaml': 2, 'configs/deployment/hhg_logistics/eval/default.yaml': 1, 'configs/deployment/hhg_logistics/monitor/default.yaml': 1, 'configs/deployment/hhg_logistics/train/default.yaml': 1, 'configs/deployment/hhg_logistics/train/lora.yaml': 1, 'configs/development/noxfile.py': 4, 'configs/evaluation/base.yaml': 1, 'configs/evaluation/default.yaml': 2, 'configs/evaluation/metrics/offline/weighted_accuracy.yaml': 1, 'configs/evaluation/reasoning/math.yaml': 1, 'configs/evaluation/reasoning/proof.yaml': 1, 'configs/evaluation/reasoning/tools.yaml': 1, 'configs/msp/gateway.yaml': 1, 'configs/msp/retrieval.yaml': 1, 'configs/msp/safety.yaml': 1, 'configs/schemas/README.md': 1, 'configs/schemas/__init__.py': 1, 'configs/schemas/data.schema.yaml': 1, 'configs/schemas/tracking.schema.yaml': 1, 'configs/schemas/training.schema.yaml': 1, 'configs/simple/train.yaml': 1, 'configs/sweeps/minimal.yaml': 1, 'configs/training/base.yaml': 1, 'configs/training/continual/difficulty_curriculum.yaml': 1, 'configs/training/continual/interleaved_rehearsal.yaml': 2, 'configs/training/continual/rehearsal.yaml': 1, 'configs/training/data/base.yaml': 1, 'configs/training/data/offline/tiny_corpus.yaml': 2, 'configs/training/data/tiny.yaml': 1, 'configs/training/functional_base.yaml': 2, 'configs/training/legacy/trainer_base.yaml': 1, 'configs/training/model/offline/gpt2.yaml': 1, 'configs/training/model/offline/tiny_sequence.yaml': 1, 'configs/training/model/offline/tinyllama.yaml': 1, 'configs/training/offline/functional.yaml': 1, 'configs/training/offline/tiny_functional.yaml': 1, 'configs/training/pipeline_inputs/smoke.yaml': 2, 'configs/training/profiles/default.yaml': 1, 'configs/training/profiles/lora.yaml': 1, 'configs/training/profiles/rlhf.yaml': 1, 'configs/training/sweeps/sweep_offline.yaml': 2, 'configs/training/tokenization/base.yaml': 1, 'configs/training/tokenizer/offline/gpt2.yaml': 1, 'configs/training/tokenizer/offline/tiny_vocab.yaml': 1, 'configs/training/tokenizer/offline/tinyllama.yaml': 1, 'configs/training/tracking/base.yaml': 1, 'configs/training/tracking/offline.yaml': 2, 'conftest.py': 2, 'data/offline/tiny_corpus.txt': 1, 'deploy/deploy_codex_pipeline.py': 3, 'deploy/helm/values.yaml': 2, 'docs/CHANGELOG.md': 2, 'docs/CHANGELOG/changelog_codex.md': 3, 'docs/CHECKPOINTS.md': 1, 'docs/CLI.md': 2, 'docs/FollowUp_Implementation_Plan.md': 2, 'docs/INFERENCE_PIPELINE.md': 3, 'docs/Implementation_Update_merged.md': 2, 'docs/MCP_Usage_Guide.md': 6, 'docs/MODEL_REGISTRY.md': 1, 'docs/PR_PLAN.md': 2, 'docs/QUALITY_GATES.md': 1, 'docs/QUICKSTART.md': 2, 'docs/README.md': 1, 'docs/README_ROOT.md': 4, 'docs/SEARCH_NOTES.md': 2, 'docs/SECURITY.md': 1, 'docs/SPACE_TRAVERSAL_GUIDE.md': 6, 'docs/Traversal_Workflow.md': 6, 'docs/Usage_Guide.md': 2, 'docs/VECTOR_STORE_INTEGRATION_GUIDE.md': 1, 'docs/agents.md': 1, 'docs/api/README.md': 1, 'docs/api/loop_eval.md': 2, 'docs/arch/_archive-policy/README-standardization.md': 1, 'docs/arch/_archive-policy/canonical-archiving-policy.md': 1, 'docs/arch/_archive-policy/standardization-framework.md': 2, 'docs/arch/adr-2025-11-02-archive-sigstore-integration.md': 1, 'docs/arch/adr-2025-11-03-evidence-schema-versioning.md': 1, 'docs/architecture.md': 2, 'docs/architecture/codex_system_overview.md': 1, 'docs/architecture/interfaces.md': 1, 'docs/archive/pages_publish_tiles_yml_archive.md': 1, 'docs/capability_contracts.md': 2, 'docs/checkpoint_integrity.md': 1, 'docs/ci_cd_strategy.md': 1, 'docs/cli/dataset_cli.md': 1, 'docs/cli/minimal_train_eval_workflow.md': 1, 'docs/cli/status_audit.md': 2, 'docs/codex/IMPLEMENTATION_GUIDE.md': 1, 'docs/compliance/archive_standards_mapping.md': 1, 'docs/config/config_patterns_and_conventions.md': 1, 'docs/config_validation.md': 1, 'docs/configs/OmegaConf_Schema.md': 1, 'docs/configuration/HYDRA_GUIDE.md': 2, 'docs/configuration/hydra_quickstart.md': 2, 'docs/control_surface.md': 1, 'docs/crm/admin-runbooks/archive.md': 1, 'docs/crm/admin-runbooks/d365.md': 1, 'docs/crm/admin-runbooks/release.md': 2, 'docs/crm/admin-runbooks/zendesk.md': 1, 'docs/data/Caching.md': 1, 'docs/data/Local_Files.md': 1, 'docs/data_determinism.md': 1, 'docs/deferred_items.md': 1, 'docs/deploy/packaging_and_docker.md': 1, 'docs/deployment/docker_deployment_guide.md': 2, 'docs/deployment/local_codex_env_readiness.md': 1, 'docs/deployment/reasoning_pod.md': 1, 'docs/dev/testing.md': 2, 'docs/dev/unified_training.md': 3, 'docs/developer/Patch_Debris_Guard.md': 1, 'docs/development/offline_ci.md': 1, 'docs/docker_hardening.md': 1, 'docs/ephemeral-runners.md': 1, 'docs/examples/codex_symbolic_pipeline.py': 2, 'docs/examples/minimal_run.md': 1, 'docs/experiments.md': 2, 'docs/experiments/README.md': 1, 'docs/experiments/experiment_tracking_minimal.md': 2, 'docs/experiments/mlflow_offline.md': 1, 'docs/explanations/architecture.md': 2, 'docs/explanations/golden_harness.md': 1, 'docs/explanations/reproducibility.md': 1, 'docs/extensibility.md': 1, 'docs/extensibility/registries_and_plugins.md': 1, 'docs/gaps/gap_pipeline_overview.md': 1, 'docs/gaps_report.md': 1, 'docs/governance/CONTRIBUTING.md': 3, 'docs/guides/AGENTS.md': 2, 'docs/guides/TESTING_GUIDE.md': 1, 'docs/guides/_codex__Newcomer_Codebase_Overview.md': 1, 'docs/guides/archive_standardization_guide.md': 1, 'docs/guides/auditing.md': 1, 'docs/guides/codex_archive_runbook.md': 1, 'docs/guides/codex_zendesk_integration_deep_dive.md': 1, 'docs/guides/config_overrides.md': 3, 'docs/guides/continual_learning_readiness.md': 2, 'docs/guides/metrics.md': 2, 'docs/guides/mlflow_offline.md': 1, 'docs/guides/offline_catalogue.md': 1, 'docs/guides/offline_transformers.md': 1, 'docs/guides/pipeline_smoke_test.md': 2, 'docs/guides/plugin_development.md': 2, 'docs/guides/plugins.md': 2, 'docs/guides/reasoning_overview.md': 2, 'docs/guides/serving_reproducibility.md': 4, 'docs/guides/vector_stores_guide.md': 2, 'docs/guides/workflow_orchestrator.md': 2, 'docs/guides/zendesk_ai_app_builder_limitations.md': 1, 'docs/how-to/admin_bootstrap.md': 1, 'docs/how-to/checkpoint_metadata.md': 3, 'docs/how-to/dataset_manifest.md': 3, 'docs/how-to/hydra_sweeps.md': 1, 'docs/how-to/offline_tracking.md': 2, 'docs/how-to/repodeterminism_smoke.md': 4, 'docs/how-to/run_audit_0D_base_.md': 1, 'docs/howto/add_capabilities.md': 2, 'docs/howto/run_audits.md': 1, 'docs/hydra_defaults_and_sweeps.md': 1, 'docs/index.md': 1, 'docs/integrity_and_uris.md': 1, 'docs/logging/metrics_and_experiment_tracking.md': 1, 'docs/metrics.md': 1, 'docs/metrics/codex_metrics_and_eval.md': 1, 'docs/modeling/registry.md': 1, 'docs/modules/configuration.md': 2, 'docs/modules/connectors.md': 1, 'docs/modules/data_handling.md': 2, 'docs/modules/data_registry.md': 1, 'docs/modules/evaluation_runner.md': 1, 'docs/modules/metric_registry.md': 1, 'docs/modules/model_registry.md': 1, 'docs/modules/modeling.md': 1, 'docs/modules/observability.md': 1, 'docs/modules/plugins.md': 2, 'docs/modules/training_engine.md': 1, 'docs/monitoring/prometheus_setup.md': 1, 'docs/offline_quickstart.md': 2, 'docs/offline_testing.md': 1, 'docs/ops/Commits.md': 1, 'docs/ops/Deterministic_Installs.md': 1, 'docs/ops/audit_runbook.md': 1, 'docs/ops/environment.md': 1, 'docs/ops/experiment_tracking.md': 2, 'docs/ops/github_connector_prep.md': 1, 'docs/ops/monitoring.md': 2, 'docs/ops/offline_workflow.md': 6, 'docs/ops/promotion_checklist.md': 1, 'docs/ops/runbook_logging.md': 3, 'docs/ops/status_reports.md': 1, 'docs/ops/training_args.md': 3, 'docs/ops/vendor_audit_conclusive_findings.md': 1, 'docs/ops/vendor_audit_stress_validation.md': 1, 'docs/optional_dependencies.md': 1, 'docs/packaging/Packaging_and_Release.md': 3, 'docs/phase4_changes.md': 1, 'docs/plans/AST_ARCHITECTURE_DESIGN.md': 1, 'docs/plans/AST_DEPENDENCY_REQUIREMENTS.md': 1, 'docs/plans/AST_ENGINEERING_PROJECT_GUIDE.md': 1, 'docs/plans/AST_IMPLEMENTATION_BLOCKERS.md': 1, 'docs/plans/AST_Standardization_InstructionEnhancement.md': 1, 'docs/plans/AST_Standardization_Requirements.md': 1, 'docs/plans/PR_2205_fix_gap-and-comments.md': 2, 'docs/plans/Phase0_ExecutiveDashboard.md': 1, 'docs/plans/Phase0_Gap_Resolution_Guide.md': 1, 'docs/plans/_codex__IntentValidation_and_ActionPlan_ApprovalGate.md': 2, 'docs/plugins.md': 1, 'docs/policies/branch-protection-checklist.md': 1, 'docs/prompts/codex_run_prompt_0A_base_.md': 4, 'docs/prompts/codex_run_prompt_0D_base_.md': 1, 'docs/prompts/custom_gpt_self_healing_engineer.md': 1, 'docs/quickstart.md': 4, 'docs/quickstart_local_training.md': 1, 'docs/quickstarts/offline_microperf.md': 1, 'docs/reference/audit_prompt.md': 2, 'docs/reference/cli.md': 2, 'docs/reference/configs.md': 2, 'docs/reference/policy.md': 1, 'docs/regression_overview.md': 1, 'docs/remediation/LEGACY_IMPORT_REDUCTION_SUMMARY.md': 2, 'docs/remediation/components.md': 5, 'docs/repo_audit_policy.md': 1, 'docs/repro.md': 4, 'docs/repro_guidance.md': 1, 'docs/repro_offline_hardening_status.md': 3, 'docs/reproducibility.md': 2, 'docs/reproducibility/env_and_dependency_snapshot.md': 1, 'docs/reproducibility/repro_manifest_and_status_digest.md': 1, 'docs/reproducibility/reproducibility_checklist.md': 2, 'docs/review/diff_intake_confirmation.md': 3, 'docs/runbooks/offline_wheelhouse.md': 1, 'docs/runbooks/zendesk_docs_pipeline.md': 1, 'docs/safety/moderation_adapter.md': 1, 'docs/safety/policy_guidance.md': 1, 'docs/security/THREAT_MODEL.md': 2, 'docs/security/codex_security_safety_baseline.md': 1, 'docs/security/secret_handling.md': 1, 'docs/security/security_baseline_local_only.md': 1, 'docs/status/Removed_Strikeouts_2025-11-05.md': 2, 'docs/status/codex_status_update_2025_CLEAN.md': 2, 'docs/status_update_outstanding_questions.md': 1, 'docs/status_update_prompt.md': 2, 'docs/status_updates/artifacts/2025-10-29-survey-0D_base-and-1926/report.md': 2, 'docs/status_updates/artifacts/2025-10-30-survey-main-and-0/report.md': 1, 'docs/status_updates/artifacts/2025-10-30-survey-work-and-0_/report.md': 3, 'docs/status_updates/artifacts/2025-10-30-survey-work-and-1926_/report.md': 2, 'docs/status_updates/deploy_dry_run.md': 1, 'docs/status_updates/status_update_{{date}}.md': 1, 'docs/status_updates/survey-0D_base-and-1926-2025-10-29.md': 2, 'docs/status_updates/survey-0D_base_-and-1926-2025-10-29.md': 2, 'docs/status_updates/survey-0D_base_-and-1926-2025-10-30.md': 6, 'docs/status_updates/survey-main-and-0-2025-10-30.md': 1, 'docs/status_updates/survey-work-and-0_-2025-10-30.md': 3, 'docs/status_updates/survey-work-and-1926_-2025-10-30.md': 2, 'docs/suggested_tasks/offline_logging_security_updates.md': 2, 'docs/suggested_tasks/remediation_phase1_task_queue_2025-09-17.md': 3, 'docs/suggested_tasks/remediation_plan_status_update_2025-09-17.md': 3, 'docs/suggested_tasks/status_update_2025-09-16.md': 3, 'docs/suggested_tasks/status_update_2025-09-17.md': 3, 'docs/templates/status/README.md': 1, 'docs/templates/status/SCHEMA_ENHANCEMENTS_v1.2.md': 2, 'docs/templates/status/Tokenization_Insights_v1.2.md': 1, 'docs/templates/status/authoring_guide_v1.1.md': 1, 'docs/templates/status/authoring_guide_v1.2.md': 2, 'docs/templates/status/capability_matrix_example_v1.2.md': 1, 'docs/templates/status/codex_status_template.schema.yaml': 1, 'docs/templates/status/codex_status_template.schema_v1.2.yaml': 2, 'docs/templates/status/codex_status_template_v1.1.md': 2, 'docs/templates/status/codex_status_template_v1.2.md': 3, 'docs/templates/status/example_report_v1.2.md': 1, 'docs/templates/status/status_json_minimal_examples_v1.2.md': 1, 'docs/testing/ml_test_suite_guide.md': 1, 'docs/tokenization_cache.md': 2, 'docs/tracking.md': 1, 'docs/tracking/Offline_MLflow.md': 2, 'docs/tracking_offline.md': 2, 'docs/tracking_offline_bootstrap.md': 1, 'docs/training/Checkpointing_Surfaces.md': 2, 'docs/training/Distributed_Minimal_Hooks.md': 1, 'docs/training/reproducibility.md': 3, 'docs/training/symbolic_training.md': 1, 'docs/troubleshooting.md': 1, 'docs/troubleshooting/API_Docs_Troubleshooting.md': 1, 'docs/troubleshooting/error_log.md': 1, 'docs/troubleshooting/open_questions.md': 2, 'docs/tutorials/getting_started.md': 1, 'docs/tutorials/train_model.md': 1, 'docs/unified_training.md': 2, 'docs/usage.md': 2, 'docs/validation/API_Docs_Build_Validation.md': 1, 'docs/validation/Atomic_Diffs_Next_Unresolved_2025-10-11.md': 1, 'docs/validation/Bridge_Run_Validation.md': 2, 'docs/validation/CODEBASE_Status_Audit_2025-10-14.md': 1, 'docs/validation/Convergence_Runbook.md': 2, 'docs/validation/Metrics_Validation.md': 1, 'docs/validation/Offline_Audit_Validation.md': 1, 'docs/validation/PR2208_CI_Failure_Remediation_Plan.md': 1, 'docs/validation/Post_Apply_Validation_Checklist_2025-10-11.md': 1, 'docs/validation/Repro_Validation.md': 2, 'docs/validation/Tokenization_Validation.md': 1, 'docs/validation/Traversal_Workflow.md': 6, 'docs/validation/Usage_Guide.md': 2, 'docs/validation/Wheel_Manifest_SBOM_Guide.md': 1, 'docs/validation/status_update_exhaustiveness.md': 2, 'dvc.yaml': 1, 'examples/TROUBLESHOOTING.md': 1, 'examples/mlflow_offline.py': 1, 'examples/safety/policy_bypass_example.yaml': 1, 'experiments/2025-01-15_smoke.md': 2, 'inventory.md': 2, 'nox_sessions/audit.py': 1, 'nox_sessions/docs_validation.py': 1, 'nox_sessions/fence_tests.py': 1, 'noxfile.py': 1, 'patches/I2_Data_Spine_P2.1-P2.3.md': 2, 'policies/denylist.yaml': 1, 'policies/safelist.yaml': 1, 'prompts/orchestrator/green.md': 1, 'prompts/repo_status_update_for_codex.md': 1, 'pytest_validation.txt': 4, 'pytest_validation_summary.txt': 4, 'scripts/archive/select_and_compress.py': 1, 'scripts/archive/trend_aggregate.py': 1, 'scripts/audit/build_integrity_chain.py': 1, 'scripts/audit/verify_integrity_chain.sh': 1, 'scripts/automation/sync_issues_to_report.py': 1, 'scripts/build_wheel.sh': 2, 'scripts/canonicalize_artifacts.py': 1, 'scripts/ci/establish_baseline.sh': 1, 'scripts/ci/generate_wheel_manifest.py': 1, 'scripts/ci/prepare_offline_env.sh': 1, 'scripts/codex_local_audit.sh': 1, 'scripts/codex_local_gates.sh': 1, 'scripts/codex_offline_audit.py': 5, 'scripts/codex_orchestrate.py': 1, 'scripts/codex_ready_execution.py': 1, 'scripts/codex_ready_task_runner.py': 2, 'scripts/data/hash_dataset_files.py': 2, 'scripts/deep_research_task_process.py': 1, 'scripts/docs_build.sh': 1, 'scripts/environment_snapshot.py': 1, 'scripts/generate_capability_report.py': 2, 'scripts/generate_docs_manifest.py': 1, 'scripts/inference_pipeline.py': 6, 'scripts/init_sample_db.py': 1, 'scripts/local/run_tests.sh': 1, 'scripts/maintenance.sh': 1, 'scripts/make_quickstart_notebook.py': 2, 'scripts/offline_gate.sh': 1, 'scripts/ops/bootstrap_self_hosted_runner.py': 1, 'scripts/ops/codex_mint_tokens_per_run.py': 1, 'scripts/run_codex_workflow.py': 1, 'scripts/run_sweep.py': 1, 'scripts/runner/runner_status.sh': 1, 'scripts/sbom_cyclonedx.py': 1, 'scripts/security/check_dependencies.py': 1, 'scripts/security/generate_sbom.py': 1, 'scripts/security/scan_secrets_runtime.py': 1, 'scripts/setup.sh': 2, 'scripts/space_traversal/audit_runner.py': 6, 'scripts/space_traversal/detectors/detector_safeguards.py': 6, 'scripts/space_traversal/detectors/reproducibility.py': 4, 'scripts/space_traversal/dup_similarity.py': 1, 'scripts/space_traversal/synonym_loader.py': 1, 'scripts/space_traversal/validate_template_hash.py': 1, 'scripts/torch_policy_check.py': 1, 'scripts/tracking/mlflow_ui.sh': 1, 'scripts/train.py': 1, 'scripts/validate_all_capabilities.sh': 4, 'scripts/validate_dataset.py': 1, 'scripts/vendor_audit_maint.sh': 1, 'scripts/vendor_audit_setup.sh': 1, 'scripts/zendesk_docs_fetch.py': 1, 'sentencepiece/__init__.py': 1, 'services/ita/app/security.py': 1, 'services/ita/app/tests_runner.py': 1, 'services/msp_gateway/README.md': 1, 'services/msp_gateway/app.py': 1, 'services/msp_gateway/config.py': 1, 'services/msp_gateway/main.py': 1, 'services/msp_gateway/routers/infer.py': 1, 'services/msp_gateway/schemas/responses.py': 1, 'services/msp_gateway/security.py': 1, 'sitecustomize.py': 1, 'src/codex/analysis/duplication.py': 1, 'src/codex/archive/api.py': 1, 'src/codex/archive/backend.py': 1, 'src/codex/archive/cli.py': 1, 'src/codex/archive/config.py': 1, 'src/codex/archive/dal.py': 1, 'src/codex/archive/retry.py': 2, 'src/codex/archive/schema.py': 1, 'src/codex/archive/service.py': 1, 'src/codex/archive/sigstore_client.py': 1, 'src/codex/archive/similarity.py': 1, 'src/codex/archive/stub.py': 1, 'src/codex/archive/util.py': 1, 'src/codex/cli.py': 1, 'src/codex/cli_archive.py': 1, 'src/codex/cli_knowledge.py': 1, 'src/codex/cli_qa.py': 1, 'src/codex/cli_release.py': 2, 'src/codex/dynamics/cli_d365.py': 1, 'src/codex/knowledge/__init__.py': 1, 'src/codex/knowledge/build.py': 1, 'src/codex/qa/__init__.py': 1, 'src/codex/rag/prompt.py': 1, 'src/codex/release/api.py': 1, 'src/codex/retrieval/stores/factory.py': 1, 'src/codex/retrieval/stores/faiss_store.py': 2, 'src/codex/retrieval/stores/pgvector_store.py': 1, 'src/codex/retrieval/stores/weaviate_store.py': 1, 'src/codex/training.py': 4, 'src/codex/utils/session_cache.py': 1, 'src/codex/utils/validators.py': 2, 'src/codex/zendesk/apply.py': 1, 'src/codex_audit/__init__.py': 1, 'src/codex_audit/gates.py': 1, 'src/codex_audit/policy.py': 1, 'src/codex_cli/app.py': 3, 'src/codex_crm/evidence/emit.py': 5, 'src/codex_ml/analysis/providers.py': 1, 'src/codex_ml/checkpointing/atomic_io.py': 1, 'src/codex_ml/checkpointing/schema_v2.py': 1, 'src/codex_ml/cli/__init__.py': 1, 'src/codex_ml/cli/checkpoint_validate.py': 1, 'src/codex_ml/cli/codex_cli.py': 3, 'src/codex_ml/cli/config.py': 1, 'src/codex_ml/cli/entrypoints.py': 1, 'src/codex_ml/cli/eval_minimal.py': 1, 'src/codex_ml/cli/hydra_entry.py': 1, 'src/codex_ml/cli/hydra_main.py': 2, 'src/codex_ml/cli/infer.py': 2, 'src/codex_ml/cli/main.py': 3, 'src/codex_ml/cli/manifest.py': 1, 'src/codex_ml/cli/minimal_train.py': 1, 'src/codex_ml/cli/offline_bootstrap.py': 2, 'src/codex_ml/cli/simple_cli.py': 2, 'src/codex_ml/cli/status_report.py': 1, 'src/codex_ml/cli/tokenizer.py': 2, 'src/codex_ml/cli/tracking_cli.py': 2, 'src/codex_ml/cli/tracking_decide.py': 1, 'src/codex_ml/cli/train.py': 1, 'src/codex_ml/cli/train_minimal.py': 1, 'src/codex_ml/cli/utils.py': 1, 'src/codex_ml/codex_data.py': 4, 'src/codex_ml/codex_model.py': 1, 'src/codex_ml/config/__init__.py': 1, 'src/codex_ml/config/schema.py': 1, 'src/codex_ml/config_schema.py': 2, 'src/codex_ml/configs/training/functional_base.yaml': 1, 'src/codex_ml/connectors/base.py': 1, 'src/codex_ml/connectors/remote.py': 1, 'src/codex_ml/data/__init__.py': 1, 'src/codex_ml/data/cache.py': 3, 'src/codex_ml/data/checksums.py': 1, 'src/codex_ml/data/dataloader.py': 1, 'src/codex_ml/data/datamodule.py': 2, 'src/codex_ml/data/dataset_wrapper.py': 2, 'src/codex_ml/data/datasets.py': 1, 'src/codex_ml/data/integrity.py': 1, 'src/codex_ml/data/jsonl_loader.py': 2, 'src/codex_ml/data/loader.py': 3, 'src/codex_ml/data/loaders.py': 4, 'src/codex_ml/data/loaders/__init__.py': 1, 'src/codex_ml/data/loaders/csv.py': 4, 'src/codex_ml/data/loaders/jsonl.py': 4, 'src/codex_ml/data/local_files.py': 1, 'src/codex_ml/data/make_splits.py': 3, 'src/codex_ml/data/reasoning_manifest.py': 2, 'src/codex_ml/data/registry.py': 5, 'src/codex_ml/data/simple_dataset.py': 1, 'src/codex_ml/data/split.py': 4, 'src/codex_ml/data/split_utils.py': 3, 'src/codex_ml/data/splits.py': 1, 'src/codex_ml/data/utils.py': 2, 'src/codex_ml/data/validator.py': 1, 'src/codex_ml/data_utils.py': 4, 'src/codex_ml/deployment/cloud.py': 1, 'src/codex_ml/deployment/package.py': 1, 'src/codex_ml/detectors/__init__.py': 1, 'src/codex_ml/eval/datasets.py': 2, 'src/codex_ml/eval/eval_runner.py': 2, 'src/codex_ml/eval/runner.py': 4, 'src/codex_ml/evaluation/cli.py': 1, 'src/codex_ml/evaluation/loop.py': 2, 'src/codex_ml/exec/codex_exec.py': 1, 'src/codex_ml/ingest.py': 2, 'src/codex_ml/interfaces/contracts.py': 2, 'src/codex_ml/interfaces/reward_model.py': 1, 'src/codex_ml/interfaces/tokenizer.py': 2, 'src/codex_ml/logging/__init__.py': 1, 'src/codex_ml/logging/experiment.py': 1, 'src/codex_ml/logging/mlflow_guard.py': 1, 'src/codex_ml/logging/run_logger.py': 1, 'src/codex_ml/logging/run_metadata.py': 1, 'src/codex_ml/metrics/registry.py': 1, 'src/codex_ml/metrics/sinks.py': 1, 'src/codex_ml/models/offline_tiny.py': 1, 'src/codex_ml/models/reasoning.py': 1, 'src/codex_ml/models/registry.py': 1, 'src/codex_ml/models/utils/peft.py': 1, 'src/codex_ml/monitoring/codex_logging.py': 2, 'src/codex_ml/monitoring/health.py': 1, 'src/codex_ml/monitoring/microhelpers.py': 1, 'src/codex_ml/monitoring/mlflow_utils.py': 1, 'src/codex_ml/monitoring/system_metrics.py': 1, 'src/codex_ml/monitoring/tracking.py': 2, 'src/codex_ml/perf/bench.py': 1, 'src/codex_ml/pipeline.py': 3, 'src/codex_ml/plugins/registries.py': 1, 'src/codex_ml/registry/tokenizers.py': 1, 'src/codex_ml/reward_models/rlhf.py': 1, 'src/codex_ml/rl/scripted_agent.py': 1, 'src/codex_ml/safety/filters.py': 1, 'src/codex_ml/safety/moderation.py': 2, 'src/codex_ml/security/__init__.py': 1, 'src/codex_ml/security/runtime.py': 1, 'src/codex_ml/serving/caching.py': 1, 'src/codex_ml/serving/inference_server.py': 2, 'src/codex_ml/symbolic_pipeline.py': 2, 'src/codex_ml/tokenization/cache.py': 1, 'src/codex_ml/tokenization/offline_vocab.py': 1, 'src/codex_ml/tokenization/sp_trainer.py': 1, 'src/codex_ml/tracking/__init__.py': 1, 'src/codex_ml/tracking/experiments.py': 1, 'src/codex_ml/tracking/guards.py': 2, 'src/codex_ml/tracking/init_experiment.py': 3, 'src/codex_ml/tracking/init_offline.py': 2, 'src/codex_ml/tracking/mlflow_guard.py': 1, 'src/codex_ml/tracking/mlflow_utils.py': 3, 'src/codex_ml/tracking/offline.py': 2, 'src/codex_ml/tracking/writers.py': 1, 'src/codex_ml/train_loop.py': 5, 'src/codex_ml/training/__init__.py': 2, 'src/codex_ml/training/dataloader_utils.py': 1, 'src/codex_ml/training/dp_config.py': 1, 'src/codex_ml/training/functional_training.py': 3, 'src/codex_ml/training/legacy_api.py': 2, 'src/codex_ml/training/rng_checkpoint.py': 2, 'src/codex_ml/training/strategies.py': 1, 'src/codex_ml/training/toy_trainer.py': 1, 'src/codex_ml/training/unified_training.py': 3, 'src/codex_ml/utils/__init__.py': 3, 'src/codex_ml/utils/artifacts.py': 2, 'src/codex_ml/utils/checkpoint.py': 3, 'src/codex_ml/utils/checkpoint_core.py': 3, 'src/codex_ml/utils/checkpoint_event.py': 1, 'src/codex_ml/utils/checkpoint_integrity.py': 2, 'src/codex_ml/utils/checkpointing.py': 4, 'src/codex_ml/utils/checksum.py': 2, 'src/codex_ml/utils/checksums.py': 2, 'src/codex_ml/utils/config_loader.py': 2, 'src/codex_ml/utils/determinism.py': 1, 'src/codex_ml/utils/experiment_tracking_mlflow.py': 1, 'src/codex_ml/utils/logging_wandb.py': 2, 'src/codex_ml/utils/modeling.py': 1, 'src/codex_ml/utils/provenance.py': 2, 'src/codex_ml/utils/repro.py': 4, 'src/codex_ml/utils/reproducibility.py': 2, 'src/codex_ml/utils/run_metadata.py': 1, 'src/codex_ml/utils/runmeta.py': 1, 'src/codex_ml/utils/seed.py': 2, 'src/codex_ml/utils/seeding.py': 1, 'src/codex_ml/utils/tensorboard_logger.py': 1, 'src/codex_ml/utils/torch_checks.py': 1, 'src/codex_ml/utils/torch_det.py': 1, 'src/codex_ml/utils/tracking_bootstrap.py': 2, 'src/codex_ml/workflow/track_c_workflow.py': 1, 'src/codex_utils/tracking/__init__.py': 1, 'src/codex_utils/tracking/guards.py': 1, 'src/common/mlflow_guard.py': 1, 'src/common/provenance.py': 1, 'src/common/randomness.py': 1, 'src/data/datasets.py': 1, 'src/data/manifest.py': 2, 'src/data/registry.py': 1, 'src/experiments/manager.py': 1, 'src/hhg_logistics/__init__.py': 1, 'src/hhg_logistics/data/prepare.py': 2, 'src/hhg_logistics/main.py': 1, 'src/hhg_logistics/serve/app.py': 4, 'src/hhg_logistics/train.py': 1, 'src/hydra_extra/__init__.py': 1, 'src/ingestion/__init__.py': 2, 'src/ingestion/split.py': 2, 'src/ingestion/utils.py': 2, 'src/logging_utils.py': 1, 'src/mcp/auth.py': 2, 'src/mcp/config.py': 2, 'src/mcp/rate_limit.py': 1, 'src/mcp/registry.py': 2, 'src/modeling.py': 1, 'src/security/audit_logger.py': 1, 'src/tokenization/train_tokenizer.py': 2, 'src/tokenizer/__init__.py': 1, 'src/training/__init__.py': 1, 'src/training/checkpoint_manager.py': 1, 'src/training/checkpointing.py': 1, 'src/training/config.py': 1, 'src/training/data_utils.py': 3, 'src/training/engine_hf_trainer.py': 4, 'src/training/functional_training.py': 4, 'src/training/trainer.py': 1, 'src/utils/__init__.py': 2, 'src/utils/checkpoint.py': 1, 'src/utils/checkpointing.py': 2, 'src/utils/logging_factory.py': 2, 'src/utils/trackers.py': 2, 'test_results_stage1.txt': 1, 'tests/analysis/test_external_search.py': 1, 'tests/analysis/test_external_web_search.py': 1, 'tests/archival/test_archive_integration.py': 2, 'tests/archival/test_bundling.py': 2, 'tests/archival/test_corruption_recovery.py': 2, 'tests/archival/test_incremental_backups.py': 2, 'tests/archival/test_large_files.py': 2, 'tests/archive/test_archive_plan_apply.py': 1, 'tests/archive/test_auto_compress.py': 1, 'tests/archive/test_backend_retention.py': 1, 'tests/archive/test_config.py': 1, 'tests/archive/test_evidence_log.py': 1, 'tests/archive/test_plan_and_store.py': 1, 'tests/archive/test_purge_shared_artifact.py': 1, 'tests/archive/test_standardization.py': 1, 'tests/archive/test_stub_text.py': 1, 'tests/assets/README.md': 1, 'tests/audit/test_context_and_facets.py': 1, 'tests/checkpoint/test_checkpoint_integrity_tolerant.py': 1, 'tests/checkpoint/test_checkpoint_integrity_wiring.py': 2, 'tests/checkpoint/test_checkpoint_peft_state.py': 1, 'tests/checkpoint/test_checkpoint_schema.py': 1, 'tests/checkpoint/test_integrity_snapshot.py': 1, 'tests/checkpoint/test_runmeta_enrichment.py': 1, 'tests/checkpointing/test_atomic_io.py': 1, 'tests/checkpointing/test_checkpoint_comprehensive.py': 2, 'tests/checkpointing/test_checkpoint_core_io.py': 1, 'tests/checkpointing/test_checkpoint_json_event.py': 1, 'tests/checkpointing/test_corrupt_checkpoint_load.py': 1, 'tests/checkpointing/test_meta_schema.py': 1, 'tests/checkpointing/test_resume_optimizer_rng_equivalence.py': 2, 'tests/checkpointing/test_retention_and_digest.py': 1, 'tests/checkpointing/test_retention_local.py': 1, 'tests/checkpointing/test_rng_state_checkpoint.py': 2, 'tests/checkpointing/test_rng_state_roundtrip.py': 2, 'tests/cli/test_cli_tracking_decide.py': 1, 'tests/cli/test_codex_export_env.py': 1, 'tests/cli/test_codex_train_cli.py': 1, 'tests/cli/test_offline_bootstrap.py': 2, 'tests/cli/test_system_metrics_flag.py': 1, 'tests/cli/test_tracking_bootstrap_cli.py': 1, 'tests/codex_ml/data/test_jsonl_loader.py': 1, 'tests/codex_ml/test_cli_train_config_bridge.py': 2, 'tests/codex_ml/test_cli_utils_run_context.py': 1, 'tests/codex_ml/test_config_loader.py': 1, 'tests/codex_ml/test_data_utils_and_datasets.py': 1, 'tests/codex_ml/test_dataloader_determinism.py': 1, 'tests/codex_ml/test_eval_minimal_cli.py': 1, 'tests/codex_ml/test_experiment_logging.py': 1, 'tests/codex_ml/test_reproducibility_utils.py': 2, 'tests/codex_ml/test_simple_dataset.py': 1, 'tests/codex_ml/test_train_minimal_cli.py': 1, 'tests/config/test_config_schema.py': 1, 'tests/config/test_hydra_defaults_tree.py': 1, 'tests/config/test_training_config_negative.py': 1, 'tests/config/test_training_config_yaml.py': 1, 'tests/config/test_validate_config.py': 1, 'tests/configs/test_hydra_structured_config.py': 1, 'tests/configuration/test_config_basics.py': 1, 'tests/configuration/test_hydra_override_propagation.py': 1, 'tests/configuration/test_hydra_validation.py': 1, 'tests/connectors/test_github_connector_check.py': 1, 'tests/connectors/test_remote.py': 1, 'tests/data/test_cache.py': 1, 'tests/data/test_data_cache.py': 1, 'tests/data/test_data_shard_integrity.py': 2, 'tests/data/test_datamodule_determinism.py': 1, 'tests/data/test_dataset_determinism.py': 4, 'tests/data/test_dataset_loaders_comprehensive.py': 1, 'tests/data/test_loaders.py': 1, 'tests/data/test_make_splits.py': 1, 'tests/data/test_manifest.py': 2, 'tests/data/test_prepare_data_reproducible.py': 2, 'tests/data/test_registry_manifest.py': 3, 'tests/data/test_safety_filter_split.py': 1, 'tests/data/test_split_dataset.py': 1, 'tests/data/test_split_dataset_checksum.py': 2, 'tests/data/test_split_dataset_deterministic.py': 1, 'tests/data/test_split_manifest.py': 2, 'tests/data/test_split_seed.py': 1, 'tests/data/test_streaming_datamodule.py': 1, 'tests/data/test_validator.py': 2, 'tests/deployment/test_helm_values.py': 2, 'tests/deployment/test_k8s_manifests.py': 1, 'tests/docs/test_api_docs_build.py': 1, 'tests/docs/test_status_update_template.py': 1, 'tests/eval/test_eval_provenance_capture.py': 1, 'tests/eval/test_evaluation_reproducible.py': 1, 'tests/eval/test_hf_dataset_loader.py': 1, 'tests/evaluation/test_eval_cli.py': 1, 'tests/evaluation/test_loop.py': 1, 'tests/experiments_tests/test_experiment_management.py': 3, 'tests/gates/test_quality_gates.py': 2, 'tests/helpers/optional_dependencies.py': 1, 'tests/hhg_logistics/serve/test_app.py': 3, 'tests/inference/test_inference_pipeline.py': 3, 'tests/ingestion/test_io_text.py': 1, 'tests/ingestion/test_split.py': 1, 'tests/integration/test_ml_pipeline_integration.py': 1, 'tests/integration/test_mlflow_offline.py': 2, 'tests/keep_it_honest/test_honesty_suites.py': 1, 'tests/logging/test_mlflow_guard.py': 1, 'tests/logging/test_run_schema.py': 1, 'tests/mcp/test_auth.py': 2, 'tests/mcp/test_authz_authn_extended.py': 3, 'tests/mcp/test_config.py': 1, 'tests/mcp/test_mcp_core_smoke.py': 1, 'tests/mcp/test_multi_tenant_extended.py': 1, 'tests/mcp/test_observability.py': 1, 'tests/mcp/test_tools_integration.py': 1, 'tests/mcp/test_utilities.py': 5, 'tests/metrics/test_bleu_rouge.py': 1, 'tests/metrics/test_registry_aliases.py': 1, 'tests/metrics/test_scoring_integration.py': 2, 'tests/metrics/test_streaming_metrics.py': 1, 'tests/modeling/test_decoder_only.py': 1, 'tests/monitoring/test_codex_logging_cfg.py': 1, 'tests/monitoring/test_codex_logging_offline.py': 1, 'tests/monitoring/test_logging_bootstrap_initialization.py': 1, 'tests/monitoring/test_logging_bootstrap_real.py': 2, 'tests/ops/test_codex_mint_tokens_contract.py': 1, 'tests/pipeline/test_pipeline_config.py': 1, 'tests/plugins/test_registry_entries.py': 1, 'tests/release/test_release_dal.py': 1, 'tests/release/test_release_pack_verify.py': 1, 'tests/release/test_release_unpack.py': 1, 'tests/repro/test_determinism.py': 1, 'tests/reproducibility/test_deterministic_seeding.py': 1, 'tests/retrieval/test_faiss_store_enhanced.py': 1, 'tests/safeguards_tests/test_safeguards_comprehensive.py': 6, 'tests/security/test_offline_scans.py': 1, 'tests/security/test_pii_filter.py': 1, 'tests/services/api/test_rate_limit_middleware.py': 1, 'tests/smoke/test_artifacts_hash.py': 1, 'tests/smoke/test_checkpoint_hashing.py': 1, 'tests/smoke/test_cli_determinism_wiring.py': 1, 'tests/smoke/test_determinism.py': 1, 'tests/smoke/test_logging_flags_end_to_end.py': 2, 'tests/space_traversal/test_detector_safeguards.py': 3, 'tests/space_traversal/test_safeguards_keywords.py': 6, 'tests/specs/test_docs_score_synonyms.py': 1, 'tests/stub_packages/numpy/__init__.py': 1, 'tests/stub_packages/torch/__init__.py': 1, 'tests/test_batch_metrics_shim.py': 1, 'tests/test_checkpoint_checksum.py': 2, 'tests/test_checkpoint_checksum_and_retention.py': 1, 'tests/test_checkpoint_corrupt_load.py': 1, 'tests/test_checkpoint_corruption.py': 1, 'tests/test_checkpoint_integrity.py': 1, 'tests/test_checkpoint_integrity_corruption.py': 1, 'tests/test_checkpoint_restore_rng_torch.py': 2, 'tests/test_checkpoint_roundtrip.py': 2, 'tests/test_checkpoint_save_resume.py': 1, 'tests/test_checkpoint_sha_rng.py': 3, 'tests/test_checkpoint_util.py': 1, 'tests/test_checkpointing.py': 1, 'tests/test_checksum_sha256.py': 2, 'tests/test_cli.py': 1, 'tests/test_cli_config_sweep.py': 2, 'tests/test_cli_hydra_validation.py': 1, 'tests/test_cli_resume.py': 1, 'tests/test_cli_train_command.py': 1, 'tests/test_cli_train_engine.py': 1, 'tests/test_codex_best_effort.py': 1, 'tests/test_codex_data.py': 2, 'tests/test_data_loader.py': 1, 'tests/test_data_loaders.py': 1, 'tests/test_data_split_utils.py': 1, 'tests/test_data_splits.py': 1, 'tests/test_data_utils.py': 2, 'tests/test_dataset_checksums.py': 1, 'tests/test_dataset_manifest.py': 2, 'tests/test_dataset_wrapper.py': 1, 'tests/test_datasets_determinism.py': 1, 'tests/test_datasets_module.py': 1, 'tests/test_deploy_codex_pipeline.py': 1, 'tests/test_determinism.py': 1, 'tests/test_deterministic_split.py': 1, 'tests/test_engine_hf_trainer.py': 1, 'tests/test_env_logging.py': 1, 'tests/test_eval_loop_cpu.py': 1, 'tests/test_evaluate_epoch.py': 1, 'tests/test_grad_accumulation_path.py': 1, 'tests/test_gradient_accumulation_equivalence.py': 1, 'tests/test_gradient_accumulation_tail_flush.py': 1, 'tests/test_ingestion_seeded_shuffle.py': 1, 'tests/test_ingestion_split_cache.py': 1, 'tests/test_json_report.py': 1, 'tests/test_logging_utils.py': 1, 'tests/test_logging_utils_module.py': 1, 'tests/test_make_generator_worker_seed.py': 1, 'tests/test_metrics_generative.py': 1, 'tests/test_mlflow_utils.py': 1, 'tests/test_mlflow_utils_root.py': 1, 'tests/test_model_registry.py': 1, 'tests/test_monitoring_thread.py': 2, 'tests/test_msp_infer_api.py': 1, 'tests/test_offline_repo_auditor.py': 2, 'tests/test_policy_enforcement.py': 1, 'tests/test_repro_cli.py': 1, 'tests/test_repro_rng_roundtrip.py': 2, 'tests/test_repro_seed_consistency.py': 1, 'tests/test_reproducibility.py': 1, 'tests/test_runner_doctor.py': 1, 'tests/test_seeded_shuffle.py': 1, 'tests/test_simple_cli_seeding.py': 1, 'tests/test_split_indices.py': 1, 'tests/test_symbolic_pipeline.py': 1, 'tests/test_tokenizer_encode_decode.py': 1, 'tests/test_tokenizer_sp.py': 1, 'tests/test_train_loop_import_sideeffects.py': 1, 'tests/test_train_loop_smoke.py': 3, 'tests/test_train_smoke.py': 1, 'tests/test_trainer_extended.py': 1, 'tests/test_trainer_reward_registry.py': 1, 'tests/test_training_config_yaml.py': 1, 'tests/test_training_continual_strategy.py': 1, 'tests/test_training_eval.py': 1, 'tests/test_training_integration_flags.py': 1, 'tests/test_training_metadata_logging.py': 1, 'tests/test_training_resume.py': 1, 'tests/test_vendor_audit_scripts.py': 1, 'tests/test_wandb_shim.py': 2, 'tests/tokenization/test_cache.py': 1, 'tests/tokenization/test_encode_decode_roundtrip.py': 1, 'tests/tokenization/test_roundtrip_basic.py': 1, 'tests/tokenization/test_sentencepiece_roundtrip.py': 1, 'tests/tokenization/test_tiny_vocab_roundtrip.py': 1, 'tests/tokenization/test_tokenizer_basic.py': 1, 'tests/tokenization/test_tokenizer_training_streaming_equivalence.py': 1, 'tests/tokenization/test_train_tokenizer_smoke.py': 1, 'tests/tokenization/test_train_tokenizer_streaming.py': 1, 'tests/tools/test_codex_experiment_index.py': 1, 'tests/tracking/test_guards_offline_matrix.py': 1, 'tests/tracking/test_init_experiment_tags.py': 1, 'tests/tracking/test_mlflow_guard.py': 1, 'tests/tracking/test_mlflow_offline_cli.py': 1, 'tests/tracking/test_offline_decision.py': 1, 'tests/tracking/test_offline_helpers.py': 2, 'tests/tracking/test_offline_ndjson_logger.py': 1, 'tests/tracking/test_seed_snapshot_local.py': 1, 'tests/tracking/test_tracking_bootstrap.py': 2, 'tests/tracking/test_tracking_guard_matrix.py': 1, 'tests/tracking/test_tracking_guards.py': 2, 'tests/tracking/test_tracking_writers_offline.py': 1, 'tests/training/conftest.py': 1, 'tests/training/test_checkpoint_compat.py': 2, 'tests/training/test_checkpoint_integrity.py': 2, 'tests/training/test_checkpoint_manifest.py': 1, 'tests/training/test_checkpoint_resume.py': 1, 'tests/training/test_checkpoint_rng_restore.py': 2, 'tests/training/test_config_loading.py': 1, 'tests/training/test_cuda_determinism_guard.py': 1, 'tests/training/test_custom_loop_overfit.py': 1, 'tests/training/test_engine_hf_trainer_comprehensive.py': 1, 'tests/training/test_extended_trainer.py': 1, 'tests/training/test_functional_training_evaluation.py': 1, 'tests/training/test_functional_training_main.py': 1, 'tests/training/test_lora_optional.py': 1, 'tests/training/test_offline_wandb.py': 2, 'tests/training/test_overfit_smoke.py': 1, 'tests/training/test_resume_and_retention.py': 2, 'tests/training/test_rng_reproducibility.py': 2, 'tests/training/test_run_functional_training_resume.py': 1, 'tests/training/test_seed_util.py': 1, 'tests/training/test_seed_utils.py': 1, 'tests/training/test_split_determinism.py': 1, 'tests/training/test_strict_determinism.py': 1, 'tests/training/test_tiny_overfit.py': 1, 'tests/unit/test_peft_utils.py': 1, 'tests/unit/test_prepare_split.py': 1, 'tests/unit/test_provenance.py': 2, 'tests/unit/test_randomness.py': 1, 'tests/unit/test_tokenizer_cli_feature_flag.py': 1, 'tests/unit/test_train_entrypoint.py': 1, 'tests/unit/test_validators.py': 1, 'tests/utils/test_checkpoint_rng.py': 2, 'tests/utils/test_checkpointing.py': 1, 'tests/utils/test_checkpointing_core.py': 2, 'tests/utils/test_codex_utils_offline.py': 3, 'tests/utils/test_provenance_export.py': 2, 'tests/utils/test_repro_rng.py': 2, 'tests/utils/test_rng_state.py': 2, 'tests/utils/test_seed.py': 1, 'tests/validation/test_audit_pipeline.py': 1, 'tests/workflow/test_track_c_workflow.py': 1, 'tokenization/loader.py': 1, 'tools/actions_server.py': 1, 'tools/apply_branchA_all.py': 3, 'tools/apply_codex_audit_tasks.py': 1, 'tools/apply_ml_metrics.py': 2, 'tools/apply_mlflow_tracking.py': 1, 'tools/apply_stack_polish.py': 2, 'tools/archive_manager/README.md': 1, 'tools/archive_manager/archive_manager.py': 1, 'tools/assets/build_manifest.py': 1, 'tools/assets/verify_manifest.py': 2, 'tools/audit_builder.py': 2, 'tools/auto_analyze_errors.py': 1, 'tools/bench_unified_training.py': 1, 'tools/capability_autodiscover.py': 1, 'tools/catalog_db.py': 1, 'tools/codex_apply_modeling_monitoring_api.py': 4, 'tools/codex_audit_orchestrator.py': 1, 'tools/codex_data_audit.py': 1, 'tools/codex_dependency_audit.py': 1, 'tools/codex_execute_audit.py': 3, 'tools/codex_experiment_summary.py': 1, 'tools/codex_import_normalizer.py': 1, 'tools/codex_make_smoke_tests.py': 2, 'tools/codex_run.py': 1, 'tools/codex_secret_scan.py': 1, 'tools/codex_seq_runner.py': 3, 'tools/codex_task_runner.py': 1, 'tools/codex_workflow_executor.py': 1, 'tools/configs/list_groups.py': 1, 'tools/configs/schema_guard.py': 2, 'tools/ephem_autoscaler.sh': 1, 'tools/ephem_runner.sh': 2, 'tools/export_to_parquet.py': 1, 'tools/file_integrity_audit.py': 1, 'tools/gen_tiny_spm.py': 2, 'tools/generate_status_update.py': 4, 'tools/git_patch_parser_complete.py': 2, 'tools/github/app_token.py': 1, 'tools/github/app_token.sh': 1, 'tools/github/gh_api.py': 1, 'tools/ledger.py': 1, 'tools/make_spm_fixture.py': 2, 'tools/make_wheelhouse.sh': 1, 'tools/metrics/generate_repo_metrics.py': 1, 'tools/offline_ci_runner.py': 1, 'tools/offline_repo_auditor.py': 2, 'tools/pip_audit_wrapper.py': 1, 'tools/post_check_validation.py': 2, 'tools/prepare_reasoning_corpora.py': 1, 'tools/prepare_reasoning_streams.py': 1, 'tools/run_codex_sequence.sh': 1, 'tools/run_supplied_task.py': 1, 'tools/runner_doctor.py': 1, 'tools/security/offline_scans.py': 1, 'tools/status/generate_status_update.py': 2, 'tools/status/migrate_v1_1_to_v1_2.py': 1, 'tools/status/remediation_workflow.py': 1, 'tools/test_auto_analyze_errors.py': 1, 'tools/unify_logging_canonical.py': 1, 'tools/uv_lock_refresh.sh': 1, 'tools/validate_checkpoint.py': 1, 'tools/validate_configs.py': 1, 'tools/validate_repo_0D_base.py': 2, 'training/checkpoint_manager.py': 1, 'training/config.py': 1, 'training/data_utils.py': 3, 'training/datasets.py': 3, 'training/engine_hf_trainer.py': 4, 'training/functional_training.py': 4, 'training/offline_wandb.py': 2, 'training/seed.py': 1, 'training/seed_utils.py': 1, 'transformed_pr_overview.md': 2, 'transformers/__init__.py': 1, 'validation.md': 2}

Patterns Found: WANDB_MODE, checksum, offline, rng, seed, sha256

Evidence Files (first 10):
```
```
### safety-security
Score: 0.7309

Components:
- Functionality: 1.0
- Consistency: 0.862745
- Tests: 0.333333
- Safeguards: 0.5
- Documentation: 1.0


Patterns Found: sanitize, secret

Evidence Files (first 10):
```
.codex/evidence/phase5_privacy_safety.jsonl
artifacts/security/safety.txt
configs/base/safety/policy.yaml
configs/msp/safety.yaml
configs/safety/policy.yaml
docs/guides/CHECKPOINT_SAFETY.md
docs/modules/safety.md
docs/safety.md
docs/safety/differential_privacy.md
docs/safety/moderation_adapter.md
```
### status-reporting
Score: 0.7588

Components:
- Functionality: 1.0
- Consistency: 0.904382
- Tests: 0.111554
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- layer: operations
- priority: medium
- category: monitoring
- missing_detectors: ['audit', 'report', 'status']

Patterns Found: audit, report, status

Evidence Files (first 10):
```
.codex/GATES_REPORT.txt
.codex/automation_out/coverage_report.json
.codex/change_log_compare_report.json
.codex/evidence/audit_fixes_phase1.jsonl
.codex/evidence/phase1_audit_fixes.jsonl
.codex/evidence/phase2_requirements_audit.jsonl
.codex/evidence/phase3_summary.md
.codex/evidence/phase4_dependencies_audit.jsonl
.codex/notes/CODEBASE_AUDIT.md
.codex/reports/.gitkeep
```
### structural-integrity
Score: 0.5773

Components:
- Functionality: 1.0
- Consistency: 0.9
- Tests: 0.0
- Safeguards: 0.666667
- Documentation: 0.315457

Meta:
- risk_level: high
- description: Detects architectural split-brain and namespace shadowing.
- split_dirs: ['codex_ml', 'codex_utils', 'data', 'experiments', 'tokenization', 'tools', 'training']
- shadow_dirs: ['torch']
- evidence_limit: 10

Patterns Found: lib-shadowing, split-brain

Evidence Files (first 10):
```
codex_ml/__init__.py
codex_ml/__main__.py
codex_ml/_package_main.py
codex_ml/cli/main.py
codex_ml/data/checksums.py
codex_utils/__init__.py
codex_utils/cli/ndjson_summary.py
codex_utils/json_report.py
codex_utils/logging_setup.py
codex_utils/mlflow_offline.py
```
### testing-infrastructure
Score: 0.9133

Components:
- Functionality: 0.75
- Consistency: 0.892384
- Tests: 0.989238
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- test_count: 1186
- config_count: 27
- fixture_count: 33

Patterns Found: fixture, pytest, test_

Evidence Files (first 10):
```
.github/docs/AGENTS_Integration_Test_Fixture_Refactor_Copilot.md
agents/codex_client/pyproject.toml
configs/base/offline/tiny_fixtures.yaml
configs/development/pytest.ini
conftest.py
pyproject.toml
pytest.ini
scripts/space_traversal/fixtures/coverage.xml
services/ita/pyproject.toml
temp/bridge_codex_copilot_bridge/agents/codex_client/pyproject.toml
```
### tokenization
Score: 0.7970

Components:
- Functionality: 1.0
- Consistency: 0.827586
- Tests: 0.525862
- Safeguards: 0.666667
- Documentation: 1.0


Patterns Found: encode, tokenizer

Evidence Files (first 10):
```
_codex_reports/2025-10-06/tokenizer_check.json
artifacts/models/tiny_tokenizer/vocab.json
codex_digest/tokenizer.py
configs/training/tokenization/base.yaml
configs/training/tokenizer/multilingual.yaml
configs/training/tokenizer/offline/gpt2.yaml
configs/training/tokenizer/offline/tiny_vocab.yaml
configs/training/tokenizer/offline/tinyllama.yaml
configs/training/tokenizer/train_tokenizer.yaml
docs/guides/tokenization.md
```
### training-engine
Score: 0.8289

Components:
- Functionality: 1.0
- Consistency: 0.845528
- Tests: 0.439024
- Safeguards: 1.0
- Documentation: 1.0

Meta:
- _aliases: ['functional_training', 'train_loop']

Patterns Found: epoch, functional_training, train, train_loop

Evidence Files (first 10):
```
_codex_reports/2025-10-06/trainer_smoke.json
_codex_reports/2025-10-06/trainer_smoke.log
artifacts/diffs/training_py01_removal.md
cli/train_codex.py
cli/train_schema_demo.py
conf/minimal_train.yaml
conf/training/minimal.yaml
configs/deployment/hhg_logistics/train/default.yaml
configs/deployment/hhg_logistics/train/lora.yaml
configs/schemas/training.schema.yaml
```
### unified-training
Score: 0.8450

Components:
- Functionality: 1.0
- Consistency: 0.6
- Tests: 1.0
- Safeguards: 0.5
- Documentation: 1.0

Meta:
- category: training

Patterns Found: UnifiedTrainingConfig, run_unified_training

Evidence Files (first 10):
```
scripts/space_traversal/detectors/unified_training.py
src/codex_ml/detectors/unified_training.py
src/codex_ml/training/unified_training.py
tests/detectors/test_unified_training.py
tools/bench_unified_training.py
```
### vector-stores
Score: 0.4902

Components:
- Functionality: 0.0
- Consistency: 1.0
- Tests: 1.0
- Safeguards: 0.0
- Documentation: 0.268139

Meta:
- mode: stub-or-mock

Patterns Found: None

Evidence Files (first 10):
```
codex_addons/vector_stores/__init__.py
codex_addons/vector_stores/pgvector_stub.py
codex_addons/vector_stores/weaviate_stub.py
```

## 6. Appendix
| Field | Description |
|-------|-------------|
| template_hash | Hash of concatenated Jinja templates |
| generation_strategy | Weighted component aggregation |
| scoring_components | functionality, consistency, tests, safeguards, documentation |

Embedded Template SHA256: e43cf2130efeaae1af314254ccc51bfbc219feaef3e5635a682da251a9710d43

*End of Matrix*