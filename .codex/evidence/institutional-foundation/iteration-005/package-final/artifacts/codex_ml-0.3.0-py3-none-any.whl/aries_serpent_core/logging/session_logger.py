"""Session logging utilities for Codex.

Provides:
- `SessionLogger`: context manager logging session_start/session_end via
  `log_event`.
- `log_message(session_id, role, message, db_path=None)`:
  validated message logging helper.

If the repo already defines `log_event`, `init_db`, and `_DB_LOCK` under
`codex.logging`, we import and use them. Otherwise we fall back to local,
minimal implementations (scoped in this file) to preserve end-to-end behavior
without polluting global API.

Roles allowed: system|user|assistant|tool|INFO|WARN.

This module is intentionally small and self-contained; it does NOT activate any
GitHub Actions or external services.
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
from typing import Any, Literal, Optional

logger = logging.getLogger(__name__)

try:
    from aries_serpent_core.db.sqlite_patch import auto_enable_from_env as _codex_sqlite_auto

    _codex_sqlite_auto()
except (ImportError, AttributeError) as exc:  # pragma: no cover - defensive
    logging.getLogger(__name__).debug("sqlite auto setup failed: %s", exc)

_fetch_messages_mod = import_module(".fetch_messages", __package__)

try:  # pragma: no cover - allow running standalone
    from .config import DEFAULT_LOG_DB
except (
    IOError,
    OSError,
    ModuleNotFoundError,
    ImportError,
):  # pragma: no cover - fallback when not a package
    DEFAULT_LOG_DB = Path(".codex/session_logs.db")

# -------------------------------
# Attempt to import shared helpers
# -------------------------------
try:
    # Expected existing helpers (preferred)
    from .db import _DB_LOCK as _shared_DB_LOCK
    from .db import init_db as _shared_init_db
    from .db import log_event as _shared_log_event
except (ImportError, AttributeError):
    logger.debug("codex.logging.db not available; using built-in fallbacks", exc_info=True)
    _shared_DB_LOCK = None  # type: ignore[assignment]
    _shared_init_db = None  # type: ignore[assignment]
    try:  # Prefer the public compatibility adapter used by legacy imports.
        from codex.monkeypatch.log_adapters import (  # type: ignore[no-redef]  # noqa: I001
            log_event as _shared_log_event,
        )
    except (IOError, OSError, ModuleNotFoundError, ImportError):
        try:  # Fallback: rely on the current package adapter if present.
            from aries_serpent_core.monkeypatch.log_adapters import (  # type: ignore[no-redef]  # noqa: I001
                log_event as _shared_log_event,
            )
        except (
            IOError,
            OSError,
            ModuleNotFoundError,
            ImportError,
        ):  # pragma: no cover - nothing available
            _shared_log_event = None  # type: ignore[assignment]
# Local, minimal fallbacks (if needed)
# ------------------------------------
_DB_LOCK = _shared_DB_LOCK or threading.RLock()

# Module-level tracker for initialized database paths
INITIALIZED_PATHS: set[str] = set()
_INITIALIZING_PATHS: dict[str, threading.Event] = {}

# Optional SQLite connection pool keyed by database path
USE_POOL = os.getenv("CODEX_SQLITE_POOL") == "1"
CONN_POOL: dict[str, sqlite3.Connection] = {}


def _configure_connection(conn: sqlite3.Connection) -> None:
    """Apply best-effort SQLite pragmas for pooled connections."""

    try:
        conn.execute("PRAGMA journal_mode=WAL;")
    except (ConnectionError, TimeoutError) as e:
        logger.warning("journal_mode=WAL failed: %s", e, exc_info=True)
    try:
        conn.execute("PRAGMA synchronous=NORMAL;")
    except (ValueError, TypeError, RuntimeError) as e:
        logger.warning("synchronous=NORMAL failed: %s", e)
    try:
        conn.execute("PRAGMA foreign_keys=ON;")
    except (ValueError, TypeError, RuntimeError) as e:
        logger.warning("foreign_keys=ON failed: %s", e)


def _close_pool() -> None:
    for conn in list(CONN_POOL.values()):
        try:
            conn.close()
        except sqlite3.Error as exc:  # pragma: no cover - defensive
            logging.getLogger(__name__).debug("pool close failed: %s", exc)
    CONN_POOL.clear()


if USE_POOL:
    atexit.register(_close_pool)


def _default_db_path() -> Path:
    """Return default database path, honoring environment variable at call time."""
    return Path(os.getenv("CODEX_LOG_DB_PATH", str(DEFAULT_LOG_DB)))


def init_db(db_path: Optional[Path] = None) -> Path:
    """Initialize SQLite table for session events if absent."""
    p = Path(db_path or _default_db_path())
    key = str(p)
    leader_event: Optional[threading.Event] = None
    while True:
        with _DB_LOCK:
            if key in INITIALIZED_PATHS:
                return p  # already initialized (no-op)
            pending = _INITIALIZING_PATHS.get(key)
            if pending is None:
                pending = threading.Event()
                _INITIALIZING_PATHS[key] = pending
                leader_event = pending
                break
        pending.wait()
    if leader_event is None:
        raise RuntimeError("leader_event not initialized; init_db synchronization failed")
    p.parent.mkdir(parents=True, exist_ok=True)
    conn: Optional[sqlite3.Connection] = None
    try:
        conn = sqlite3.connect(p)
        try:
            conn.execute("PRAGMA journal_mode=WAL;")
        except (ConnectionError, TimeoutError) as e:
            logger.warning("journal_mode=WAL failed: %s", e, exc_info=True)
        try:
            conn.execute("""CREATE TABLE IF NOT EXISTS session_events(
                        ts REAL NOT NULL,
                        session_id TEXT NOT NULL,
                        role TEXT NOT NULL,
                        message TEXT NOT NULL,
                        seq INTEGER,
                        meta TEXT
                    )""")
            cols = [r[1] for r in conn.execute("PRAGMA table_info(session_events)")]
            if "seq" not in cols:
                conn.execute("ALTER TABLE session_events ADD COLUMN seq INTEGER")
            if "meta" not in cols:
                conn.execute("ALTER TABLE session_events ADD COLUMN meta TEXT")
            # Index `session_id` and `ts` for faster queries and pruning operations.
            conn.execute(
                "CREATE INDEX IF NOT EXISTS session_events_sid_ts_idx "
                "ON session_events(session_id, ts)"
            )
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS session_events_session_seq_idx "
                "ON session_events(session_id, seq)"
            )
            conn.commit()
        finally:
            conn.close()
    except (IOError, OSError, ModuleNotFoundError, ImportError):
        logger.warning("init_db failed", exc_info=True)
        with _DB_LOCK:
            _INITIALIZING_PATHS.pop(key, None)
        leader_event.set()
        raise
    else:
        with _DB_LOCK:
            INITIALIZED_PATHS.add(key)
            _INITIALIZING_PATHS.pop(key, None)
        leader_event.set()
        return p


def _fallback_log_event(
    session_id: str,
    role: str,
    message: str,
    db_path: Optional[Path] = None,
    meta: Optional[dict[str, Any]] = None,
) -> None:
    p = init_db(db_path)
    key = str(p)
    if USE_POOL:
        conn = CONN_POOL.get(key)
        if conn is None:
            conn = sqlite3.connect(p, check_same_thread=False)
            _configure_connection(conn)
            CONN_POOL[key] = conn
    else:
        conn = sqlite3.connect(p)
        _configure_connection(conn)
    try:
        cur = conn.execute(
            "SELECT COALESCE(MAX(seq), 0) FROM session_events WHERE session_id=?",
            (session_id,),
        )
        next_seq = cur.fetchone()[0] + 1
        conn.execute(
            "INSERT INTO session_events("
            "ts, session_id, role, message, seq, meta) "
            "VALUES(?,?,?,?,?,?)",
            (
                time.time(),
                session_id,
                role,
                message,
                next_seq,
                json.dumps(meta) if meta else None,
            ),
        )
        conn.commit()
    except (ValueError, TypeError):
        logger.warning("Exception occurred in _fallback_log_event", exc_info=True)
        if USE_POOL:
            try:
                conn.close()
            except sqlite3.Error as exc:  # pragma: no cover - defensive
                logging.getLogger(__name__).debug("pool conn close failed: %s", exc)
            CONN_POOL.pop(key, None)
        raise
    finally:
        if not USE_POOL:
            conn.close()


def log_event(
    session_id: str,
    role: str,
    message: str,
    db_path: Optional[Path] = None,
    meta: Optional[dict[str, Any]] = None,
) -> None:
    """Delegate to shared log_event if available, otherwise fallback."""
    if _shared_log_event is not None:
        if getattr(_shared_log_event, "__module__", "") == "codex.monkeypatch.log_adapters":
            _fallback_log_event(session_id, role, message, db_path=db_path, meta=meta)
            adapter_meta: dict[str, Any] = {"session_id": session_id}
            if meta is not None:
                adapter_meta["meta"] = meta
            adapter_meta_json = json.dumps(adapter_meta, ensure_ascii=False, default=str)
            try:
                # log_adapters.log_event signature: (level, message, meta=None, db_path=None)
                _shared_log_event(  # type: ignore[call-arg]
                    role,
                    message,
                    meta=adapter_meta_json,  # type: ignore[arg-type]
                    db_path=db_path,
                )
                return
            except TypeError as e:
                logger.warning("monkeypatch adapter call failed (trying minimal): %s", e)
                try:
                    _shared_log_event(session_id, role, message)
                except TypeError as e:
                    logger.debug(
                        "shared log_event compatibility fallback failed: %s",
                        e,
                        exc_info=True,
                    )
            return
        try:
            _shared_log_event(session_id, role, message, db_path=db_path, meta=meta)
        except TypeError as e:
            logger.warning("shared log_event keyword call failed (retrying without meta): %s", e)
            _shared_log_event(session_id, role, message, db_path=db_path)
        return
    _fallback_log_event(session_id, role, message, db_path=db_path, meta=meta)
    return


_ALLOWED_ROLES = {"system", "user", "assistant", "tool", "INFO", "WARN"}


def get_session_id() -> str:
    """Return current session ID, generating and persisting if absent.

    If ``CODEX_SESSION_ID`` is not set, a new UUID is generated, stored in the
    process environment, and returned. Subsequent calls in the same process will
    return the same value.
    """

    sid = os.getenv("CODEX_SESSION_ID")
    if sid:
        return sid
    sid = str(uuid.uuid4())
    os.environ["CODEX_SESSION_ID"] = sid
    return sid


def fetch_messages(session_id: str, db_path: Optional[Path] = None) -> list[dict[str, Any]]:
    """Read a session's messages in ascending timestamp order.

    Args:
        session_id: Exact session identifier to select.
        db_path: SQLite path, defaulting to ``CODEX_LOG_DB_PATH`` or
            ``DEFAULT_LOG_DB`` when omitted.

    Returns:
        Dictionaries with ``ts``, ``role``, and ``message`` keys. The
        delegated reader initializes a missing database and returns an empty
        list for an unknown session or a database error during retrieval.
        Initialization errors are not covered by that retrieval fallback.
    """
    path = Path(db_path or _default_db_path())
    return _fetch_messages_mod.fetch_messages(session_id, db_path=path)


def log_message(
    session_id: str,
    role: str,
    message,
    db_path: Optional[Path] = None,
    meta: Optional[dict[str, Any]] = None,
) -> None:
    """Validate role, normalize message to string, ensure DB init, and write.

    Args:
        session_id: Correlates related events.
        role: One of {system,user,assistant,tool,INFO,WARN}.
        message: Any object; will be coerced to str().
        db_path: Optional path (Path/str). If None, uses CODEX_LOG_DB_PATH or
            DEFAULT_LOG_DB.
        meta: Optional event metadata forwarded to the active logging backend.

    Raises:
        ValueError: If ``role`` is not one of the allowed, case-sensitive roles.

    Usage:
        >>> from aries_serpent_core.logging.session_logger import log_message
        >>> log_message("S1", "user", "hi there")
    """
    if role not in _ALLOWED_ROLES:
        raise ValueError(f"invalid role {role!r}; expected one of {_ALLOWED_ROLES}")
    text = message if isinstance(message, str) else str(message)
    path = Path(db_path) if db_path else _default_db_path()
    init_db(path)
    with _DB_LOCK:
        log_event(session_id, role, text, db_path=path, meta=meta)


@dataclass
class SessionLogger:
    """Context manager for session-scoped logging.

    Example:
        >>> from aries_serpent_core.logging.session_logger import SessionLogger
        >>> with SessionLogger(session_id="dev-session") as sl:
        ...     sl.log("user", "hi")
        ...     sl.log("assistant", "hello")
    """

    session_id: str
    db_path: Optional[Path] = None

    def __post_init__(self) -> None:
        if _shared_init_db is not None and self.db_path is not None:
            _shared_init_db(self.db_path)

    def __enter__(self) -> SessionLogger:
        log_event(self.session_id, "system", "session_start", db_path=self.db_path)
        return self

    def __exit__(self, exc_type, exc, tb) -> Literal[False]:
        try:
            if exc_type is not None:
                log_event(
                    self.session_id,
                    "system",
                    f"session_end (exc={exc_type.__name__}: {exc})",
                    db_path=self.db_path,
                )
            else:
                log_event(
                    self.session_id,
                    "system",
                    "session_end",
                    db_path=self.db_path,
                )
        except (IOError, OSError, ModuleNotFoundError, ImportError):
            logger.warning("session_end DB log failed", exc_info=True)
        return False

    def log(self, role: str, message) -> None:
        """Append a message using this logger's session ID and database path.

        Delegates to :func:`log_message`, including its role validation and
        string conversion. Accepted roles are ``system``, ``user``,
        ``assistant``, ``tool``, ``INFO``, and ``WARN``; others raise
        ``ValueError``. Can be called directly or inside the context manager;
        only context entry/exit adds session boundary events.
        """
        log_message(self.session_id, role, message, db_path=self.db_path)


def migrate_legacy_events(db_path: Optional[Path] = None) -> None:
    """Backfill ``seq`` for rows missing it and remove duplicate start/end events."""

    path = init_db(db_path)
    conn = sqlite3.connect(path)
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
    except (IOError, OSError, ModuleNotFoundError, ImportError) as e:
        logger.warning("journal_mode=WAL failed: %s", e, exc_info=True)
    try:
        conn.execute("BEGIN")
        # Backfill seq for rows lacking it
        cur = conn.execute("SELECT DISTINCT session_id FROM session_events WHERE seq IS NULL")
        for (sid,) in cur.fetchall():
            max_seq = conn.execute(
                "SELECT COALESCE(MAX(seq),0) FROM session_events WHERE session_id=?",
                (sid,),
            ).fetchone()[0]
            rows = conn.execute(
                "SELECT rowid FROM session_events WHERE session_id=? AND seq IS NULL ORDER BY ts",
                (sid,),
            ).fetchall()
            for row in rows:
                max_seq += 1
                conn.execute("UPDATE session_events SET seq=? WHERE rowid=?", (max_seq, row[0]))
        # Remove duplicate start/end events
        cur = conn.execute(
            "SELECT DISTINCT session_id FROM session_events "
            "WHERE message IN ('session_start','session_end')"
        )
        for (sid,) in cur.fetchall():
            start_ids = [
                r[0]
                for r in conn.execute(
                    "SELECT rowid FROM session_events WHERE session_id=? "
                    "AND message='session_start' ORDER BY ts",
                    (sid,),
                ).fetchall()
            ]
            for rid in start_ids[1:]:
                conn.execute("DELETE FROM session_events WHERE rowid=?", (rid,))
            end_ids = [
                r[0]
                for r in conn.execute(
                    "SELECT rowid FROM session_events WHERE session_id=? "
                    "AND message='session_end' ORDER BY ts DESC",
                    (sid,),
                ).fetchall()
            ]
            for rid in end_ids[1:]:
                conn.execute("DELETE FROM session_events WHERE rowid=?", (rid,))
        conn.commit()
    finally:
        conn.close()
