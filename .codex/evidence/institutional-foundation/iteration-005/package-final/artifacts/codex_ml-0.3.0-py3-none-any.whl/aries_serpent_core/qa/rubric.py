"""
Rubric Module

This module provides functionality for rubric.

Usage:
    from qa.rubric import ...

Classes:
    [To be documented]

Functions:
    [To be documented]

Author: Codex Team
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


import csv  # noqa: E402
import json  # noqa: E402
from pathlib import Path  # noqa: E402
from typing import Any  # noqa: E402

from pydantic import BaseModel, Field  # noqa: E402


class RubricCriterion(BaseModel):
    """A single evaluation criterion in a QA rubric."""

    id: str
    description: str
    max_score: float


class QARubric(BaseModel):
    """A QA rubric composed of multiple criteria."""

    name: str
    criteria: list[RubricCriterion] = Field(default_factory=list)


def load_rubric(path: Path) -> QARubric:
    """
    Load a QA rubric definition from a file.
    Supports CSV (with headers: id, description, max_score) or JSON format.
    """

    if path.suffix.lower() == ".csv":
        criteria: list[RubricCriterion] = []
        with path.open("r", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                if not row:
                    continue
                criteria.append(
                    RubricCriterion(
                        id=(row.get("id") or "").strip(),
                        description=(row.get("description") or "").strip(),
                        max_score=float(row.get("max_score") or 0),
                    )
                )
        return QARubric(name=path.stem, criteria=criteria)

    data = json.loads(path.read_text(encoding="utf-8"))
    return QARubric(**data)


def generate_scores(input_path: Path, rubric: QARubric, output_path: Path) -> None:
    """
    Generate a JSONL file with scores per record based on the provided rubric.
    Expects input CSV with an 'id' column and one column per rubric criterion
    (using the criterion identifier as the header).
    """

    with (
        input_path.open("r", encoding="utf-8") as fin,
        output_path.open("w", encoding="utf-8") as fout,
    ):
        reader = csv.DictReader(fin)
        for row in reader:
            if not row:
                continue
            record_id = row.get("id") or row.get("record_id") or ""
            scores: dict[str, Any] = {}
            total_score = 0.0
            for criterion in rubric.criteria:
                raw_value = row.get(criterion.id)
                try:
                    value = float(raw_value) if raw_value not in (None, "") else None
                except ValueError as e:
                    type(e).__name__
                    logger.debug("ValueError: <ERROR_TYPE>")
                    logger.warning("ValueError: <ERROR_TYPE>", exc_info=True)
                    value = None
                scores[criterion.id] = value
                if value is not None:
                    total_score += value
            payload = {"id": record_id, "scores": scores, "total_score": total_score}
            fout.write(json.dumps(payload) + "\n")
