"""Query a session or the latest events from a SQLite logging database.

Usage::

    python -m aries_serpent_core.logging.session_query --db logs.db --session-id S123
    python -m aries_serpent_core.logging.session_query --db logs.db --last 20 --desc

At least one of ``--session-id`` and ``--last`` is required; they can be
combined to select the latest N events within a session. Results are printed
as tab-separated timestamp/session/role/message fields, ascending by timestamp
unless ``--desc`` is given. There are no role, substring, or time-bound flags
in this module; use ``aries_serpent_core.logging.query_logs`` for role/time
filters or ``aries_serpent_core.logging.viewer`` for substring filters.

The database path comes from ``--db``, then ``CODEX_DB_PATH`` or
``CODEX_LOG_DB_PATH``, then the first existing ``DEFAULT_DB_CANDIDATES`` entry.
Each fetch opens and closes its own connection. Schema detection requires a
timestamp and message column; a session ID column is required only when
filtering by session. Role columns are optional.
"""

from __future__ import annotations

import argparse
import logging
import os  # noqa: E402
import re  # noqa: E402
import sqlite3  # noqa: E402
import sys  # noqa: E402
from collections.abc import Iterable  # noqa: E402
from pathlib import Path  # noqa: E402
from typing import Any, Optional  # noqa: E402

from aries_serpent_core.logging.structured_logger import logger

try:
    from aries_serpent_core.db.sqlite_patch import auto_enable_from_env as _codex_sqlite_auto

    _codex_sqlite_auto()
except (ImportError, AttributeError) as exc:  # pragma: no cover - defensive
    logging.getLogger(__name__).debug("sqlite auto setup failed: %s", exc)

from .config import DEFAULT_LOG_DB  # noqa: E402

_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _sanitize_table(name: str) -> str:
    if not _IDENT_RE.fullmatch(name):
        raise ValueError(f"Unsafe table name: {name!r}")
    return name


DEFAULT_DB_CANDIDATES = [
    str(DEFAULT_LOG_DB),
    "codex_session_log.db",
    "data/codex.db",
    "codex.db",
]

TS_CANDIDATES = ["timestamp", "ts", "event_ts", "created_at", "time", "datetime"]
SID_CANDIDATES = ["session_id", "sid", "session", "conversation_id"]
ROLE_CANDIDATES = ["role", "type", "speaker", "kind"]
MSG_CANDIDATES = ["message", "content", "text", "body", "value"]


def _resolve_with_extension(path: str) -> str:
    """Return existing path, falling back between .db and .sqlite."""
    p = Path(path)
    if p.exists():
        return str(p)
    if p.suffix in {".db", ".sqlite"}:
        alt = p.with_suffix(".sqlite" if p.suffix == ".db" else ".db")
        if alt.exists():
            return str(alt)
    return str(p)


def resolve_db_path(cli_db: Optional[str]) -> str:
    """Resolve database path from CLI, environment, or known defaults.

    Lookup order:
    1. ``--db`` flag
    2. ``CODEX_DB_PATH`` or ``CODEX_LOG_DB_PATH`` environment variables
    3. First existing entry in ``DEFAULT_DB_CANDIDATES`` (search stops after the
        first hit and only inspects top-level ``.codex`` or ``data`` directories).
    """
    if cli_db:
        return cli_db
    env = os.getenv("CODEX_DB_PATH") or os.getenv("CODEX_LOG_DB_PATH")
    if env:
        return env
    for c in DEFAULT_DB_CANDIDATES:
        if os.path.exists(c):
            return c
    raise FileNotFoundError(
        "No database found. Provide --db or set CODEX_DB_PATH/CODEX_LOG_DB_PATH",
    )


def detect_schema(conn: sqlite3.Connection) -> tuple[str, dict[str, str]]:
    """Infer table and column names for timestamp/session/role/message."""
    cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [r[0] for r in cur.fetchall()]
    for table in tables:
        try:
            safe = _sanitize_table(table)
        except ValueError as e:
            type(e).__name__
            logger.debug("ValueError: <ERROR_TYPE>")
            logger.warning("ValueError: <ERROR_TYPE>", exc_info=True)
            continue
        cur = conn.execute(f"PRAGMA table_info({safe})")
        cols = [row[1] for row in cur.fetchall()]
        mapping: dict[str, str] = {}
        for want, candidates in {
            "timestamp": TS_CANDIDATES,
            "session_id": SID_CANDIDATES,
            "role": ROLE_CANDIDATES,
            "message": MSG_CANDIDATES,
        }.items():
            for c in candidates:
                if c in cols:
                    mapping[want] = c
                    break
        if "timestamp" in mapping and "message" in mapping:
            return table, mapping
    raise RuntimeError(f"No suitable events table found. Tables: {tables}")


def fetch_rows(
    db_path: str,
    session_id: Optional[str],
    last_n: Optional[int],
    desc: bool,
) -> tuple[list[sqlite3.Row], dict[str, str]]:
    """Fetch events and the logical-to-actual column mapping used to read them.

    Args:
        db_path: SQLite filename passed directly to ``sqlite3.connect``.
        session_id: Optional exact session filter; an empty string is unfiltered.
        last_n: If not ``None``, select the latest N rows by descending
            timestamp before reordering them for display. ``None`` selects all
            matching rows. Passed to SQLite's LIMIT without range validation.
        desc: Return the selected rows in descending rather than ascending
            timestamp order.

    Returns:
        A pair of materialized ``sqlite3.Row`` objects and the mapping from
        :func:`detect_schema`. Row keys use actual database column names.
        The connection is closed before returning, including on errors.

    Raises:
        RuntimeError: No compatible table exists, or session filtering was
            requested but no session ID column was detected.
        sqlite3.Error: Opening or querying the database fails.

    For example, ``fetch_rows("logs.db", "S123", 10, False)`` selects the latest
    ten events in S123 but returns that subset in chronological order.
    """
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        table, cols = detect_schema(conn)
        ts_col = cols["timestamp"]
        sid_col = cols.get("session_id")
        order_clause = "DESC" if desc else "ASC"
        select_cols = [ts_col]
        if sid_col:
            select_cols.append(sid_col)
        if "role" in cols:
            select_cols.append(cols["role"])
        select_cols.append(cols["message"])
        select_list = ", ".join(select_cols)
        sql = f"SELECT {select_list} FROM {table}"  # nosec B608
        params: list[object] = []
        where_clause = ""
        if session_id:
            if not sid_col:
                raise RuntimeError("Session filtering requested but no session id column found")
            where_clause = f" WHERE {sid_col}=?"  # nosec B608
            params.append(session_id)

        if last_n is not None:
            inner_sql = (  # nosec B608
                f"SELECT {select_list} FROM {table}{where_clause} "  # nosec B608
                f"ORDER BY {ts_col} DESC LIMIT ?"
            )
            sql = f"SELECT * FROM ({inner_sql}) sub ORDER BY {ts_col} {order_clause}"  # nosec B608
            params.append(last_n)
        else:
            sql = f"SELECT {select_list} FROM {table}{where_clause} ORDER BY {ts_col} {order_clause}"  # nosec B608  # nosec B608
        cur = conn.cursor()
        rows = list(cur.execute(sql, params))
        return rows, cols
    finally:
        conn.close()


def print_rows(rows: list[sqlite3.Row], cols: dict[str, str]) -> None:
    """Print fetched rows to stdout as an unescaped tab-separated table.

    ``cols`` is the logical-to-actual mapping returned by :func:`fetch_rows`.
    Fields appear in timestamp, session ID, role, message order, omitting
    unavailable fields. SQL NULL values render as empty strings. Empty input
    prints ``(no rows)`` instead of a header. Tabs/newlines within messages are
    not escaped, so this is a display format rather than a lossless export.
    """
    if not rows:
        print("(no rows)")
        return
    header_keys = [k for k in ["timestamp", "session_id", "role", "message"] if k in cols]
    print("\t".join(header_keys))
    for r in rows:
        print("\t".join("" if r[cols[k]] is None else str(r[cols[k]]) for k in header_keys))


def main(argv: Optional[Iterable[str]] = None) -> int:
    """Parse session/latest-event flags, fetch rows, and print the result.

    ``argv`` omits the executable name; ``None`` uses process arguments.
    Returns ``0`` on success (including an empty result) or ``2`` for caught
    I/O/import errors, including a missing database found by path resolution.
    Argument errors raise argparse's ``SystemExit``. Schema ``RuntimeError``
    and ``sqlite3.Error`` propagate rather than becoming return codes.
    """
    parser = argparse.ArgumentParser(
        description="Query session events from a SQLite database",
    )
    parser.add_argument("--session-id", help="Filter events by session id")
    parser.add_argument("--last", type=int, metavar="N", help="Show last N events")
    parser.add_argument("--db", help="Path to SQLite database")
    parser.add_argument(
        "--desc",
        action="store_true",
        help="Sort output in descending order (default asc for session-id mode)",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)
    if args.session_id is None and args.last is None:
        parser.error("Provide --session-id, --last, or both")

    try:
        db = resolve_db_path(args.db)
        rows, cols = fetch_rows(db, args.session_id, args.last, args.desc)
        print_rows(rows, cols)
        return 0
    except (
        IOError,
        OSError,
        ModuleNotFoundError,
        ImportError,
    ) as exc:  # pragma: no cover - top-level guard
        type(exc).__name__
        logger.error("ERROR: <ERROR_TYPE>")
        return 2


if __name__ == "__main__":  # pragma: no cover - CLI entry
    session_ctx: Optional[Any]
    try:
        from .session_hooks import session as session_ctx
    except (ImportError, AttributeError):  # pragma: no cover - optional helper
        session_ctx = None
    if session_ctx:
        with session_ctx(sys.argv):
            raise SystemExit(main())
    raise SystemExit(main())
