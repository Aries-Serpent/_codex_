"""
Export all events for a given session as JSON or plain text.

Usage:
    python -m aries_serpent_core.logging.export SESSION_ID --format {json,text}
    # custom DB:
    python -m aries_serpent_core.logging.export SESSION_ID --db /path/to/db.sqlite

Environment:
    CODEX_LOG_DB_PATH   Default DB path if --db not provided (CODEX_DB_PATH fallback).

Examples:
    from aries_serpent_core.logging.export import export_session
    payload = export_session("S123", fmt="json", db=".codex/session_logs.db")
    # payload is the serialized export; the caller chooses where to write it.

Behavior:
    The CLI emits the serialized result through the configured logger, not a
    dedicated stdout stream. Use export_session() when a raw string is needed.
    Each export opens and closes its own connection.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import sys
from collections.abc import Iterable
from typing import Any, Optional

from aries_serpent_core.logging.structured_logger import logger

try:
    from aries_serpent_core.db.sqlite_patch import auto_enable_from_env as _codex_sqlite_auto

    _codex_sqlite_auto()
except (IOError, OSError, ModuleNotFoundError, ImportError) as e:
    logger.warning("sqlite auto setup skipped: %s", e, exc_info=True)

from .config import DEFAULT_LOG_DB  # noqa: E402
from .db_utils import (  # noqa: E402
    infer_columns,
    infer_probable_table,
    open_db,
    resolve_db_path,
)


def _db_path(override: str | None = None) -> str:
    """Resolve the SQLite path using env, override, or default.

    If no explicit path is provided, look for `DEFAULT_LOG_DB` or
    `DEFAULT_LOG_DB.with_suffix(".sqlite")` in the current working directory.
    """

    if override:
        return str(resolve_db_path(override))
    env = os.getenv("CODEX_LOG_DB_PATH") or os.getenv("CODEX_DB_PATH")
    if env:
        return str(resolve_db_path(env))
    for suffix in (".db", ".sqlite"):
        candidate = DEFAULT_LOG_DB.with_suffix(suffix)
        if candidate.exists():
            return str(resolve_db_path(candidate))
    return str(resolve_db_path(DEFAULT_LOG_DB))


def _fetch_events(db_path: str, session_id: str) -> list[dict[str, Any]]:
    conn = open_db(db_path)
    conn.row_factory = sqlite3.Row
    try:
        table = infer_probable_table(conn)
        if table is None:
            raise RuntimeError("No suitable events table found.")
        mapping = infer_columns(conn, table)
        cols = [
            f"{mapping['timestamp']} AS timestamp",
            f"{mapping['session_id']} AS session_id",
            f"{mapping['message']} AS message",
        ]
        if "role" in mapping:
            cols.append(f"{mapping['role']} AS role")
        sql = (
            f"SELECT {', '.join(cols)} FROM {table} "  # nosec B608
            f"WHERE {mapping['session_id']}=? ORDER BY {mapping['timestamp']}"
        )
        cur = conn.execute(sql, (session_id,))
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


def export_session(session_id: str, fmt: str = "json", db: str | None = None) -> str:
    """Return a session's events in timestamp order as a serialized string.

    ``session_id`` is checked against ``^[A-Za-z0-9_-]+$``; empty or
    nonmatching identifiers raise ``ValueError``. ``db`` overrides the
    environment/default resolution described by :func:`_db_path`. The
    database must have a compatible event table with session, timestamp,
    message, and role columns.

    ``fmt="json"`` returns an indented JSON list with normalized field names.
    Every other value selects newline-joined ``timestamp (role): message``
    text (the CLI restricts this to ``json``/``text``). No matching rows
    produces ``"[]"`` for JSON or an empty string for text. Schema and SQLite
    failures propagate; the reader closes its connection on either path.
    """
    if not re.match(r"^[A-Za-z0-9_-]+$", str(session_id or "")):
        raise ValueError("Invalid session_id: must match ^[A-Za-z0-9_-]+$")
    db_path = _db_path(db)
    events = _fetch_events(db_path, session_id)
    if fmt == "json":
        return json.dumps(events, indent=2)
    lines: list[str] = []
    for e in events:
        ts = e.get("timestamp", "")
        role = e.get("role", "")
        msg = e.get("message", "")
        lines.append(f"{ts} ({role}): {msg}")
    return "\n".join(lines)


def main(argv: Iterable[str] | None = None) -> int:
    """Parse export options, log the serialized session, and return ``0``.

    ``argv`` omits the executable name; ``None`` reads process arguments.
    Argument errors raise argparse's ``SystemExit``; validation, schema, and
    database errors from :func:`export_session` are not converted to status
    codes. Output routing and log prefixes depend on the configured logger.
    """
    parser = argparse.ArgumentParser(description="Export session events from SQLite")
    parser.add_argument("session_id", help="Session identifier to export")
    parser.add_argument("--format", choices=["json", "text"], default="json", help="Output format")
    parser.add_argument("--db", help="Path to SQLite DB", default=None)
    args = parser.parse_args(list(argv) if argv is not None else None)
    logger.info(export_session(args.session_id, args.format, args.db))
    return 0


if __name__ == "__main__":
    session_ctx: Optional[Any]
    try:
        from .session_hooks import session as session_ctx
    except (ImportError, AttributeError):  # pragma: no cover - helper optional
        session_ctx = None
    if session_ctx:
        with session_ctx(sys.argv):
            raise SystemExit(main())
    raise SystemExit(main())
