"""
Physics-Inspired Quantum-Integrated Software Developer Orchestrator.

This orchestrator leverages all physics paradigms to guide software development:
- Chaos Theory: Explore diverse solution approaches
- Fractal Geometry: Analyze code structure complexity
- Fluid Dynamics: Optimize development workflow
- Electromagnetic Fields: Prioritize critical components
- Wave Propagation: Synchronize team decisions
- Relativistic Effects: Manage distributed development
- Quantum Mechanics: Parallel solution evaluation

The orchestrator assists in developing Python and console applications by:
1. Analyzing user requirements
2. Identifying missing variables
3. Suggesting optimal architectures
4. Generating code with physics-guided decisions
5. Optimizing development workflow
"""

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)
from enum import Enum  # noqa: E402
from types import ModuleType  # noqa: E402
from typing import Any, Optional  # noqa: E402

try:
    import numpy as np

    NUMPY_AVAILABLE = True
except ImportError:
    logger.warning("Failed to import numpy; using stub fallback", exc_info=True)
    NUMPY_AVAILABLE = False

    # Minimal stub so code guarded by NUMPY_AVAILABLE can still
    # work when the guard is patched to True in tests.
    class _NpStubDev(ModuleType):
        """Lightweight numpy stand-in for developer_orchestrator."""

        def __init__(self) -> None:
            super().__init__("numpy")

        @staticmethod
        def array(obj: Any, *a: Any, **kw: Any) -> Any:
            _ = (a, kw)
            return obj

    np = _NpStubDev()

try:
    from agents.advanced_physics_calculators import (
        AdvancedPhysicsOrchestrator,
        ChaoticNeuralNetwork,
    )

    ADVANCED_PHYSICS = True
except ImportError:
    logger.warning("Failed to import advanced physics calculators", exc_info=True)
    ADVANCED_PHYSICS = False

# Import logging utilities
try:
    from codex.logging.session_logger import log_message

    LOGGING_AVAILABLE = True

except ImportError:
    LOGGING_AVAILABLE = False
    logger.warning("Failed to import session logger; using print fallback", exc_info=True)

    # Fallback to print if logging not available
    def log_message(session_id, role, message, **kwargs):  # type: ignore
        _ = (session_id, kwargs)
        print(f"[{role}] {message}")


class AppType(Enum):
    """Types of applications the orchestrator can develop."""

    PYTHON_CONSOLE = "python_console"
    PYTHON_CLI = "python_cli"
    PYTHON_API = "python_api"
    PYTHON_WEB = "python_web"
    PYTHON_LIBRARY = "python_library"
    PYTHON_SCRIPT = "python_script"


class DevelopmentPhase(Enum):
    """Phases in the development lifecycle."""

    REQUIREMENTS = "requirements"
    DESIGN = "design"
    ARCHITECTURE = "architecture"
    IMPLEMENTATION = "implementation"
    TESTING = "testing"
    OPTIMIZATION = "optimization"
    DEPLOYMENT = "deployment"
    MAINTENANCE = "maintenance"


@dataclass
class RequirementVariable:
    """A variable that needs to be specified for development."""

    name: str
    description: str
    variable_type: str  # str, int, float, bool, list, dict
    required: bool = True
    default_value: Any = None
    suggested_values: list[Any] = field(default_factory=list)
    current_value: Any = None

    def is_satisfied(self) -> bool:
        """Check if variable has a value."""
        return self.current_value is not None or not self.required

    def suggest_from_chaos(self, cnn: Optional["ChaoticNeuralNetwork"] = None) -> list[Any]:
        """Generate suggestions using chaos theory for exploration."""
        if not ADVANCED_PHYSICS or cnn is None:
            return self.suggested_values

        # Use chaos to explore diverse options
        if self.variable_type in ["int", "float"]:
            # Generate diverse numeric suggestions
            if self.suggested_values:
                min_val = min(self.suggested_values)
                max_val = max(self.suggested_values)
            else:
                min_val, max_val = 0, 100

            chaotic_values = cnn.generate_test_parameters([(min_val, max_val)], num_tests=5)
            return [v[0] for v in chaotic_values]

        return self.suggested_values


@dataclass
class CodeComponent:
    """A component of the software being developed."""

    name: str
    component_type: str  # module, class, function, test
    description: str
    code: str = ""
    component_id: str = ""
    dependencies: list[str] = field(default_factory=list)
    priority: float = 0.5  # 0-1, for EM field routing
    complexity: float = 1.0  # For fractal analysis
    complexity_score: Optional[float] = None  # Normalised 0-1 complexity score
    implementation_status: str = "pending"  # pending, in_progress, complete

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "component_id": self.component_id,
            "name": self.name,
            "type": self.component_type,
            "description": self.description,
            "dependencies": self.dependencies,
            "priority": self.priority,
            "complexity": self.complexity,
            "status": self.implementation_status,
        }


class PhysicsGuidedDeveloperOrchestrator:
    """
    Physics-inspired orchestrator for software development.

    Uses physics paradigms to guide development decisions:
    - Chaos: Explore diverse architectural approaches
    - Fractals: Analyze code structure and detect complexity
    - Fluid: Optimize development workflow and resource allocation
    - EM Fields: Route attention to high-priority components
    - Waves: Synchronize team consensus on design decisions
    - Relativity: Manage distributed development with time zones
    - Quantum: Evaluate multiple implementation approaches in parallel
    """

    def __init__(self, session_id: Optional[str] = None, app_type: Optional["AppType"] = None):
        """Start a development session with no requirements or components.

        ``session_id`` labels log messages and defaults to ``dev_orchestrator``.
        ``app_type`` is the initial application category; requirement analysis
        subsequently chooses it from the supplied request. Advanced physics
        engines are instantiated only when their optional import succeeded.
        """
        self.app_type: Optional[AppType] = app_type
        # requirements is a mutable list; required_variables is a derived dict view kept in sync
        self._requirements: list[RequirementVariable] = []
        self.components: list[CodeComponent] = []
        self.current_phase: DevelopmentPhase = DevelopmentPhase.REQUIREMENTS
        self.session_id = session_id or "dev_orchestrator"

        # Physics engines
        self.physics_orchestrator = None
        if ADVANCED_PHYSICS:
            self.physics_orchestrator = AdvancedPhysicsOrchestrator()

        self.development_history: list[dict[str, Any]] = []
        self.suggestions_cache: dict[str, list[Any]] = {}

    def _log(self, role: str, message: str) -> None:
        """Log a message using session logger."""
        log_message(self.session_id, role, message)

    @property
    def requirements(self) -> list[RequirementVariable]:
        """Return mutable list of required variables.  Append/index operations persist."""
        return self._requirements

    @requirements.setter
    def requirements(self, value: list[RequirementVariable]) -> None:
        """Replace the requirements list (also updates required_variables)."""
        self._requirements = list(value)

    @property
    def required_variables(self) -> dict[str, RequirementVariable]:
        """Dict view of requirements, keyed by name."""
        return {rv.name: rv for rv in self._requirements}

    @required_variables.setter
    def required_variables(self, value: dict[str, RequirementVariable]) -> None:
        """Set requirements from a dict (keeps insertion order)."""
        self._requirements = list(value.values())

    # Alias for backward compat with tests that call analyze_requirements()
    def analyze_requirements(self, user_request: str) -> Any:
        """Analyse a plain-text user request and populate required_variables."""
        return self.analyze_user_requirements({"request": user_request})

    def analyze_user_requirements(self, requirements: dict[str, Any]) -> dict[str, Any]:
        """
        Analyze user requirements and identify missing variables.

        Args:
            requirements: User-provided requirements dictionary

        Returns:
            Analysis with missing variables and suggestions
        """
        self._log("system", "=== ANALYZING USER REQUIREMENTS ===")

        # Extract app type
        if "app_type" in requirements:
            try:
                self.app_type = AppType(requirements["app_type"])
            except ValueError as e:
                logger.debug(f"ValueError: {e}")
                logger.warning(f"ValueError: {e}", exc_info=True)
                self.app_type = AppType.PYTHON_CONSOLE
        else:
            self.app_type = AppType.PYTHON_CONSOLE

        self._log("system", f"Application Type: {self.app_type.value}")

        # Define required variables based on app type
        self._define_required_variables()

        # Extract provided variables
        provided_vars = set()
        for var_name, var_obj in self.required_variables.items():
            if var_name in requirements:
                var_obj.current_value = requirements[var_name]
                provided_vars.add(var_name)

        # Identify missing variables
        missing_vars = {
            name: var for name, var in self.required_variables.items() if not var.is_satisfied()
        }

        # Use chaos theory to generate diverse suggestions
        if ADVANCED_PHYSICS and self.physics_orchestrator:
            for var_name, var_obj in missing_vars.items():
                suggestions = var_obj.suggest_from_chaos(self.physics_orchestrator.chaos)
                self.suggestions_cache[var_name] = suggestions

        missing_variables: list[dict[str, object]] = []
        variable_suggestions: dict[str, list[object]] = {}
        completeness = (
            len(provided_vars) / len(self.required_variables) if self.required_variables else 0
        )
        analysis: dict[str, object] = {
            "app_type": self.app_type.value,
            "provided_variables": list(provided_vars),
            "missing_variables": missing_variables,
            "suggestions": variable_suggestions,
            "completeness": completeness,
        }

        # Format missing variables with suggestions
        for var_name, var_obj in missing_vars.items():
            var_info: dict[str, object] = {
                "name": var_name,
                "description": var_obj.description,
                "type": var_obj.variable_type,
                "required": var_obj.required,
                "default": var_obj.default_value,
            }

            # Add physics-inspired suggestions
            suggestions = self.suggestions_cache.get(var_name, var_obj.suggested_values)
            if suggestions:
                var_info["suggested_options"] = suggestions[:5]  # Top 5

            missing_variables.append(var_info)
            variable_suggestions[var_name] = suggestions[:5] if suggestions else []

        self._log("system", f"Completeness: {completeness * 100:.1f}%")
        self._log("system", f"Provided: {len(provided_vars)} variables")
        self._log("system", f"Missing: {len(missing_vars)} variables")

        return analysis

    def _define_required_variables(self):
        """Define required variables based on app type."""
        # Common variables for all app types
        self.required_variables = {
            "app_name": RequirementVariable(
                name="app_name",
                description="Name of the application",
                variable_type="str",
                required=True,
                suggested_values=["my_app", "tool", "service", "script"],
            ),
            "description": RequirementVariable(
                name="description",
                description="Brief description of what the app does",
                variable_type="str",
                required=True,
            ),
            "python_version": RequirementVariable(
                name="python_version",
                description="Target Python version",
                variable_type="str",
                required=False,
                default_value="3.10",
                suggested_values=["3.8", "3.9", "3.10", "3.11", "3.12"],
            ),
        }

        # App-specific variables — use setter assignment (not .update()) because
        # required_variables is a @property returning a derived dict; .update() on
        # that dict is a no-op against the backing _requirements list.
        app_specific_vars: dict = {}
        if self.app_type == AppType.PYTHON_CLI:
            app_specific_vars = {
                "cli_framework": RequirementVariable(
                    name="cli_framework",
                    description="CLI framework to use",
                    variable_type="str",
                    required=False,
                    default_value="argparse",
                    suggested_values=["argparse", "click", "typer", "fire"],
                ),
                "commands": RequirementVariable(
                    name="commands",
                    description="list of CLI commands",
                    variable_type="list",
                    required=True,
                ),
            }

        elif self.app_type == AppType.PYTHON_API:
            app_specific_vars = {
                "api_framework": RequirementVariable(
                    name="api_framework",
                    description="API framework to use",
                    variable_type="str",
                    required=False,
                    default_value="fastapi",
                    suggested_values=["fastapi", "flask", "django", "starlette"],
                ),
                "endpoints": RequirementVariable(
                    name="endpoints",
                    description="list of API endpoints",
                    variable_type="list",
                    required=True,
                ),
                "authentication": RequirementVariable(
                    name="authentication",
                    description="Authentication method",
                    variable_type="str",
                    required=False,
                    default_value="none",
                    suggested_values=["none", "jwt", "oauth2", "api_key", "basic"],
                ),
            }

        elif self.app_type == AppType.PYTHON_WEB:
            app_specific_vars = {
                "web_framework": RequirementVariable(
                    name="web_framework",
                    description="Web framework to use",
                    variable_type="str",
                    required=False,
                    default_value="flask",
                    suggested_values=["flask", "django", "fastapi", "starlette"],
                ),
                "routes": RequirementVariable(
                    name="routes",
                    description="Web routes/pages",
                    variable_type="list",
                    required=True,
                ),
            }

        elif self.app_type == AppType.PYTHON_LIBRARY:
            app_specific_vars = {
                "modules": RequirementVariable(
                    name="modules",
                    description="Main modules/packages",
                    variable_type="list",
                    required=True,
                ),
                "public_api": RequirementVariable(
                    name="public_api",
                    description="Public API functions/classes",
                    variable_type="list",
                    required=True,
                ),
            }

        if app_specific_vars:
            self.required_variables = {**self.required_variables, **app_specific_vars}

    def suggest_architecture(self, requirements: dict[str, Any]) -> dict[str, Any]:
        """
        Suggest optimal architecture using physics paradigms.

        Uses:
        - Fractal analysis for structure
        - EM fields for component prioritization
        - Quantum superposition for parallel evaluation
        """
        self._log("system", "=== SUGGESTING ARCHITECTURE ===")

        self.current_phase = DevelopmentPhase.ARCHITECTURE

        # Create component graph
        components = self._generate_components(requirements)

        # Use fractal analysis to evaluate structure
        structure_analysis = None
        if ADVANCED_PHYSICS and self.physics_orchestrator:
            # Build tree structure from components
            component_tree = self._build_component_tree(components)
            structure_analysis = self.physics_orchestrator.fractal.analyze_code_tree(component_tree)

        # Use EM fields to prioritize components
        if ADVANCED_PHYSICS and self.physics_orchestrator and NUMPY_AVAILABLE:
            hotspots = []
            for comp in components:
                # Position based on complexity and priority
                pos = np.array([comp.priority, comp.complexity / 10.0])
                charge = comp.priority * 2.0
                hotspots.append((pos, charge))

            for pos, charge in hotspots:
                self.physics_orchestrator.em_field.add_charge(pos, charge)

        architecture = {
            "components": [comp.to_dict() for comp in components],
            "structure_analysis": structure_analysis,
            "recommended_order": self._determine_implementation_order(components),
            "dependencies": self._extract_dependencies(components),
        }

        self._log("system", f"Generated {len(components)} components")
        if structure_analysis:
            self._log(
                "system", f"Fractal dimension: {structure_analysis.get('fractal_dimension', 0):.2f}"
            )

        return architecture

    def _generate_components(self, requirements: dict[str, Any]) -> list[CodeComponent]:
        """Generate code components based on requirements."""
        components = []

        # Main entry point
        components.append(
            CodeComponent(
                component_id="main",
                name="main.py",
                component_type="module",
                description="Main entry point",
                priority=1.0,
                complexity=1.0,
            )
        )

        # Add app-specific components
        if self.app_type == AppType.PYTHON_CLI:
            commands = requirements.get("commands", [])
            for i, cmd in enumerate(commands):
                components.append(
                    CodeComponent(
                        component_id=f"cmd_{i}",
                        name=f"{cmd}_command",
                        component_type="function",
                        description=f"Command handler for {cmd}",
                        dependencies=["main"],
                        priority=0.7,
                        complexity=2.0,
                    )
                )

        elif self.app_type == AppType.PYTHON_API:
            endpoints = requirements.get("endpoints", [])
            for i, endpoint in enumerate(endpoints):
                components.append(
                    CodeComponent(
                        component_id=f"endpoint_{i}",
                        name=f"{endpoint}_endpoint",
                        component_type="function",
                        description=f"API endpoint for {endpoint}",
                        dependencies=["main"],
                        priority=0.8,
                        complexity=3.0,
                    )
                )

        # Configuration component
        components.append(
            CodeComponent(
                component_id="config",
                name="config.py",
                component_type="module",
                description="Application configuration",
                priority=0.9,
                complexity=1.0,
            )
        )

        # Tests
        components.append(
            CodeComponent(
                component_id="tests",
                name="test_main.py",
                component_type="test",
                description="Unit tests",
                dependencies=["main"],
                priority=0.6,
                complexity=2.0,
            )
        )

        self.components = list(components)
        return components

    def _build_component_tree(self, components: list[CodeComponent]) -> dict[str, Any]:
        """
        Build hierarchical tree from components for fractal analysis.

        Args:
            components: list of CodeComponent objects

        Returns:
            Nested dictionary where keys are component names and values are
            dictionaries of their dependencies. Example:
            {
                'main.py': {'config.py': {}, 'utils.py': {}},
                'config.py': {},
                'utils.py': {}
            }
        """
        tree: dict[str, dict[str, dict[str, object]]] = {}

        for comp in components:
            tree[comp.name] = {dep: {} for dep in comp.dependencies}

        return tree

    def _determine_implementation_order(self, components: list[CodeComponent]) -> list[str]:
        """Determine optimal implementation order using dependency analysis."""
        # Topological sort based on dependencies
        order = []
        visited = set()

        def visit(comp_id: str):
            if comp_id in visited:
                return

            comp = next((c for c in components if c.component_id == comp_id), None)
            if not comp:
                return

            for dep in comp.dependencies:
                visit(dep)

            visited.add(comp_id)
            order.append(comp_id)

        for comp in components:
            visit(comp.component_id)

        return order

    def _extract_dependencies(self, components: list[CodeComponent]) -> dict[str, list[str]]:
        """Extract dependency graph."""
        return {comp.component_id: comp.dependencies for comp in components}

    def generate_code(
        self,
        component_id: str | dict[str, Any] | None = None,
        specifications: Optional[dict[str, Any]] = None,
    ) -> str:
        """
        Generate code for a specific component or from specifications directly.

        Args:
            component_id: Component ID string, specifications dict, or None to
                          generate generic code.
            specifications: Optional specifications (used when component_id is a string)

        Uses chaos theory to explore different implementation approaches.
        """
        # Handle case where specifications are passed as first argument
        if isinstance(component_id, dict):
            specifications = component_id
            component_id = None

        if component_id is None:
            # No specific component requested
            if self.components:
                # Generate code for the first component
                first = self.components[0]
                component_id = first.component_id if first.component_id else first.name
            else:
                return self._generate_generic_code(specifications or {})

        if (
            isinstance(component_id, str)
            and specifications is not None
            and "app_name" in specifications
        ):
            return self._generate_app_from_specs(specifications)

        # Find component in list by component_id or name
        component = None
        for c in self.components:
            if c.component_id == component_id or c.name == component_id:
                component = c
                break

        if component is None:
            return f"# Error: Component {component_id} not found"

        self._log("system", f"=== GENERATING CODE: {component.name} ===")

        # Use template based on component type
        if component.component_type == "module" and component.component_id == "main":
            code = self._generate_main_module(specifications or {})
        elif component.component_type == "function":
            code = self._generate_function(component, specifications or {})
        elif component.component_type == "test":
            code = self._generate_tests(specifications or {})
        else:
            code = f"# {component.description}\n# TODO: Implement {component.name}\n"

        component.code = code
        component.implementation_status = "complete"

        return code

    def _generate_app_from_specs(self, specs: dict[str, Any]) -> str:
        """Generate a simple application from specifications."""
        app_name = specs.get("app_name", "my_app")
        app_type = specs.get("app_type", "cli")

        return f'''#!/usr/bin/env python3
"""
{app_name} - Generated application
Type: {app_type}
"""

def main():
    """Main entry point."""
    print("Hello from {app_name}!")
    print("Application type: {app_type}")

if __name__ == "__main__":
    main()
'''

    def _generate_generic_code(self, specs: dict[str, Any]) -> str:
        """Generate generic code from specifications."""
        return f"""# Generated code from specifications
# Specs: {specs}

def placeholder():
    \"\"\"Generated placeholder function.\"\"\"
    pass
"""

    def _generate_main_module(self, specs: dict[str, Any]) -> str:
        """Generate main module code."""
        app_name = (
            self.required_variables.get(
                "app_name", RequirementVariable("", "", "str")
            ).current_value
            or "app"
        )
        description = (
            self.required_variables.get(
                "description", RequirementVariable("", "", "str")
            ).current_value
            or "Application"
        )

        if self.app_type == AppType.PYTHON_CLI:
            framework = specs.get("cli_framework", "argparse")
            return self._generate_cli_main(app_name, description, framework)
        if self.app_type == AppType.PYTHON_API:
            framework = specs.get("api_framework", "fastapi")
            return self._generate_api_main(app_name, description, framework)
        return f'''"""
{description}
"""

def main():
    """Main entry point."""
    print("Hello from {app_name}!")

if __name__ == '__main__':
    main()
'''

    def _generate_cli_main(self, app_name: str, description: str, framework: str) -> str:
        """Generate CLI application main module."""
        if framework == "argparse":
            return f'''"""
{description}
"""
import argparse

def main():
    """Main entry point for CLI."""
    parser = argparse.ArgumentParser(description='{description}')
    parser.add_argument('--version', action='version', version='1.0.0')

    # Add subcommands here
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    args = parser.parse_args()

    if args.command:
        print(f"Executing command: {{args.command}}")
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
'''
        if framework == "typer":
            return f'''"""
{description}
"""
import typer

app = typer.Typer()

@app.command()
def hello(name: str = "World"):
    """Say hello."""
    typer.echo(f"Hello {{name}}!")

def main():
    """Main entry point."""
    app()

if __name__ == '__main__':
    main()
'''
        return f"# CLI framework: {framework}\n# TODO: Implement\n"

    def _generate_api_main(self, app_name: str, description: str, framework: str) -> str:
        """Generate API application main module."""
        if framework == "fastapi":
            return f'''"""
{description}
"""
from fastapi import FastAPI

app = FastAPI(title="{app_name}", description="{description}")

@app.get("/")
async def root():
    """Root endpoint."""
    return {{"message": "Welcome to {app_name}"}}

@app.get("/health")
async def health():
    """Health check endpoint."""
    return {{"status": "healthy"}}

def main():
    """Run the API server."""
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

if __name__ == '__main__':
    main()
'''
        return f"# API framework: {framework}\n# TODO: Implement\n"

    def _generate_function(self, component: CodeComponent, specs: dict[str, Any]) -> str:
        """Generate function code."""
        return f'''
def {component.name}(*args, **kwargs):
    """
    {component.description}

    Args:
        *args: Positional arguments
        **kwargs: Keyword arguments

    Returns:
        Result of operation
    """
    # TODO: Implement {component.name}
    raise NotImplementedError("{component.name} not yet implemented")
'''

    def _generate_tests(self, specs: dict[str, Any]) -> str:
        """Generate test code."""
        return '''"""
Unit tests for the application.
"""
import pytest

def test_example():
    """Example test."""
    assert True, "Tests should be implemented"

def test_main_imports():
    """Test that main module can be imported."""
    try:
        import main
        assert True
    except ImportError as e:
        logger.debug(f"ImportError: {e}")
        pytest.fail(f"Failed to import main: {e}")
'''

    def get_development_status(self) -> dict[str, Any]:
        """Get current development status."""
        total_components = len(self.components)
        completed = sum(1 for comp in self.components if comp.implementation_status == "complete")

        return {
            "phase": self.current_phase.value,
            "components": {
                "total": total_components,
                "completed": completed,
                "pending": total_components - completed,
                "progress": completed / total_components if total_components > 0 else 0,
            },
            "variables": {
                "total": len(self.required_variables),
                "satisfied": sum(1 for v in self.required_variables.values() if v.is_satisfied()),
            },
        }

    def export_project(self, output_dir: str = ".", overwrite: bool = False) -> dict[str, str]:
        """
        Export generated code to files.

        Args:
            output_dir: Directory to export files to
            overwrite: If False, do not overwrite existing files (default: False)

        Returns:
            Dictionary mapping filenames to file paths (or error messages if failed)

        Raises:
            ValueError: If output_dir is not a valid directory path
            PermissionError: If output_dir is not writable
            RuntimeError: If output_dir cannot be created
        """
        import os

        exported_files = {}

        # Ensure output_dir exists and is a directory - use atomic creation
        try:
            os.makedirs(output_dir, exist_ok=True)
        except OSError as e:
            logger.debug(f"OSError: {e}")
            raise RuntimeError(f"Failed to create output directory '{output_dir}': {e}") from e

        # Verify directory is valid and writable after creation/access
        if not os.path.isdir(output_dir):
            raise ValueError(f"Output path '{output_dir}' is not a directory.")
        if not os.access(output_dir, os.W_OK):
            raise PermissionError(f"Output directory '{output_dir}' is not writable.")

        for comp in self.components:
            if comp.code:
                filepath = os.path.join(output_dir, comp.name)

                try:
                    if overwrite:
                        # Overwrite mode: use standard open
                        with open(filepath, "w") as f:
                            f.write(comp.code)
                        exported_files[comp.name] = filepath
                        self._log("system", f"Exported {comp.name} to {filepath}")
                    else:
                        # Non-overwrite mode: use exclusive creation to prevent TOCTOU
                        # os.open with O_CREAT | O_EXCL atomically checks and creates
                        try:
                            fd = os.open(filepath, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
                            try:
                                os.write(fd, comp.code.encode("utf-8"))
                            finally:
                                os.close(fd)
                            exported_files[comp.name] = filepath
                            self._log("system", f"Exported {comp.name} to {filepath}")
                        except FileExistsError as e:
                            logger.debug(f"FileExistsError: {e}")
                            logger.warning(f"FileExistsError: {e}", exc_info=True)
                            exported_files[comp.name] = f"Skipped (file exists): {filepath}"
                            self._log("system", f"Skipped {comp.name} (file exists)")
                except OSError as e:
                    logger.debug(f"OSError: {e}")
                    error_msg = f"Failed to write {filepath}: {e}"
                    exported_files[comp.name] = error_msg
                    self._log("system", error_msg)

        return exported_files

    def validate_code(self, code: str, component_id: Optional[str] = None) -> dict[str, Any]:
        """
        Validate generated code for syntax and quality.

        Args:
            code: Python code to validate
            component_id: Optional component ID for context

        Returns:
            Validation results with 'valid', 'errors', and 'warnings' keys
        """
        import ast

        errors: list[str] = []
        warnings: list[str] = []
        result: dict[str, object] = {
            "valid": True,
            "errors": errors,
            "warnings": warnings,
            "component_id": component_id,
        }

        # Syntax validation
        try:
            ast.parse(code)
            self._log("system", f"Code syntax valid for {component_id or 'component'}")
        except SyntaxError as e:
            logger.debug(f"SyntaxError: {e}")
            result["valid"] = False
            errors.append(f"Syntax error at line {e.lineno}: {e.msg}")
            self._log("system", f"Syntax error in {component_id or 'component'}: {e}")

        # Basic quality checks
        if len(code.strip()) < 10:
            warnings.append("Code is very short, may be incomplete")

        if "TODO" in code or "FIXME" in code:
            warnings.append("Code contains TODO/FIXME markers")

        if "\t" in code:
            warnings.append("Code uses tabs instead of spaces")

        return result

    def prioritize_tasks(self, tasks: Optional[list[dict[str, Any]]] = None) -> list[str]:
        """
        Prioritize development tasks using physics-based scoring.

        Args:
            tasks: Optional list of task dicts with 'id', 'priority', 'complexity'
                  If None, uses components as tasks

        Returns:
            list of task IDs in priority order
        """
        if tasks is None:
            # Use components as tasks
            tasks = [
                {
                    "id": comp.component_id,
                    "priority": comp.priority,
                    "complexity": comp.complexity,
                    "dependencies": comp.dependencies,
                }
                for comp in self.components
            ]

        # Score based on priority and inverse complexity
        # Higher priority, lower complexity = higher score
        scored_tasks = []
        for task in tasks:
            task_id = task.get("id", "")
            priority = task.get("priority", 0.5)
            complexity = task.get("complexity", 1.0)
            task.get("dependencies", [])

            # Score: priority / sqrt(complexity)
            # Penalize tasks with unmet dependencies
            score = priority / (complexity**0.5)

            scored_tasks.append((score, task_id))

        # Sort by score descending
        scored_tasks.sort(reverse=True, key=lambda x: x[0])

        result = [task_id for _, task_id in scored_tasks]
        self._log("system", f"Prioritized {len(result)} tasks")
        return result

    def execute_workflow(self, workflow_steps: Optional[list[str]] = None) -> dict[str, Any]:
        """
        Execute a development workflow through all phases.

        Args:
            workflow_steps: Optional list of phase names to execute.
                            If None, executes standard workflow.

        Returns:
            Workflow execution results. ``outputs["implementation"]`` reports
            generated component and newline counts; TESTING validates the code
            stored on each component. Unknown steps are recorded in
            ``steps_failed`` without preventing subsequent steps from running.

        Example:
            After populating ``components``, call
            ``execute_workflow(["IMPLEMENTATION", "TESTING"])`` to generate and
            syntax-check them using their component IDs (or names if unset).
        """
        if workflow_steps is None:
            workflow_steps = ["REQUIREMENTS", "ARCHITECTURE", "IMPLEMENTATION", "TESTING"]

        steps_completed: list[str] = []
        steps_failed: list[str] = []
        outputs: dict[str, object] = {}
        results: dict[str, object] = {
            "steps_completed": steps_completed,
            "steps_failed": steps_failed,
            "current_phase": self.current_phase.value,
            "outputs": outputs,
        }

        for step in workflow_steps:
            step_upper = step.upper()

            try:
                if step_upper == "REQUIREMENTS":
                    self.current_phase = DevelopmentPhase.REQUIREMENTS
                    # Requirements already analyzed if variables are set
                    outputs["requirements"] = {
                        "completeness": (
                            sum(1 for v in self.required_variables.values() if v.is_satisfied())
                            / len(self.required_variables)
                            if self.required_variables
                            else 0
                        )
                    }
                    steps_completed.append(step)

                elif step_upper == "ARCHITECTURE":
                    self.current_phase = DevelopmentPhase.ARCHITECTURE
                    # Build requirements from current state
                    requirements = {
                        var_name: var.current_value
                        for var_name, var in self.required_variables.items()
                        if var.current_value is not None
                    }
                    arch = self.suggest_architecture(requirements)
                    outputs["architecture"] = arch
                    steps_completed.append(step)

                elif step_upper == "IMPLEMENTATION":
                    self.current_phase = DevelopmentPhase.IMPLEMENTATION
                    # Generate code for all components
                    generated: dict[str, str] = {}
                    for component in self.components:
                        component_key = component.component_id or component.name
                        code = self.generate_code(component_key)
                        generated[component_key] = code
                    outputs["implementation"] = {
                        "components_generated": len(generated),
                        "total_lines": (
                            sum(c.count("\n") for c in generated.values()) if generated else 0
                        ),
                    }
                    steps_completed.append(step)

                elif step_upper == "TESTING":
                    self.current_phase = DevelopmentPhase.TESTING
                    # Validate all generated code
                    validations = {}
                    for comp in self.components:
                        comp_id = comp.component_id
                        if comp.code:
                            validation = self.validate_code(comp.code, comp_id)
                            validations[comp_id] = validation["valid"]
                    outputs["testing"] = {
                        "components_validated": len(validations),
                        "all_valid": all(validations.values()) if validations else False,
                    }
                    steps_completed.append(step)

                else:
                    steps_failed.append(f"Unknown step: {step}")

            except Exception as e:
                logger.debug(f"Exception: {e}")
                steps_failed.append(f"{step}: {e!s}")
                self._log("system", f"Workflow step {step} failed: {e}")

        results["success"] = len(steps_failed) == 0
        results["final_phase"] = self.current_phase.value

        self._log("system", f"Workflow complete: {len(steps_completed)} steps")
        return results


def create_developer_orchestrator() -> PhysicsGuidedDeveloperOrchestrator:
    """Factory function to create orchestrator."""
    return PhysicsGuidedDeveloperOrchestrator()


# Export main classes
__all__ = [
    "PhysicsGuidedDeveloperOrchestrator",
    "AppType",
    "DevelopmentPhase",
    "RequirementVariable",
    "CodeComponent",
    "create_developer_orchestrator",
]
